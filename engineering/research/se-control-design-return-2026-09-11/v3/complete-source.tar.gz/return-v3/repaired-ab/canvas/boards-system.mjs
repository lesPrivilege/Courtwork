import { page, icon, iconBtn, sidebar } from './shared.mjs';

const sw = (hex) => `<span class="swatch" style="background:${hex}"></span>`;

export function buildSystem(out) {
  // ── Main: recommended system (DG-09) ────────────────────────────────────────
  const grammar = `
  <table class="spec">
    <tr><th style="width:150px">Axis</th><th>Legal combinations (existing tokens only)</th><th style="width:300px">Counter-example / boundary</th></tr>
    <tr><td>Surface</td><td>Four roles: sunken <span class="k">--panel-muted</span> · frame <span class="k">--frame</span> · paper <span class="k">--panel</span> · raised <span class="k">--float</span>, resolved by the appearance in force (default slate: #e9edef / #e0e4e7 / #f4f5f6 / #ffffff light; #1c2021 / #171a1b / #222627 / #2e3335 dark). Authored plane (user bubble): light #202426, dark = <span class="k">--float</span> (CW-PREF-20260911-01). Components consume roles, never these hex values.</td><td>No third frame, no raised card inside a raised card. Sunken is legal below paper in both themes; "nothing darker than its background" is not a rule. The open Attention row uses <span class="k">--float</span> as the current pattern; it is still a selection (see State).</td></tr>
    <tr><td>State</td><td>Interaction states hover <span class="k">--hover</span> · pressed <span class="k">--pressed</span> · selected <span class="k">--selected</span> (aria-current / aria-pressed) · focus 2px <span class="k">--focus</span> ring offset 2. Object states running / waiting / review are words (Working · Waiting for you · Needs you) with weight, plus the 6px dot for running. The two families are <b>orthogonal</b>: a running row can be selected and focused at once; each fact keeps its own channel.</td><td>No exclusive chain ("running never selected") — that was wrong in v1. Color-only state is forbidden everywhere (forced-colors, SE-08); Review colour is fixed per scheme and independent of skin.</td></tr>
    <tr><td>Color</td><td>Ink roles only: <span class="k">--ink</span>, <span class="k">--muted-strong</span> (text ≥ 4.5:1), <span class="k">--muted</span> (icons, hairlines ≥ 3:1), <span class="k">--accent</span> = ink (solid submit), <span class="k">--danger</span> (text + 2px left rule, never a flood), <span class="k">--success</span> (loaded word), <span class="k">--attention-review</span> (Needs you word, 600 weight).</td><td>New Spark/Attention glyphs take <span class="k">currentColor</span> and inherit the row's role. They never carry a color of their own, never a badge, never a dot.</td></tr>
    <tr><td>Type</td><td>Productive ladder: title 18/600, nav-title 15/600, reading 15 @1.7, body 14 @1.5, section 13/600, label 12, meta 11.5, caption 10.5 caps @0.08em. Mono 12/1.6 for paths, hashes, model ids. Hierarchy by size + weight, not color or rules (WK-120).</td><td>Pages keeps its expressive serif (Georgia campaign) for editorial moments only; no serif enters App controls, tables or composer (UE-VG07 adapt).</td></tr>
    <tr><td>Material</td><td>Solid content planes. Two registered blur consumers only: chrome 12px (Back to latest chip), transient 16px (context popover). Glass always has a solid <span class="k">--float</span> fallback under reduced-transparency and forced-colors.</td><td>No glass on cards, dialogs, message stream, Spark/Attention rows. Material never encodes agent state (EX-SC1 8/8 ignore; iridescent status = anti-example).</td></tr>
    <tr><td>Shape</td><td>control.compact 6 · control.default 8 · surface.card 12 · surface.container 16 · full 999 (only the composer's floating Send/Stop) · 0 for tab strips and edge-flush planes. Concentric: R<sub>child</sub> = max(4, R<sub>parent</sub> − inset).</td><td>New glyph slots do not become circles; the Spark dialog stays 12; Attention registry rows stay 4.</td></tr>
    <tr><td>Motion</td><td>Registered tokens: <span class="k">--duration-fast</span> 120ms · <span class="k">--duration</span> 180ms · <span class="k">--ease-out</span> (.2,0,0,1). Also present in the code today: the 1.6s run pulse, a 1.8s activity shimmer (styles.css ~3433) and a raw 140ms on the Home attention chevron (~5471). Recommendation for DR-04: at most one long-lived loop, shimmer adjudicated, raw values normalised. Reduced motion = static.</td><td>The token list is not proof the code has converged. No progress for running, no token-rate, no replay of streamed text on reopen; word first, motion second.</td></tr>
    <tr><td>Icons</td><td>Lucide 1.41.0 static subset (35 glyphs), 24 grid, 2px stroke, round cap/join, sizes 16 row / 18 control / 20 nav; hit ≥ 32 desktop, 44 touch — glyph size is never the hit size. Two reopened slots (Spark, Attention) get Courtwork-drawn glyphs on the same grid + text kept; adopted specimen until DR-02's optical pass.</td><td>No family migration (WK-163 D). No sparkle, bell, eye. Glyphs carry no state or permission badge; donors need a real source filename + hash.</td></tr>
  </table>`;

  const depth = (dark) => `
  <div class="cell${dark ? ' dark' : ''}" style="background:var(--frame);border-color:var(--line);color:var(--ink)">
    <div class="eyebrow" style="margin-bottom:10px">${dark ? 'Dark' : 'Light'} · effective default-slate roles (styles.css ~5500–5570, selector html:not([data-skin=…]))</div>
    <div style="display:flex;gap:10px;align-items:flex-end">
      <div style="flex:1;background:var(--panel-muted);border:1px solid var(--line);border-radius:8px;padding:10px;font-size:11.5px;color:var(--ink)"><div class="k" style="color:var(--muted-strong)">sunken --panel-muted</div><div style="font-weight:600;margin-top:2px">${dark ? '#1c2021' : '#e9edef'}</div><div class="form-help">inset wells · a legal role below paper</div></div>
      <div style="flex:1;background:var(--frame);border:1px solid var(--line);border-radius:8px;padding:10px;font-size:11.5px;color:var(--ink)"><div class="k" style="color:var(--muted-strong)">frame --frame</div><div style="font-weight:600;margin-top:2px">${dark ? '#171a1b' : '#e0e4e7'}</div><div class="form-help">sidebar · canvas</div></div>
      <div style="flex:1;background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:10px;font-size:11.5px;color:var(--ink)"><div class="k" style="color:var(--muted-strong)">paper --panel</div><div style="font-weight:600;margin-top:2px">${dark ? '#222627' : '#f4f5f6'}</div><div class="form-help">reading plane</div></div>
      <div style="flex:1;background:var(--float);border:1px solid var(--line-strong);border-radius:8px;padding:10px;font-size:11.5px;box-shadow:var(--shadow-float);color:var(--ink)"><div class="k" style="color:var(--muted-strong)">raised --float</div><div style="font-weight:600;margin-top:2px">${dark ? '#2e3335' : '#ffffff'}</div><div class="form-help">composer · popover · dialog</div></div>
      <div style="flex:1;background:var(--authored-surface);color:var(--authored-ink);border-radius:8px;padding:10px;font-size:11.5px"><div class="k" style="color:var(--authored-muted)">authored</div><div style="font-weight:600;margin-top:2px">${dark ? '= --float' : '#202426'}</div><div style="font-size:11.5px;color:var(--authored-muted)">user message</div></div>
    </div>
    <p class="form-help" style="margin-top:8px">These are the default appearance's resolved values at dbd1efe; other skins resolve the same roles differently. Roles are the contract, hex values are not.</p>
  </div>`;

  page({
    file: `${out}/Main.dc.html`, title: 'Recommended system', width: 1440, height: 1500,
    body: `<div class="board">
      <div class="eyebrow">Courtwork · SE control surfaces · independent Design return · 2026-09-11 · packet dbd1efe · product a01dee8 · captures f1373cde</div>
      <h1 class="board-title" style="margin-top:8px">One system, two new glyphs, no new tokens.</h1>
      <p class="board-lede">Spark and Attention become visible in the sidebar, in their titles and in small controls through two Courtwork-drawn glyphs that share one reading direction — <b>from work on the left toward the object of attention on the right</b>. Everything else is expressed with the roles, states and motion the app already ships: the grammar below is a legal-combination table over existing roles, not a parallel token system (DG-09). <b>v2:</b> boards now resolve the effective default-slate cascade, not the top-of-file palette; this is a drawn specimen at those values, not a pixel baseline. Tags: <span class="tag live">live</span> = wired today · <span class="tag sample">sample</span> = design sample, backend gap listed · <span class="tag spec">specimen</span> = source-inferred, not run.</p>
      <div class="board-grid" style="grid-template-columns:1fr 1fr">${depth(false)}${depth(true)}</div>
      <div class="board-grid" style="grid-template-columns:1fr"><div class="cell"><h3>DG-09 · Surface / State / Color / Type / Material / Shape / Motion / Icons — legal combinations</h3>${grammar}</div></div>
    </div>`,
  });

  page({
    file: `${out}/MainPlan.dc.html`, title: 'Return plan · ruled mapping', width: 1440, height: 760,
    body: `<div class="board"><div class="eyebrow">Companion to the system board · v3: items map to the existing DG / DR contracts; the v1 "open disagreements" are ruled and kept only as history</div><h1 class="board-title" style="margin-top:8px">Where each item lives now.</h1>
      <div class="board-grid" style="grid-template-columns:1fr 1fr 1fr">
        <div class="cell"><h3>v1 "Suggested PR order" → ruled mapping (DR-01…06, return-intake.md)</h3><p class="form-help">Historical list kept verbatim below; the active queue is DR-01 → DR-02 → DR-03 → DR-04, DR-05 isolated, DR-06 after copy rewrite.</p><ol style="padding-left:18px;font-size:12px;line-height:1.7;margin:6px 0 0">
          <li><b>DG-09</b> grammar table into <span class="k">engineering/design/atlas</span> (docs only, no CSS)</li>
          <li><b>DG-01</b> two glyph source SVGs + manifest rows + sprite regen (asset PR); then <span class="k">nav.spark</span> / <span class="k">nav.attention</span> semantic slots switch from text-reserved to glyph+text</li>
          <li><b>DG-06/07</b> header pair: three-line summary donor for Chat overview (real Lucide filename + hash at vendoring); work-surface control keeps its disclosure semantics (<span class="k">aria-expanded</span> / <span class="k">aria-controls</span>, names Open / Hide / Collapse)</li>
          <li><b>DG-02</b> Spark: state copy + snapshot-conflict + narrow layout (read-only); rebuild stays sample until BE-4x</li>
          <li><b>DG-03</b> Attention: receipt / uncertain / conflict states already live — visual parity pass only</li>
          <li><b>DG-04</b> composer timeline as a source-inferred specimen: each motion bound to a real host state and an interrupt path; not CSS-only, not wired by this return</li>
          <li><b>DG-05</b> Explore: sample adapter behind a flag; backend gap registered</li>
          <li><b>DG-08</b> Pages: Home story revision with before/after; media stays f137</li></ol></div>
        <div class="cell"><h3>What this return does not claim</h3><ul style="padding-left:18px;font-size:12px;line-height:1.7;margin:6px 0 0">
          <li>No acceptance by Astra, no merge, no gate closed.</li><li>No VoiceOver, IME, forced-colors emulation or true 200% zoom was run: those rows read <i>unverified</i>.</li><li>Glyph optical checks are source-inferred; Spark A reads flat at 16 next to house/activity (Astra) — A2 is offered for DR-02, blur test not run.</li><li>Rebuild / recover, Explore lifecycle, read-aloud, feedback, fork, share, pin, download remain capability gaps; drawn only as samples.</li><li>f137 captures are not relabelled; every scene here is a drawn specimen at 1440×900 / 390×844.</li></ul></div>
        <div class="cell"><h3>v1 disagreements — all ruled 2026-09-11 (history, not reopened)</h3><ul style="padding-left:18px;font-size:12px;line-height:1.7;margin:6px 0 0">
          <li><b>Spark glyph A vs B</b> — ruled: A, canonical only after DR-02 optics. A2 (taller source block, wider spread) is the v2 optical candidate.</li><li><b>Header pair</b> — donor glyph for overview (recommended) vs folding overview into the work surface as a tab (bigger scope).</li><li><b>Attention item open-state</b> — ruled: keep the current float row; it <i>is</i> a selection (v1 reasoning withdrawn).</li><li><b>Pages hero</b> — no change proposed; the story section gains a static "after" frame only.</li></ul></div>
      </div>
    </div>`,
  });

  // ── Icons: DG-01 glyph board ────────────────────────────────────────────────
  const sizes = [16, 18, 20, 24];
  const row = (name, label, note, tagHtml) => `
    <div style="display:grid;grid-template-columns:200px 1fr 1fr 1fr 1fr;gap:12px;align-items:center;padding:12px 0;border-bottom:1px solid var(--line)">
      <div><div style="font-weight:600;font-size:13px;display:flex;gap:8px;align-items:center">${label} ${tagHtml || ''}</div><div class="form-help">${note}</div></div>
      <div style="display:flex;gap:18px;align-items:center;background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:10px 14px">${sizes.map(s => `<span style="display:inline-flex;flex-direction:column;align-items:center;gap:4px;color:var(--ink)">${icon(name, s)}<span class="k" style="color:var(--muted-strong)">${s}</span></span>`).join('')}</div>
      <div class="dark" style="display:flex;gap:18px;align-items:center;background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:10px 14px;color:var(--ink)">${sizes.map(s => `<span style="display:inline-flex;flex-direction:column;align-items:center;gap:4px">${icon(name, s)}<span class="k" style="color:var(--muted-strong)">${s}</span></span>`).join('')}</div>
      <div style="display:flex;gap:18px;align-items:center;background:#fff;border:1px solid #000;border-radius:0;padding:10px 14px;color:#000">${sizes.map(s => `<span style="display:inline-flex;flex-direction:column;align-items:center;gap:4px">${icon(name, s)}<span class="k">${s}</span></span>`).join('')}</div>
      <div style="display:flex;gap:10px;align-items:center;background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:10px 14px;color:var(--ink)">${icon('house', 16)}${icon(name, 16)}${icon('activity', 16)}${icon('panel-right', 16)}<span class="form-help" style="margin-left:6px">neighbours at 16</span></div>
    </div>`;

  page({
    file: `${out}/Icons.dc.html`, title: 'Spark & Attention glyphs', width: 1440, height: 2280,
    body: `<div class="board">
      <div class="eyebrow">DG-01 · P0 · native identification for the two reopened slots · input: SE-10 (Lucide 1.41.0 subset), IC-6 canonical geometry, WK-163 D, user reopening 2026-09-11</div>
      <h1 class="board-title" style="margin-top:8px">Two glyphs, one reading direction.</h1>
      <p class="board-lede"><b>Principle.</b> Spark's question is "what derives from this source and is it still current?"; Attention's is "which of the things in motion needs attention?". Both glyphs read left → right: <b>Spark</b> is one source block fanning into derivations; <b>Attention</b> is streams of work, one of which crosses to the ring where judgment converges. Counts are abstract (not three derivations, not three streams). Neither carries a state, a badge or a permission — the word next to it does (SE-01, IC-1). Geometry: 24 grid, 2px stroke, round cap/join, 1px safe edge, bbox 18×10–12 (ratio ≈ 0.69, the Lucide median WK-163 measured). Text stays: the nav row is glyph + "Spark" / "Attention"; the accessible name is unchanged.</p>
      <div style="display:grid;grid-template-columns:200px 1fr 1fr 1fr 1fr;gap:12px;margin-top:24px;padding-bottom:6px;border-bottom:1px solid var(--line-strong)"><div class="eyebrow">Candidate</div><div class="eyebrow">Light · 16 / 18 / 20 / 24</div><div class="eyebrow">Dark</div><div class="eyebrow">Single colour · hand-drawn, not a forced-colors run</div><div class="eyebrow">Optical match · Lucide neighbours</div></div>
      ${row('spark-a', 'Spark A · Fan-out', 'One source (rect 6×6) → wire → spine → three derivations. Reads "derived from" at 16; no collision with git-branch (nodes+curve) or share-2 (three circles).', '<span class="tag rec">recommended</span>')}
      ${row('spark-a2', 'Spark A2 · Fan-out, optical revision', 'Same construction as A with a taller source block (6×8) and derivations at 5 / 12 / 19: bbox 18×14 instead of 18×10, so at 16 it no longer reads flatter than house / activity beside it. Offered for DR-02; geometry stays Astra\'s to fix.', '<span class="tag">v2 candidate for DR-02</span>')}
      ${row('spark-b', 'Spark B · Revision ladder', 'A rising step line: revision 1 → 2 → 3, ending in the current point. Says "behind by" well, says "sources" less well; can read as chart at 16.', '<span class="tag">alternate</span>')}
      ${row('spark-c', 'Spark C · Strike', 'A flint stroke meeting an arc with rays. Literal spark, but the ray cluster is optically a sparkle/wand — the borrowed AI mark the packet forbids.', '<span class="tag sample">rejected · anti-example</span>')}
      ${row('attn-a', 'Attention A · Stream to ring', 'Streams of work (an abstract count, not three of anything); one continues across into a ring — the object of attention where judgment converges, not a claim that a person must act. Ring r=4 keeps a 2px inner at 16.', '<span class="tag rec">recommended</span>')}
      ${row('attn-b', 'Attention B · Lifted item', 'A three-line list whose middle line is lifted and marked. Says "one item needs you" but competes with Lucide list/menu at 16.', '<span class="tag">alternate</span>')}
      ${row('attn-c', 'Attention C · Eye', 'Eye + pupil. Semantic collision: visibility / show-password / watch; implies surveillance, not judgment.', '<span class="tag sample">rejected · collision</span>')}
      ${row('bell', 'Not this · bell', 'Generic notification/alarm. Attention is a queue of human decisions, not an alert (SE proposition §1).', '<span class="tag sample">rejected</span>')}
      ${row('sparkles', 'Not this · sparkles', 'Generic AI mark. Spark is source-maintenance, not generation; the glyph would claim a capability the surface does not have.', '<span class="tag sample">rejected</span>')}

      <div class="board-grid" style="grid-template-columns:1fr 1fr 1fr">
        <div class="cell"><h3>In place · nav (20) and title (18)</h3>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:8px">
            <div style="background:var(--frame);border:1px solid var(--line);border-radius:8px;padding:8px"><div class="eyebrow" style="margin:0 0 6px 8px">Recommended</div>
              <button type="button" class="nav-home quiet-button">${icon('house',16)}<span>Home</span></button>
              <button type="button" class="nav-home quiet-button" style="margin-top:4px">${icon('attn-a',16)}<span>Attention</span></button>
              <button type="button" class="nav-home quiet-button" style="margin-top:4px" aria-current="page">${icon('spark-a',16)}<span>Spark</span></button></div>
            <div style="background:var(--frame);border:1px solid var(--line);border-radius:8px;padding:8px"><div class="eyebrow" style="margin:0 0 6px 8px">Baseline · text-reserved (current)</div>
              <button type="button" class="nav-home quiet-button">${icon('house',16)}<span>Home</span></button>
              <button type="button" class="nav-home quiet-button" style="margin-top:4px"><span>Attention</span></button>
              <button type="button" class="nav-home quiet-button" style="margin-top:4px" aria-current="page"><span>Spark</span></button></div>
          </div>
          <div style="display:flex;gap:24px;margin-top:14px;align-items:center"><span class="spark-header" style="gap:8px"><span class="dialog-title">${icon('spark-a',18)}Spark</span></span><span class="dialog-title">${icon('attn-a',18)}Attention</span><span class="form-help">dialog titles, 18</span></div>
          <p class="why">Glyph sits before the word in the row (IC-1: icon + text for navigation). The baseline stays valid as a fallback: if Astra defers DG-01, nothing else in this return depends on the glyphs.</p></div>
        <div class="cell"><h3>Semantic collision ledger</h3>
          <table class="spec"><tr><th>Glyph</th><th>Nearest existing</th><th>Why distinct</th></tr>
          <tr><td>spark-a</td><td>git-branch · share-2 · settings-2</td><td>filled-corner block + straight spine; no circles, no curve</td></tr>
          <tr><td>spark-a</td><td>panel-right</td><td>open right side; no enclosing frame</td></tr>
          <tr><td>attn-a</td><td>activity · search</td><td>ring is right-anchored and entered by a line; no pulse, no handle</td></tr>
          <tr><td>attn-a</td><td>ellipsis</td><td>lines, not dots; ring is 8px wide at 24</td></tr>
          <tr><td>text (donor)</td><td>panel-right</td><td>three lines, no frame — the point of the header pair fix</td></tr></table>
          <p class="why">Construction source: hand-drawn path data on the Lucide 24 grid (this file). Licence: Courtwork-owned; Lucide ISC applies only to the donor rows. Manifest rows: <span class="k">spark.svg</span>, <span class="k">attention.svg</span> under a <span class="k">courtwork</span> block, not under <span class="k">lucide.files</span>.</p></div>
        <div class="cell"><h3>Verification account</h3>
          <table class="spec"><tr><th>Check</th><th>Status</th></tr>
          <tr><td>bbox vs Lucide neighbours</td><td>A: 18×10 (reads flat at 16, Astra visual review) · A2: 18×14 · attn-a: 18×10 with an 8px ring · <i>source-inferred</i></td></tr>
          <tr><td>16px legibility</td><td>rendered on this board at 16/18/20/24 in light, dark, mono · <i>executed (canvas)</i></td></tr>
          <tr><td>Circle/square blur test (IC-6)</td><td><i>unverified</i> — needs the icon specimen page at 8px blur</td></tr>
          <tr><td>forced-colors</td><td>currentColor only, no fills → CanvasText · <i>source-inferred</i></td></tr>
          <tr><td>VoiceOver name</td><td>unchanged ("Spark", "Attention"); glyph aria-hidden · <i>unverified on device</i></td></tr>
          <tr><td>200% zoom</td><td>SVG scales; hit area stays 32/44 · <i>unverified</i></td></tr></table>
          <p class="why">Taste Memory: A/B for each slot are <b>Open Taste</b> until the user or Astra chooses; C rows are <b>Exemplars (rejected)</b> with reasons kept.</p></div>
      </div>
    </div>`,
  });

  // ── HeaderPair: two adjacent panel-right (DG-06/07 input) ───────────────────
  const hdr = (leftGlyph, rightGlyph, rightOpen, label) => `
    <div class="main" style="border:1px solid var(--line);border-radius:8px;overflow:hidden">
      <div class="chat-header"><div class="chat-header-inner"><div class="chat-title-wrap"><h1>Source inspection</h1><span class="run-badge running"><span class="dot"></span>Running</span></div>
        <div class="chat-header-actions">${iconBtn(leftGlyph, 'Chat overview')}${iconBtn(rightGlyph, rightOpen ? 'Hide work surface' : 'Open work surface', 'quiet-button icon-only' + (rightOpen ? ' is-selected' : ''), 18, `aria-expanded="${rightOpen}" aria-controls="work-surface"`)}</div></div></div>
      <div class="form-help" style="padding:8px 24px">${label}</div>
    </div>`;
  page({
    file: `${out}/HeaderPair.dc.html`, title: 'Header pair: overview vs work surface', width: 1100, height: 720,
    body: `<div class="board">
      <div class="eyebrow">DG-06 / DG-07 input · user screenshot header-controls-user.png · app.mjs show-run-button (openContextSummary) and show-surface-button both take panel-right</div>
      <h1 class="board-title" style="margin-top:8px">Same shape, different object: split them by what they open.</h1>
      <p class="board-lede"><b>Chat overview</b> opens a transient popover summarising this chat's context (a reading of text). <b>Work surface</b> toggles a persistent L2 panel on the right (a place). Only the second one is a panel, so only the second one keeps <span class="k">panel-right</span>. The overview takes a same-family three-line donor at 18 (Lucide <span class="k">text</span>, filename and sha to be confirmed at vendoring; <span class="k">align-left</span> is the fallback) — a summary, not a place. The work-surface control keeps its real disclosure semantics: <span class="k">aria-expanded</span> mirrors the actual panel, <span class="k">aria-controls</span> names it, and the accessible name follows Open / Hide / Collapse as it already does; the open state may additionally paint <span class="k">--selected</span>. The overview is a one-shot opener and stays stateless.</p>
      <div class="board-grid" style="grid-template-columns:1fr 1fr">
        <div><div class="eyebrow" style="margin-bottom:8px">Current · two panel-right, label-only difference</div>${hdr('panel-right', 'panel-right', false, 'aria-label differs ("Chat overview" / "Open work surface"); visually identical; no open state')}</div>
        <div><div class="eyebrow" style="margin-bottom:8px">Recommended · text + panel-right, surface open</div>${hdr('text', 'panel-right', true, 'overview = three-line summary glyph; surface = panel-right, aria-expanded=true while the panel is open, name Hide work surface')}</div>
      </div>
      <div class="board-grid" style="grid-template-columns:1fr 1fr 1fr">
        <div class="cell"><h3>Alternative B · fold overview into the surface</h3><p class="why">Overview becomes the first tab of the work surface; one control remains. Cleaner header, but it changes navigation scope (SE-04 composition, WK-113 tab contract) and makes the summary unreachable while the surface is collapsed on 1024–1679. Not recommended this round; listed for Astra.</p></div>
        <div class="cell"><h3>Alternative C · text label beside the glyph</h3><p class="why">"Overview" as a visible word next to the glyph. Solves the pair, but the 48px band already holds the title + run word; on 1280 the label ellipsizes first. Keep as the narrow fallback only if the donor is refused.</p></div>
        <div class="cell"><h3>Wiring boundary</h3><p class="why">The donor is a new manifest row under the pinned Lucide commit; its real filename and sha are recorded at vendoring — <i>not fetched here, and not present in the current sprite</i>. Semantic keys stay; the surface control changes no handler: its aria follows the disclosure it already toggles.</p></div>
      </div>
    </div>`,
  });
}
