// Render harness: embeds each candidate SVG with the site's own .fig CSS and
// campaign palette (site/src/site.css @ 3f5daf4), light and dark, then
// screenshots with headless Chrome. Author render only; not independent acceptance.
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const FIG_CSS = `
.fig text { fill: currentColor; }
.fig .fig-th { font-weight: 600; }
.fig .fig-muted { fill: var(--muted-strong); }
.fig .fig-label { font-family: var(--font-mono); letter-spacing: .06em; fill: var(--muted-strong); }
.fig .fig-node { fill: var(--campaign-raised); stroke: currentColor; stroke-width: 1; }
.fig .fig-centre, .fig .fig-engaged { stroke-width: 2; }
.fig .fig-set { fill: var(--campaign-soft); stroke-width: 1.5; }
.fig .fig-stock { fill: var(--campaign-soft); stroke: currentColor; stroke-width: 1; }
.fig .fig-candidate, .fig .fig-derived { fill: none; stroke: currentColor; stroke-width: 1; stroke-dasharray: 4 3; }
.fig .fig-exiting, .fig .fig-slot, .fig .fig-quiet { fill: none; stroke: var(--muted); stroke-width: 1; }
.fig .fig-slot { stroke-dasharray: 4 3; }
.fig .fig-edge { fill: none; stroke: currentColor; stroke-width: 1.5; }
.fig .fig-trace { fill: none; stroke: currentColor; stroke-width: 1; stroke-dasharray: 2 3; }
.fig .fig-rule { stroke: var(--campaign-rule); stroke-width: 1; }
.fig .fig-threshold { stroke: currentColor; stroke-dasharray: 6 4; }
.fig .fig-attention { fill: var(--campaign-attention-review); }
@media (forced-colors: active) {
  .fig { color: CanvasText; }
  .fig text, .fig .fig-muted, .fig .fig-label { fill: CanvasText; }
  .fig .fig-node, .fig .fig-set, .fig .fig-stock { fill: Canvas; stroke: CanvasText; }
  .fig .fig-candidate, .fig .fig-derived, .fig .fig-exiting, .fig .fig-slot, .fig .fig-quiet,
  .fig .fig-strata, .fig .fig-edge, .fig .fig-trace, .fig .fig-rule, .fig .fig-threshold { stroke: CanvasText; }
  .fig .fig-attention { fill: CanvasText; }
}`;
const THEMES = {
  light: `--campaign-paper:#f4f5f6;--campaign-raised:#ffffff;--campaign-ink:#282b2d;--campaign-soft:#e1e5e8;--campaign-rule:#a7aeb2;--campaign-attention-review:#b3262d;--ink:#282b2d;--muted-strong:#54616a;--muted:#7e8d96;--frame:#f4f5f6;`,
  dark: `--campaign-paper:#202224;--campaign-raised:#303335;--campaign-ink:#eef0f2;--campaign-soft:#272b2e;--campaign-rule:#62696e;--campaign-attention-review:#ed9396;--ink:#eef0f2;--muted-strong:#b2c1ca;--muted:#82939d;--frame:#202224;`,
};
const figs = ['F1-ownership', 'F2-compile-commit', 'F3-runtime-anatomy', 'F5-expert-composition'];
mkdirSync('png', { recursive: true }); mkdirSync('html', { recursive: true });
const receipts = [];
for (const f of figs) {
  const svg = readFileSync(`svg/${f}.svg`, 'utf8');
  const vb = svg.match(/viewBox="0 0 (\d+) (\d+)"/); const [w, h] = [Number(vb[1]), Number(vb[2])];
  for (const [theme, vars] of Object.entries(THEMES)) {
    for (const width of [1440, 390]) {
      const plate = width >= 720 ? `max-width:${Math.min(w, 960)}px` : 'min-width:720px';
      const html = `<!doctype html><html><head><meta charset="utf-8"><style>
:root{${vars}--font-mono:ui-monospace,SFMono-Regular,Menlo,monospace}
html,body{margin:0;background:var(--campaign-paper);color:var(--ink);font:15px/1.6 ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif}
.figure{margin:0;padding:24px;overflow-x:auto}
.figure svg.fig{display:block;width:100%;height:auto;color:var(--ink);font-family:inherit;${plate}}
${FIG_CSS}</style></head><body><figure class="figure figure-plate">${svg}</figure></body></html>`;
      const file = `html/${f}-${theme}-${width}.html`; writeFileSync(file, html);
      const scale = width >= 720 ? Math.min(w, 960) / w : 720 / w;
      const height = Math.ceil(h * scale) + 48 + 16;
      const out = `png/${f}-${width}-${theme}.png`;
      execFileSync(CHROME, ['--headless=new', '--hide-scrollbars', '--disable-gpu', '--force-device-scale-factor=2', `--window-size=${width},${height}`, `--screenshot=${out}`, `file://${process.cwd()}/${file}`], { stdio: 'ignore' });
      receipts.push({ figure: f, theme, viewport: width, window: [width, height], file: out, viewBox: [w, h], dpr: 2 });
    }
  }
}
writeFileSync('png/render-receipt.json', JSON.stringify({ chrome: 'Google Chrome.app headless (new)', at: new Date().toISOString(), css: 'site/src/site.css .fig rules @3f5daf4 (copied into harness)', receipts }, null, 2));
console.log(receipts.map(r => r.file).join('\n'));
