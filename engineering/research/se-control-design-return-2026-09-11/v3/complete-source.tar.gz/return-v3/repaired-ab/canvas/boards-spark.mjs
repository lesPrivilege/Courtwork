import { page, icon, iconBtn, sidebar } from './shared.mjs';

const homeBehind = () => `
  <div class="main">
    <div class="chat-header" style="border-bottom:0"><div class="chat-header-inner"><div class="chat-title-wrap"></div></div></div>
    <div style="max-width:var(--home-column);margin:24px auto 0;width:100%;display:grid;grid-template-columns:1fr 1fr;gap:24px">
      <div class="home-card home-attention"><div style="display:flex;justify-content:space-between;align-items:center"><span class="home-card-title">${icon('attn-a',16)}Attention items</span><select style="width:180px"><option>Project Cedar review</option></select></div><div class="form-help" style="margin-top:6px">1 item · all states</div>
        <div class="home-attention-item" style="background:var(--panel-muted)"><span><b style="font-weight:500">Review Project Cedar source change</b><br><span class="form-help">The source-backed review needs human inspection after a sou…</span><br><span class="form-help">Next · Inspect refreshed sources</span></span><span class="home-attention-state" style="border:1px solid var(--line);border-radius:4px;padding:2px 6px">Investigating</span>${icon('chevron-right',14)}</div></div>
      <div class="home-card"><div style="display:flex;justify-content:space-between;align-items:center"><span class="home-card-title">${icon('activity',16)}Activity</span><span class="segmented" style="width:auto;display:inline-grid"><span class="segment">28d</span><span class="segment on">84d</span></span></div><div style="margin-top:10px"><span style="font-size:22px;font-weight:600">5</span> <span class="form-help">recorded runs · 84 days · all retained work</span></div>
        <div style="display:grid;grid-template-columns:repeat(13,1fr);gap:3px;margin-top:12px">${Array.from({length:91},(_, i)=>`<span style="height:8px;border-radius:2px;background:${i===82?'var(--line-strong)':'var(--panel)'};border:1px solid var(--line)"></span>`).join('')}</div>
        <div class="form-help" style="margin-top:12px">2026-06-20 — 2026-09-11<br>UTC · Retained runs only. Deleted-chat history is unknown.</div></div>
    </div>
  </div>`;

const matter = ({ title, rev, stale, total, chips = [], change, quiet = false, unavailable = null, readOnly = false }) => `
  <div class="spark-matter-row${quiet ? ' is-quiet' : ''}${unavailable ? ' is-unavailable' : ''}">
    ${readOnly ? `<span class="spark-matter-open">${title}</span>` : `<button type="button" class="spark-matter-open" aria-label="Open ${title} in Work">${title}</button>`}
    <div class="spark-matter-meta">${unavailable ? `<span class="spark-unavailable">Unavailable · ${unavailable}</span>` : `<span>Source revision ${rev}</span><span>${quiet ? `${total} current, none stale` : `${stale} stale of ${total}`}</span>`}</div>
    ${chips.length ? `<div class="spark-chip-row">${chips.map(c => `<span class="spark-chip">${c}</span>`).join('')}</div>` : ''}
    ${unavailable ? '' : `<p class="form-help spark-source-change">${change}</p>`}
  </div>`;

const dialog = ({ tab = 'overview', body, controls = true, sample = false, width = 880, glyph = true }) => `
  <div class="spark-dialog" style="width:${width}px" role="dialog" aria-labelledby="spark-title">
    <header class="spark-header"><div><h2 id="spark-title" class="dialog-title">${glyph ? icon('spark-a', 18) : ''}Spark</h2><p class="form-help">See which Matters need updating after their sources change.</p></div>${iconBtn('x', 'Close Spark', 'quiet-button icon-only', 18)}</header>
    ${controls ? `<div class="spark-controls"><select style="width:auto"><option>Project Cedar review</option></select>${sample ? '' : '<button type="button" class="text-button">Refresh</button>'}</div>` : ''}
    <div class="spark-tabs" role="tablist" aria-label="Spark view"><button type="button" role="tab" aria-selected="${tab === 'overview'}">Overview</button><button type="button" role="tab" aria-selected="${tab === 'activity'}">Activity</button></div>
    <section role="tabpanel">${body}</section>
  </div>`;

export function buildSpark(out) {
  // ── SparkOverview (light, 1440) — real stale fixture content ─────────────────
  const overviewBody = `
    <p class="form-help" style="margin-top:12px">As of 2026-09-11T04:13:20.424Z</p>
    <h3 class="spark-section-heading">Behind the current source set</h3>
    ${matter({ title: 'Acme inbound NDA', rev: 3, stale: 2, total: 5, chips: ['Pending · 2 stale / 1 current'], change: 'Revision 2 → 3 · 1 added, 1 replaced' })}
    <h3 class="spark-section-heading">Unavailable</h3>
    ${matter({ title: 'Northside ledger memo', unavailable: 'contract_unsupported' })}
    <h3 class="spark-section-heading is-quiet">Up to date</h3>
    ${matter({ title: 'Acme employment agreement', rev: 2, total: 3, quiet: true, change: 'No prior source revision recorded.' })}`;
  page({
    file: `${out}/SparkOverview.dc.html`, title: 'Spark · Overview · light 1440', width: 1440, height: 900,
    body: `<div class="app-shell" style="height:900px">${sidebar({ current: 'home', sparkGlyph: 'spark-a', attnGlyph: 'attn-a' })}${homeBehind()}<div class="dialog-scrim"></div>${dialog({ body: overviewBody })}</div>`,
  });

  // ── SparkActivityDark (dark, 1440) — Activity tab with filters + table ───────
  const activityBody = `
    <div class="spark-controls"><select style="width:auto"><option>All Matters</option></select><select style="width:auto"><option>Pending</option></select></div>
    <p class="form-help">As of 2026-09-11T04:13:20.424Z</p>
    <section style="margin:20px 0"><button type="button" class="spark-matter-open">Acme inbound NDA</button>
      <table class="spark-table" style="margin-top:8px"><thead><tr><th scope="col">Candidate</th><th scope="col">Status</th><th scope="col">Candidate revision</th><th scope="col">Behind by</th><th scope="col">Supersedes</th></tr></thead>
      <tbody><tr><td>c-9</td><td>Pending</td><td>1 of 3</td><td>2</td><td>—</td></tr><tr><td>c-10</td><td>Pending</td><td>2 of 3</td><td>1</td><td>c-9</td></tr></tbody></table></section>
`;
  page({
    file: `${out}/SparkActivityDark.dc.html`, title: 'Spark · Activity · dark 1440', width: 1440, height: 964, dark: true,
    body: `<div class="app-shell" style="height:900px">${sidebar({ current: 'home', sparkGlyph: 'spark-a', attnGlyph: 'attn-a' })}${homeBehind()}<div class="dialog-scrim"></div>${dialog({ tab: 'activity', body: activityBody })}</div><div class="annot"><b>Specimen notes.</b> Refresh re-reads the page at the runtime's current state; it does not rebuild a candidate, and Rebuild is not a control on this baseline (see the sample board). Dark roles: effective default-slate cascade (#222627 paper, #2e3335 raised, #1c2021 sunken).</div>`,
  });

  // ── SparkStates matrix ───────────────────────────────────────────────────────
  const mini = (title, tagHtml, inner, note) => `<div class="cell" style="padding:0;overflow:hidden"><div style="padding:10px 14px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0">${title}</h3>${tagHtml}</div><div style="padding:14px;min-height:150px;background:var(--panel)">${inner}</div><div class="why" style="padding:10px 14px;border-top:1px solid var(--line);margin:0">${note}</div></div>`;
  const tabsMini = `<div class="spark-tabs"><button type="button" aria-selected="true">Overview</button><button type="button" aria-selected="false">Activity</button></div>`;
  page({
    file: `${out}/SparkStates.dc.html`, title: 'Spark · state matrix', width: 1440, height: 1420,
    body: `<div class="board">
      <div class="eyebrow">DG-02 · Spark control surface · states the projection actually produces (spark-projection.mjs / spark-view.mjs) · every state is a word, never a colour or a spinner</div>
      <h1 class="board-title" style="margin-top:8px">Empty, loading, partial, unknown, error, conflict — each with its exit.</h1>
      <div class="board-grid" style="grid-template-columns:1fr 1fr 1fr">
        ${mini('Loading', '<span class="tag live">live</span>', `${tabsMini}<p style="margin-top:14px" role="status">Loading maintenance state…</p>`, 'Text only, role=status. No skeleton, no shimmer (L1 motion boundary). Refresh disabled while loading.')}
        ${mini('No source yet', '<span class="tag live">live</span>', `${tabsMini}<p style="margin-top:14px" role="status">No source yet. This runtime has no maintenance source connected here.</p><button type="button" class="text-button" style="margin-top:6px">Show sample data</button>`, '404 = unimplemented. The sample entry lives inside this sentence and nowhere else (SD-14).')}
        ${mini('Sample data', '<span class="tag sample">sample</span>', `${tabsMini}<div class="spark-controls"><span class="form-help">Sample data</span><select style="width:auto"><option>Stale</option></select><button type="button" class="text-button">Check for a source again</button><button type="button" class="text-button">Hide sample data</button></div><p class="form-help">As of 2026-09-10T12:34:56.000Z</p>${matter({ title: 'Acme inbound NDA', rev: 3, stale: 2, total: 5, change: 'Revision 2 → 3 · 1 added, 1 replaced', readOnly: true })}`, 'Grey label, no icon, no colour (SD-17). Rows are inert text; nothing navigates (SD-19).')}
        ${mini('Empty scope', '<span class="tag live">live</span>', `${tabsMini}<p class="form-help" style="margin-top:14px">As of 2026-09-11T04:13:20.424Z</p><p class="form-help">No Matters in this project’s scope.</p>`, 'Empty ≠ quiet ≠ unknown: three different sentences.')}
        ${mini('Quiet (all current)', '<span class="tag live">live</span>', `${tabsMini}<h3 class="spark-section-heading is-quiet">Up to date</h3>${matter({ title: 'Acme employment agreement', rev: 2, total: 3, quiet: true, change: 'No prior source revision recorded.' })}<p class="form-help" style="margin-top:8px">Every Matter in scope is current with its source set. No prompt is generated for a quiet read.</p>`, 'Quiet rows: weight 400, no chip, no mark. A quiet read never becomes an Attention item (SP-11).')}
        ${mini('Partial coverage', '<span class="tag live">live</span>', `${tabsMini}<p class="form-help" style="margin-top:14px">As of 2026-09-10T12:34:56.000Z · scope partial: contract_unsupported_excluded</p>${matter({ title: 'Northside ledger memo', unavailable: 'contract_unsupported' })}`, 'Reasons are the machine-readable values the DTO and the partial.json fixture carry (contract_unsupported; coverage reason contract_unsupported_excluded). Unavailable rows: dotted outline, italic reason, counts null — never 0. BE-41 asks nothing about producers or sessions.')}
        ${mini('Truncated stale list', '<span class="tag live">live</span>', `${tabsMini}${matter({ title: 'Acme inbound NDA', rev: 9, stale: 27, total: 31, change: 'Revision 8 → 9 · 4 replaced' })}<p class="form-help" style="margin-top:8px">Showing the first 20 stale candidates. The remaining stale candidates for this Matter are not loaded on this page.</p>`, 'Page ceiling 20 (be41-dto). The note is the only affordance; no "load more" is invented without a contract.')}
        ${mini('Error', '<span class="tag live">live</span>', `${tabsMini}<p style="margin-top:14px;color:var(--danger)" role="alert">Spark could not read maintenance state.</p><button type="button" class="text-button">Retry</button>`, 'Danger colour on text only. Retry replays the same query with the same expected snapshot.')}
        ${mini('Snapshot moved (409)', '<span class="tag live">live</span>', `${tabsMini}<p style="margin-top:14px" role="alert">This runtime’s maintenance state moved on since the last page. Refresh to read it again; the two pages are not shown together.</p><button type="button" class="text-button">Refresh</button>`, 'Old request late / paging across a changed state: the page is dropped, not merged. Neutral colour: this is not a failure.')}
      </div>
      <div class="board-grid" style="grid-template-columns:1fr 1fr">
        <div class="cell"><h3>Keyboard · focus · return path</h3><p class="why">Dialog opens from the nav row and returns focus to it on close (opener restore, already wired). Tabs: manual activation, ←/→/Home/End, roving tabindex. Re-render keeps focus by <span class="k">data-spark-focus</span> key; if the focused control disappears, focus lands on Close Spark. Project switch resets both filters and drops sample. Escape closes.</p></div>
        <div class="cell"><h3>Not wired · listed, not drawn as live</h3><p class="why">Rebuild / recover a stale candidate; open a stale candidate directly (only the Matter opens in Work); diff of a replaced source; per-candidate history. Each needs a BE contract before a control exists (SE-02). The one candidate anatomy is on SparkRebuild, marked sample.</p></div>
      </div>
    </div>`,
  });

  // ── SparkRebuild: candidate anatomy (sample adapter) ─────────────────────────
  page({
    file: `${out}/SparkRebuild.dc.html`, title: 'Spark · rebuild candidate (sample)', width: 1440, height: 820,
    body: `<div class="board">
      <div class="eyebrow">DG-02 · rebuild control · <span class="tag sample">sample adapter</span> · no production wiring · required backend listed</div>
      <h1 class="board-title" style="margin-top:8px">Refresh reads. Rebuild would write. They cannot share a button.</h1>
      <p class="board-lede">If a rebuild capability arrives, it belongs on the stale candidate row in Activity, bound to <b>one candidate at one source revision</b>, with the same request-identity / expected-revision / receipt protocol Attention already uses. It is a governed action: a reason, a visible target, a receipt, never optimistic.</p>
      <div class="board-grid" style="grid-template-columns:1.2fr 1fr">
        <div class="cell" style="padding:0;overflow:hidden"><div style="padding:10px 14px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between"><h3 style="margin:0">Activity row with a rebuild candidate — every control inert</h3><span class="tag sample">sample · no handler exists</span></div>
          <div style="padding:16px;background:var(--panel)">
            <button type="button" class="spark-matter-open">Acme inbound NDA</button>
            <table class="spark-table" style="margin-top:8px"><thead><tr><th>Candidate</th><th>Status</th><th>Candidate revision</th><th>Behind by</th><th>Supersedes</th><th></th></tr></thead>
            <tbody><tr><td>c-9</td><td>Pending</td><td>1 of 3</td><td>2</td><td>—</td><td><button type="button" class="text-button" aria-disabled="true" aria-expanded="true">Rebuild <span class="tag sample">sample</span></button></td></tr>
            <tr><td>c-10</td><td>Pending</td><td>2 of 3</td><td>1</td><td>c-9</td><td><button type="button" class="text-button" aria-disabled="true">Rebuild <span class="tag sample">sample</span></button></td></tr></tbody></table>
            <div class="attention-action-editor" style="margin-top:12px"><fieldset><legend>Rebuild c-9 against source revision 3</legend>
              <label class="attention-field"><span class="attention-field-label">Reason</span><textarea rows="2">Source s-1 moved 1 → 2; the purpose clause changed.</textarea></label>
              <p class="form-help">Creates a new candidate that supersedes c-9. c-9 stays recorded and pending. Nothing is accepted by rebuilding.</p>
              <div style="display:flex;gap:8px"><button type="button" class="primary-button" aria-label="Rebuild · c-9" aria-disabled="true">Rebuild</button><button type="button" class="quiet-button">Cancel</button></div></fieldset></div>
            <p class="chat-action-status" style="margin-top:10px">Sending… Nothing changes until the receipt is read.</p>
          </div></div>
        <div class="cell"><h3>Required backend (gap register)</h3><table class="spec">
          <tr><th>Need</th><th>Owner / contract</th></tr>
          <tr><td>advertise</td><td>candidate advertises <span class="k">rebuild</span> with <span class="k">expected_revision</span> (like Attention typed actions)</td></tr>
          <tr><td>request</td><td>a write contract defined by the owner — request identity, reason, target source revision; no route or DTO is proposed here</td></tr>
          <tr><td>receipt</td><td>new candidateId + supersedes link; 409 on revision conflict; query by request_id for uncertain transport</td></tr>
          <tr><td>projection</td><td>BE-41 page shows the superseding candidate as current, old one stays stale (already representable via <span class="k">supersedes</span>)</td></tr>
          <tr><td>governance</td><td>rebuild is not review acceptance; Review still binds candidate + source (SE-01)</td></tr></table>
          <p class="why" style="margin-top:10px">Until these exist, the Activity table stays read-only and Refresh keeps its current meaning (the read path already handles the 409 snapshot conflict). Rebuild appears on this board only; the Pages story names it as a proposed outcome, not a control.</p></div>
      </div>
    </div>`,
  });

  // ── SparkNarrow 390 ──────────────────────────────────────────────────────────
  page({
    file: `${out}/SparkNarrow.dc.html`, title: 'Spark · 390 narrow', width: 390, height: 930,
    body: `<div style="height:844px;background:var(--frame);position:relative">
      <div class="chat-header" style="padding:0 12px"><div class="chat-header-inner"><div class="chat-title-wrap">${iconBtn('panel-left','Open navigation')}<h1>Home</h1></div></div></div>
      <div class="dialog-scrim"></div>
      <div class="spark-dialog" style="width:366px;left:12px;top:16px;transform:none;padding:16px;max-height:812px;overflow:hidden">
        <header class="spark-header"><div><h2 class="dialog-title">${icon('spark-a',18)}Spark</h2><p class="form-help">See which Matters need updating after their sources change.</p></div>${iconBtn('x','Close Spark','quiet-button icon-only',18,'style="width:44px;min-width:44px;height:44px"')}</header>
        <div class="spark-controls" style="gap:6px"><select style="flex:1;min-width:0;height:44px"><option>Project Cedar review</option></select><button type="button" class="text-button" style="min-height:44px">Refresh</button></div>
        <div class="spark-tabs"><button type="button" aria-selected="true" style="min-height:44px">Overview</button><button type="button" aria-selected="false" style="min-height:44px">Activity</button></div>
        <p class="form-help" style="margin-top:12px">As of 2026-09-11T04:13:20.424Z</p>
        <h3 class="spark-section-heading">Behind the current source set</h3>
        ${matter({ title: 'Acme inbound NDA', rev: 3, stale: 2, total: 5, chips: ['Pending · 2 stale / 1 current'], change: 'Revision 2 → 3 · 1 added, 1 replaced' })}
        <h3 class="spark-section-heading">Unavailable</h3>
        ${matter({ title: 'Northside ledger memo', unavailable: 'contract_unsupported' })}
        <h3 class="spark-section-heading is-quiet">Up to date</h3>
        ${matter({ title: 'Acme employment agreement', rev: 2, total: 3, quiet: true, change: 'No prior source revision recorded.' })}
      </div>
    </div><div class="annot"><b>Specimen notes.</b> Activity's table scrolls horizontally inside the dialog; the first column stays 120 wide (existing rule). All targets ≥ 44. Static frame; the real 390 interaction is not verified here.</div>`,
  });
}
