# P2 · 候选怎样成为持续工作的正式结果 — three compositions, one fact set

Mount (proposal, not edited): `tour.html`, chapter JUDGE, after the `review` state and before SPECIALIZE — the place where the reader has just seen a pending candidate; the same figure can accompany `index.html#architecture` beside state-to-commit. Public copy for the mount is Astra's.

## Fixed claim and facts (identical in all three)

Governed work state (Matter v7: active artifact, obligations, sources at their revisions, decisions) is projected into a bounded context for one run (selected versions, s-1 @ rev 2, contract); with requirements and permissions this is the frozen run input. Execution produces two different things: run observations, which stay with the host runtime owner as a record and are not work facts, and a candidate c-11 bound to source revision 3. The candidate becomes the work only after validation, evidence and an authority decision — the drawn instance: a person accepts this version with a reason and a request id bound to the content — which the Work Core commits in one transaction: artifact created, version 7 → 8, obligations updated, decision + receipt recorded; c-9 / c-10 remain stale. The next run projects from v8. The compiler is not on the decision path; run control and events belong to the host runtime owner. "Compile" here is context compilation (M09), not the whole target Work Compiler.

| | P2-1 · Boundary and loop | P2-2 · Strata of one Matter | P2-3 · Sheets, beam, gate |
|---|---|---|---|
| expression | engineering: the loop drawn around one dashed boundary; candidate crosses upward only through the gate; observations stay below | product sequence: one object cut across — proposal (ephemeral) → candidate (bound) → decision layer → committed record; trace drawn beside, not inside | abstract: the record as a stack of sheets, a projection beam, a dashed sheet returned by the run, a gate with a person, the sheet landing solid on the stack |
| borrowed assets | state-to-commit loop and the repaired F2; pipeline's Run → Store return | fig-00 layered sheets; Review-section state words | archive-stack sheets, anatomy-instrument projection lines, attention.svg threshold |
| abstraction | low | medium | high |
| read order | counter-clockwise loop | top → bottom | stack → beam → run → gate → stack |
| red | none — a mechanism figure (Review · Authority is words) | one — the decision layer names the instance: a person accepts c-11 | one — at the gate, "a person decides" |
| static complete | yes | yes | yes |
| min display | 720 plate · compact 360 provided | same | same |
| motion (optional, not built) | none | none | the beam could draw on scroll (defocus, as the site already does for state-to-commit connectors); decline for v1 |
| files | svg/P2-1-boundary-loop.svg · -compact.svg | svg/P2-2-strata.svg · -compact.svg | svg/P2-3-sheets-gate.svg · -compact.svg |

## Recommendation

**P2-2 (strata).** The Tour reader has just seen a pending candidate; the strata answer "why isn't this the work yet, and what would make it so" in one vertical read, keep the trace visibly outside the record, and name the human instance without turning the whole loop into a human-gated process. P2-1 is the correct engineering view and should live beside state-to-commit in the architecture section rather than the Tour; P2-3 is the strongest match to the Hero's sheet language and is the fallback if the Tour wants imagery over anatomy.

## Author checks

As for P1: rendered 1440 / 390, light / dark; wide plates scroll at 390; compact variants are the 390 view; text-in-viewBox check in `../text-check.json`. Not run: site build, forced-colors, greyscale, VoiceOver, 200 %.
