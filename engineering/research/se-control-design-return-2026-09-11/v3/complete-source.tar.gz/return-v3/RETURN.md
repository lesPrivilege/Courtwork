# Claude · return-v3 · A/B repairs and Pages candidates P1 / P2

Date 2026-09-11. Dispatch: `engineering/release/fresh-claude-pages-2026-09-11/ONE-SHOT.md` @ `b7b7be8`. **Content input fixed at `bf7fa82abe4b1e02bc470ff077ef6aba52000654`**; actual checkout HEAD while authoring `b7b7be8fdd64261385978e3e41bcc1a9c63aeed1` (difference: the dispatch docs only; no product source drift observed — `app/`, `site/`, `docs/` identical between the two). Author: Claude (Fable) in its own scratchpad. Nothing here was written to the shared repository, to `app/`, `site/` or a deployment; nothing is accepted or published.

Local path: `<scratchpad>/return-v3/` (absolute path in the chat handover) and `Courtwork-SE-Design-return-v3-2026-09-11.zip` beside it. v1 / v2 archives untouched.

## 1 · A/B repairs — item-by-item receipt against the v2 receipt

| v2 receipt item | Done | Where |
|---|---|---|
| F1 label overflow, right-side balance | boxes widened to 300, copy shortened, right column carries a MATURITY block | repaired-ab/figures/svg/F1-ownership.svg |
| F1 merged return edge (trace vs candidates) | split: candidates → Core via extension work adapter; events · telemetry → host runtime store node | same |
| F2 Review subtext overflow; Runtime → candidate gap | Review box 72 h, two lines; edge starts at the box edge | F2-compile-commit.svg |
| F2 "record" and owners | "a record, not a work fact"; Work queries / decisions → Core vs run control / events → host runtime owner; desc: "the instance where a person decides" | same |
| F3 fidelity, observations, coupling | protocol state = owner obligation, "recoverability unproven today (DRT-02)"; candidates via work adapter, events to host store; today vs target line | F3-runtime-anatomy.svg |
| F4 caption / footnote | copy candidates only, no SVG edit | repaired-ab/figures/F4-captions.md |
| F5 surface authority; compact 390 | "surface metadata · not UI authority"; new F5-expert-composition-compact.svg (360×330) | svg/ |
| roles.svg hash typo | corrected in FIGURES-README-v3.md (`a6ec15e1…1901`); v2 file left as archived | repaired-ab/figures/FIGURES-README-v3.md |
| canvas dark authored values | only `--authored-surface` overridden in dark; others root; "candidate difference, not parity" | repaired-ab/canvas/shared.mjs |
| Spark invented reason | replaced by DTO / fixture values (`contract_unsupported`, `contract_unsupported_excluded`); scenario text removed | boards-spark.mjs; SparkOverview / SparkNarrow / SparkStates |
| clipped boards | Main split into Main + MainPlan; every frame set from measured content height and re-measured (document height ≤ frame, no clipped container) — see measure-final.json; the one remaining "clipped" is the AttentionAssistant stream, a scroll region in the product itself | repaired-ab/canvas/measure-final.json, renders/ |
| beat 5 causality | new derivation from the current source (c-11, rev 3) → version 8; c-9 / c-10 kept stale; contract path named (revise_candidate / new Run with supersedes) | boards-pages.mjs |
| RETURN old ledger | v1 "Awaiting Astra" + PR order kept verbatim as history with the ruled DG / DR mapping; ledger rows corrected per consumption-review C04 / C05 / C15 / C16 / C18 / C30 / C32 | boards-return.mjs → work/RETURN-design.md |
| A2 glyph | unchanged: DR-02 optical candidate only | — |
| CR-05 | read as App reference only; not drawn | — |

Canvas artifact URL not republished this round (offline `work/` + `renders/` are the deliverable).

## 2 · Pages candidates

Six static compositions, two fact sets, one claim each; details, borrowed assets, abstraction, read order, red meaning, min size and motion rationale in `pages-candidates/P1/README.md` and `P2/README.md`; images in `png/`, sources in `svg/`, compact 390 views beside each.

| Passage | Candidates | Recommended | Why |
|---|---|---|---|
| P1 · after a source changes (Home, after the atoms, before research) | P1-1 sequence · P1-2 before / after with a lens · P1-3 sheets, branches, convergence | **P1-2** | "nothing is erased" and "the version moved because a person decided and a new derivation was accepted" are visible on the object itself, not only in the caption |
| P2 · how a candidate becomes the work (Tour, chapter JUDGE after `review`; also fits index #architecture beside state-to-commit) | P2-1 boundary and loop · P2-2 strata of one Matter · P2-3 sheets, beam, gate | **P2-2** | answers the Tour reader's question in one vertical read; trace visibly outside the record; names the human instance without gating the whole loop |

Red: P1-1 / P1-2 / P1-3 one each (the person's judgment, with text equivalent); P2-1 none (mechanism); P2-2 one (the instance: a person accepts c-11); P2-3 one (the gate). No figure uses red as decoration; every red has a word beside it.

## 3 · Author checks and not-run

Executed: headless-Chrome renders (DPR 2) of 5 figures, 12 candidates, 20 boards at 1440 and 390, light and dark; CDP measurement of document height, clipped containers and SVG text outside the viewBox (`tools/measure.mjs`; receipts: `repaired-ab/canvas/measure-final.json`, `repaired-ab/figures/png/text-check.json`, `pages-candidates/text-check.json`). Wide plates scroll horizontally at 390 inside the site's figure-scroll region, as pipeline.svg does today; compact variants are the intended 390 view. Not run: real `site/build.mjs`, link / media checks, forced-colors emulation, greyscale, VoiceOver, IME, true 200 %, 1280 product regression, IC-6 blur. Author renders are not independent acceptance.

## 4 · Open for Astra

- Mount points are proposals (P1 under the atoms; P2 in Tour JUDGE or index #architecture).
- The candidate SVGs use four small class additions beyond `site.css` `.fig` rules (`fig-sheet`, `fig-sheet-candidate`, `fig-paper`, `fig-wire`, plus `fig-serif`/`fig-ink`); their CSS is in `tools/render-figures.mjs` for integration.
- F1 names Codex / DSH as dashed candidates per the contract; a public variant may drop the names.
- Public captions are English in the SVG `<title>/<desc>`; bilingual page copy is Astra's.

Manifest of every delivered file with SHA-256: `source-manifest.json`.
