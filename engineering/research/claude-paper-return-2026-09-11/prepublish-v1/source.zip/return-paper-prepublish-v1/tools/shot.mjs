// Headless Chrome screenshot runner over CDP. Node 22+ global WebSocket, no deps.
// usage: node shot.mjs <list.json>   list: [{url,w,h,label,out,dark?,full?,scrollTo?,scale?,zoom?,noscript?,waitMs?,eval?}]
import { spawn } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const items = JSON.parse(readFileSync(process.argv[2], 'utf8'));
const port = 9800 + Math.floor(Math.random() * 400);
const chrome = spawn(CHROME, ['--headless=new', '--disable-gpu', '--hide-scrollbars', '--no-first-run', `--remote-debugging-port=${port}`, '--user-data-dir=/tmp/cw-shot-' + port, 'about:blank'], { stdio: 'ignore' });
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
async function waitPort() { for (let i = 0; i < 60; i++) { try { const r = await fetch(`http://127.0.0.1:${port}/json/version`); if (r.ok) return; } catch {} await sleep(200); } throw new Error('chrome did not start'); }
await waitPort();
const receipts = [];
for (const it of items) {
  const t = await (await fetch(`http://127.0.0.1:${port}/json/new?about:blank`, { method: 'PUT' })).json();
  const ws = new WebSocket(t.webSocketDebuggerUrl);
  await new Promise(r => ws.onopen = r);
  let id = 0; const pending = new Map();
  ws.onmessage = (m) => { const d = JSON.parse(m.data); if (d.id && pending.has(d.id)) { pending.get(d.id)(d); pending.delete(d.id); } };
  const send = (method, params = {}) => new Promise(res => { const i = ++id; pending.set(i, res); ws.send(JSON.stringify({ id: i, method, params })); });
  const scale = it.scale ?? 1;
  await send('Emulation.setDeviceMetricsOverride', { width: it.w, height: it.h, deviceScaleFactor: scale, mobile: it.w < 600 });
  if (it.dark !== undefined) await send('Emulation.setEmulatedMedia', { features: [{ name: 'prefers-color-scheme', value: it.dark ? 'dark' : 'light' }, ...(it.reducedMotion ? [{ name: 'prefers-reduced-motion', value: 'reduce' }] : [])] });
  if (it.noscript) await send('Emulation.setScriptExecutionDisabled', { value: true });
  if (it.print) await send('Emulation.setEmulatedMedia', { media: 'print' });
  await send('Page.enable');
  await send('Page.navigate', { url: it.url });
  await sleep(it.waitMs ?? 1500);
  if (it.zoom) await send('Emulation.setPageScaleFactor', { pageScaleFactor: it.zoom });
  if (it.eval) await send('Runtime.evaluate', { expression: it.eval, awaitPromise: true });
  if (it.scrollTo !== undefined) { await send('Runtime.evaluate', { expression: typeof it.scrollTo === 'number' ? `window.scrollTo(0,${it.scrollTo})` : `(document.querySelector(${JSON.stringify(it.scrollTo)})||document.body).scrollIntoView({block:'start'})` }); await sleep(400); }
  const m = await send('Runtime.evaluate', { expression: `({sw:document.documentElement.scrollWidth,sh:document.documentElement.scrollHeight,cw:document.documentElement.clientWidth,title:document.title,url:location.href})`, returnByValue: true });
  const meta = m.result.result.value;
  const params = { format: 'png' };
  if (it.full) { params.captureBeyondViewport = true; params.clip = { x: 0, y: 0, width: it.w, height: Math.min(meta.sh, it.maxH ?? 6000), scale: 1 }; }
  const shot = await send('Page.captureScreenshot', params);
  mkdirSync(dirname(it.out), { recursive: true });
  writeFileSync(it.out, Buffer.from(shot.result.data, 'base64'));
  receipts.push({ label: it.label, url: it.url, viewport: [it.w, it.h], dark: !!it.dark, scrollWidth: meta.sw, scrollHeight: meta.sh, clientWidth: meta.cw, out: it.out, title: meta.title });
  console.log(`${it.label}: ${it.w}x${it.h} sw=${meta.sw} sh=${meta.sh} -> ${it.out}`);
  ws.close();
  await fetch(`http://127.0.0.1:${port}/json/close/${t.id}`);
}
chrome.kill();
if (process.argv[3]) writeFileSync(process.argv[3], JSON.stringify({ at: new Date().toISOString(), receipts }, null, 2));
