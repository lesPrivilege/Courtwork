# Architecture figure candidates · F1–F5 · 2026-09-11

Author: Claude (Fable) at the user's instruction. Candidates only: not registered in `figures.json`, not placed in README / architecture / Pages, not accepted. Astra integrates after the independent architecture review; registry ids below are proposals following the existing naming (`state-to-commit`, `pipeline`).

## Semantic sources consumed (Courtwork main @ 3f5daf41aba918622b1ca7a3534eccf81ecfd562)

| Path | sha256 |
|---|---|
| engineering/architecture-runtime-canon.md (DEC-013) | 3d268762ca789bf78d772bc0e6935ff98ff1799645408f030a7458f30e8a03d2 |
| engineering/architecture.md (M01–M14, dependency boundaries) | 0fff85bc067ec5ec6a0897517d64b9a3b1cd8143ed0bd6e338026c6eae74321b |
| engineering/release/architecture-reconciliation-2026-09-11.md (F1–F5 contract) | 1502d55ca694b7bccfb3955500552b7a3ec4a8a82eb52a80501886ce29bb672d |
| site/src/assets/figures/figures.json (registry) | 79ae520712d03546451029fe32480b258ec6708c488fc32184c575eb50e84d5d |
| site/src/assets/diagram.svg (state-to-commit) | 008864a7ce0eada15350f66996c05a9f596c670ea9ae834902e6b6f8d649b31e |
| site/src/assets/figures/pipeline.svg | 2d403485e24ca3577bb787d8f260f76915dcf2ee2ea6b4b215fd2e45578218da |
| site/src/assets/figures/roles.svg | a6ec15e1d79c19e3e443186ebde1ece956043c43a378ad69e07eedc211901 |

Also read, not hashed as sources: engineering/research/deepseek-runtime-2026-09-11/README.md (DS/AC/TM/VC dispositions), input-snapshot.txt §F1–F5 (the original ASCII sketches), publishing-visuals visual-semantic-registry.md (taboos, red rule VG-15), site/src/site.css .fig rules, app/runtime/pi-session-runtime.mjs and app/server/service.mjs (SessionManager coupling, lines 18 / 1509 / 1513), app/harness/ (Thread only).

## Per-figure delivery

| | F1 · ownership | F2 · compile / execute / commit | F3 · runtime anatomy | F5 · expert composition (optional inset) |
|---|---|---|---|---|
| proposed registry id | `ownership` | `compile-commit` | `runtime-anatomy` | `expert-composition` |
| claim (one question) | what CourtWork owns; what can be replaced | how requirements become a run, and how a run becomes a decision | what a Runtime is made of | how Schema, Work Contract and Expert relate |
| audience / placement | README compact · architecture.md full · Pages Research & architecture (not Hero) | architecture.md · Pages Research & architecture | architecture.md (engineering); Pages optional | architecture.md only if F1/F2 leave Expert unclear |
| grammar / renderer / status | plate · svg-file · `concept` (target structure; Pi implemented, Codex/DSH candidates) | plate · svg-file · `concept` | plate · svg-file · `concept` | object · svg-file · `concept` |
| editable source | svg/F1-ownership.svg | svg/F2-compile-commit.svg | svg/F3-runtime-anatomy.svg | svg/F5-expert-composition.svg |
| sha256 (this delivery) | 47d795e685719729802df7c25d2fde77ec927c97b4517080a6c1678814f20725 | 2abf888070956a70e56e1cb029a693b38907f04be9a983bc5f76a4f8f9bd8771 | dd576fe32b93ccf05f3d5803634f32f625ed280155608c2633a0a4b4396fab8f | a4b3b9ab6c04df842b0406149d827708c242aac07d720c793278f8a48a514336 |
| viewBox · min display | 1000×690 · plate min-width 720 (site rule), scrolls at 390 | 960×560 · same | 760×500 · same | 500×220 · inline ≤ 440 |
| red (VG-15) | none (no point needs a person) | one: `data-red="person"` on Review · Authority, "a person decides" — also marked by bold text, so it survives greyscale | none | none |
| reduced motion | static | static | static | static |
| alt / text equivalent | `<title>` + `<desc>` in the SVG (full sentence form) | same | same | same |
| old figure replaced | none (new view); roles.svg stays (Expert-as-method view) | none; state-to-commit stays (F4) | none; the ASCII "Host Adapter ── Generic Agent Runtime" in architecture.md is the nearest prior | none |
| change reason | contract row F1: ownership + stable boundary; Pi in use, others candidate | contract row F2: compile / execute / candidate / Review-Authority / commit kept apart; return edge to Core; execution ≠ commit | contract row F3: Core + capabilities + model adapter + environment as a composition; no extra Runtime layer; protocol state beside, Matter outside | contract row F5: composition, no strict containment; Schema reusable; declares ≠ grants |

### Node / edge / maturity lists

**F1** nodes: Work Surface (shipped) · Work Core (shipped: app/core owner, one SQLite transaction) · Expert (package; today domain/extension = partial) · Work Compiler (target responsibility; M08/M09 dispersed) · Run Plan (target; local facts only, no DTO) · Runtime Adapter (pi-session-runtime.mjs; service still calls SessionManager — decoupling incomplete) · Runtime Pi (in use) · Codex, DSH (candidates, dashed, not connected) · Model / Provider Adapter (present seam) · Environment (local working dir; not a sandbox; not the Matter). Edges: Work Surface ⇄ Work Core "Work API" (control path, not through the compiler) · Work Core → Compiler "Matter projection · policy · authority envelope" · Expert → Compiler "declares requirements" · Compiler → Run Plan "emits" · Run Plan → Runtime Adapter (crosses the boundary) · Adapter → Pi "realizes on" · Pi → Model Adapter "uses" · Pi → Environment "executes in" · Pi ⇢ Work Core (dotted) "run observations · candidates → their owners".

**F2** nodes: five inputs · Work Compiler · Run Plan · Runtime Adapter · Runtime (Pi) · Run observations (trace) · Candidate (dashed) · Review · Authority (person, red) · Commit (Core transaction) · Effective state. Edges: inputs → Compiler "compiles" · Compiler → Plan "emits" · Plan → Adapter · Adapter → Runtime "realizes on" · Runtime → observations · Runtime → Candidate "proposes · domain adapter validates" · Candidate → Review "validation · evidence" · Review → Commit "accepts" · Commit → Effective state · Effective state ⇢ Matter projection (dotted, next run). Text: execution success ≠ commit; two gates, two owners; compiler is not a hub.

**F3** nodes: Model / Provider Adapter · Harness Core (Pi; app/harness ≠ this loop) · Harness Capabilities (as policy + adapter admit) · Runtime Profile · Environment · Runtime protocol state (beside) · Matter state / Work Core (outside). Edges: Runtime → Environment "executes / provisions" · Harness Core ⇄ protocol state · Capabilities ⇢ Matter state (dotted, via adapter only).

**F5** nodes: Expert · Work Contract · Schema. Edges: Expert → Contract "composes" · Contract → Schema "uses" · Expert ⇢ Schema "may reuse directly".

## Semantic checks (contract "下一轮接收条件"), author's pass

| Check | F1 | F2 | F3 |
|---|---|---|---|
| Expert does not touch provider-private objects | Expert's only edge is to the Compiler | same | Expert absent by design |
| Work Core does not depend on Model Adapter | no edge; text says so | no edge | Matter state outside the chain |
| protocol only inside the execution boundary | boundary line + "protocol ends at the adapter" | Adapter is the only crossing | Model Adapter carries dialects |
| Environment ≠ Matter | "not the Matter" on the node | — | "not the Matter" on protocol state; Matter outside |
| candidate / committed and trace / state distinguishable | dotted return edge is observations, not effect | four distinct nodes | protocol state ≠ Matter state |
| authority boundaries have words | boundary label; "declares, never grants" | "a person decides"; "two gates, two owners" | "naming grants nothing" |
| control / query edges not forced through the compiler | Work API edge bypasses the compiler | "the compiler is not a hub" | n/a |

## Visual checks (author's render, not independent acceptance)

Rendered with headless Google Chrome (new headless), DPR 2, the site's `.fig` CSS and campaign palette copied into `render.mjs`: 1440 light / dark and 390 light / dark for each figure (png/, receipt in png/render-receipt.json). At 390 the plate keeps the site's 720 min-width and scrolls horizontally, as pipeline.svg does today. Checked by eye: no clipped text after the second pass, arrowheads terminate on node edges, dashed = candidate / not connected, dotted = return of observations. Not run: forced-colors emulation, greyscale filter, real Pages build (`site/build.mjs`), links / media checks — those belong to the integration step.

## F4

No redraw; edge-by-edge verdicts in F4-continuity-review.md (all keep; one caption relabel candidate; one README footnote).

## Not done / for Astra

- Registry rows are proposals; no `figures.json` edit, no site build, no README / architecture edits (no write grant).
- F1 shows Codex and DSH as dashed candidates because the contract names them; if Astra prefers not to name unconnected runtimes publicly (as roles.svg avoids implementation names), the compact README variant should drop the names and keep "candidate" slots.
- The maturity words inside F1 ("today dispersed", "pi-session-runtime.mjs") suit architecture.md; a Pages variant should drop file names.
- Alt sentences are English; Pages captions are bilingual and remain Astra's copy.
