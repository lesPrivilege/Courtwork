import { mkdirSync, writeFileSync } from 'node:fs';
import { buildSystem } from './boards-system.mjs';
import { buildSpark } from './boards-spark.mjs';
import { buildAttention } from './boards-attention.mjs';
import { buildChat } from './boards-chat.mjs';
import { buildExploreSettings } from './boards-explore-settings.mjs';
import { buildPages } from './boards-pages.mjs';
import { buildReturn } from './boards-return.mjs';
import { ICONS } from './shared.mjs';

const out = new URL('./work/', import.meta.url).pathname;
mkdirSync(out, { recursive: true });
mkdirSync(out + 'glyphs', { recursive: true });
buildSystem(out); buildSpark(out); buildAttention(out); buildChat(out); buildExploreSettings(out); buildPages(out);
buildReturn(out, out + 'RETURN-design.md');
for (const n of ['spark-a','spark-a2','spark-b','spark-c','attn-a','attn-b','attn-c']) {
  writeFileSync(`${out}glyphs/${n}.svg`, `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICONS[n]}</svg>\n`);
}

const P = { system: 'p-system', spark: 'p-spark', attention: 'p-attention', chat: 'p-chat', explore: 'p-explore-settings', pages: 'p-pages', ret: 'p-return' };
const ab = (file, x, y, w, h, page, extra = {}) => ({ file, x, y, w, h, page, ...extra });
const canvas = {
  pages: [
    { id: P.system, name: 'System & glyphs' }, { id: P.spark, name: 'Spark' }, { id: P.attention, name: 'Attention' },
    { id: P.chat, name: 'Chat · composer · motion' }, { id: P.explore, name: 'Explore · Settings' }, { id: P.pages, name: 'Pages' }, { id: P.ret, name: 'Return' },
  ],
  artboards: [
    ab('Main.dc.html', 0, 0, 1440, 1500, P.system, { title: 'Recommended system (DG-09)', print: 'flow' }),
    ab('MainPlan.dc.html', 0, 1620, 1440, 760, P.system, { title: 'Return plan · ruled mapping' }),
    ab('Icons.dc.html', 1560, 0, 1440, 2280, P.system, { title: 'Spark & Attention glyphs (DG-01)' }),
    ab('HeaderPair.dc.html', 3120, 0, 1100, 720, P.system, { title: 'Header pair (DG-06/07 input)' }),
    ab('SparkOverview.dc.html', 0, 0, 1440, 900, P.spark, { title: 'Spark · Overview · light' }),
    ab('SparkActivityDark.dc.html', 1560, 0, 1440, 964, P.spark, { title: 'Spark · Activity · dark' }),
    ab('SparkNarrow.dc.html', 3120, 0, 390, 930, P.spark, { title: 'Spark · 390' }),
    ab('SparkStates.dc.html', 0, 1060, 1440, 1420, P.spark, { title: 'Spark · state matrix' }),
    ab('SparkRebuild.dc.html', 1560, 1060, 1440, 820, P.spark, { title: 'Spark · rebuild (sample)' }),
    ab('AttentionQueue.dc.html', 0, 0, 1440, 1460, P.attention, { title: 'Attention items · light' }),
    ab('AttentionAssistant.dc.html', 1560, 0, 1440, 900, P.attention, { title: 'Attention assistant · dark' }),
    ab('AttentionNarrow.dc.html', 3120, 0, 390, 960, P.attention, { title: 'Attention · 390' }),
    ab('AttentionStates.dc.html', 0, 1140, 1440, 2440, P.attention, { title: 'Attention · state matrix' }),
    ab('ChatSpace.dc.html', 0, 0, 1440, 964, P.chat, { title: 'Chat space · light' }),
    ab('ChatActions.dc.html', 1560, 0, 1440, 1380, P.chat, { title: 'Chat rows & actions (DG-06)' }),
    ab('ComposerMotion.dc.html', 0, 1360, 1440, 1860, P.chat, { title: 'Composer · thinking · streaming (DG-04)' }),
    ab('Explore.dc.html', 0, 0, 1440, 1160, P.explore, { title: 'Explore agent (DG-05)' }),
    ab('Settings.dc.html', 1560, 0, 1440, 2000, P.explore, { title: 'Settings · tab · tap (DG-07)' }),
    ab('PagesStory.dc.html', 0, 0, 1440, 1900, P.pages, { title: 'Pages · Spark & Attention story (DG-08)' }),
    ab('Return.dc.html', 0, 0, 1200, 8900, P.ret, { title: 'Design return · RETURN contract · v2', print: 'flow' }),
  ],
  annotations: [
    { id: 'note-read-order', x: 0, y: -170, w: 720, page: P.system, text: 'v2 · revised after Astra\'s ruling (return-intake.md, main 3f5daf4). Read order: this page → Spark → Attention → Chat/composer/motion → Explore/Settings → Pages → Return (text half, with the v2 change list).\nEvery scene is a drawn specimen at the effective default-slate cascade of styles.css @ dbd1efe — not a pixel baseline. Tags: live = wired today · sample = design sample with its backend gap · specimen = source-inferred, not run. Dashed strips under product frames are notes, not product copy.' },
    { id: 'note-spark', x: 0, y: -140, w: 520, page: P.spark, text: 'Spark: read-only surface as shipped (BE-41 live). Refresh re-reads; Rebuild is drawn once, on the sample board, with its backend register.' },
    { id: 'note-attention', x: 0, y: -140, w: 520, page: P.attention, text: 'Attention: every state on the matrix exists in attention-view.mjs today. The new glyph sits before the word in nav, the workspace title and the assistant title.' },
    { id: 'note-chat', x: 0, y: -140, w: 560, page: P.chat, text: 'Chat: header pair resolved (text = overview, panel-right = surface with pressed state). Composer timeline: word first, motion second; reduced motion = static.' },
    { id: 'note-pages', x: 0, y: -140, w: 560, page: P.pages, text: 'Pages: only a new story section under the two atoms; hero, nav, Ideas, media (f137) unchanged.' },
  ],
  launch: { view: 'canvas', page: P.system },
};
writeFileSync(out + 'canvas.json', JSON.stringify(canvas, null, 2));
console.log('built', Object.keys(canvas.artboards).length, 'artboards →', out);
