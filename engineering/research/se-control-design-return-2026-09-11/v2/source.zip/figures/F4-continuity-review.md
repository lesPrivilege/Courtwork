# F4 · continuity / commitment — existing figures, edge by edge

Contract: reuse the consumable parts of `anatomy-instrument` and `state-to-commit`; do not redraw a correct figure; keep trace ≠ state ≠ context legible. Semantic source: `engineering/architecture-runtime-canon.md` @3f5daf4 (four data classes: governed work state · runtime protocol state · trace · compiled context). Visual source: `site/src/assets/figures/figures.json` @3f5daf4.

Verdict vocabulary follows the registry: **keep / relabel / revise**. Nothing below changes a file; the verdicts are candidates for Astra.

## state-to-commit (`site/src/assets/diagram.svg`, sha256 008864a7…31e, registry `state-to-commit`, status shipped)

| Edge / node | Reads as | Against the canon | Verdict |
|---|---|---|---|
| Governed work state → Context projection (`state-context`) | the run starts from governed state, projected | governed work state (Core) → compiled context: correct, and the projection is named as a projection, not as memory | keep |
| Context projection → Model / human proposal (`context-proposal`) | the proposal is made from the projection | correct; "human" keeps the propose/approve split visible | keep |
| Proposal → Candidate (`proposal-candidate`) | a proposal becomes a candidate | correct (SE-01: candidate is a distinct thing) | keep |
| Candidate ⇣ validation · evidence · authority · review (`candidate-commit`) | the gate | matches Review / Authority / commit; the gate has no person drawn, but the page's Review section carries the recorded red, and the registry already ruled no red here | keep |
| Committed change → Updated state (`commit-state`) | commit updates state | correct | keep |
| Updated state ⇢ next run (`state-next-run`, dashed) | the loop closes | correct (VG-2③ revision already applied) | keep |
| absent: trace / runtime protocol state | — | this figure is the work-state transition view; trace is deliberately not here. F2 carries trace ≠ candidate ≠ effective state | keep; no addition |
| caption "当前状态 → 运行上下文 → 候选 → 审阅 → 正式变化" | — | "运行上下文" could be read as runtime state; the canon's word is compiled context / projection | relabel candidate: "当前状态 → 上下文投影 → 候选 → 审阅 → 正式变化" (copy owner: Astra; not changed here) |

## pipeline (`site/src/assets/figures/pipeline.svg`, sha256 2d403485…8da, registry `pipeline`, status concept)

| Edge / node | Against the canon | Verdict |
|---|---|---|
| Store → Govern → Retrieve → Compile | SE 9.6 §5.4 data/context architecture; Compile = context compilation (M09), which is one responsibility inside the target Work Compiler, not the whole compiler | keep; footnote in the figure README only: "Compile here is context compilation; the Work Compiler (F1/F2) also intersects policy and capabilities" |
| Compile → Run | correct | keep |
| Run → Store "candidate → review → commit" | correct; consistent with F2 | keep |
| strip "stock grows · working set does not" | correct (bounded working set) | keep |
| status `concept` | the page states an idea, not a shipped four-stage product | keep |

## anatomy-instrument (`site/src/page.mjs` rendered fragment, registry `anatomy-instrument`, status shipped, decorative, aria-hidden)

| Element | Against the canon | Verdict |
|---|---|---|
| three projections of one Matter: Event log · Work state · Context (tab panels carry the meaning) | event log = trace owner (Run events), Work state = governed state, Context = compiled projection: the three classes the canon separates; runtime protocol state is not one of the three views, and should not be added to a public "three views" figure | keep |
| tab copy "Event log: 按时间追踪请求、工具调用、批准、回答与结果" | this is trace; it does not claim trace = accepted fact | keep |
| tab copy "Work state: 在同一个工作面查看候选、证据、决定与版本" | governed state + candidates on one surface; candidate ≠ committed is carried by the Review section | keep |

## Conclusion

No F4 redraw is proposed. One copy relabel candidate (state-to-commit caption) and one README footnote (pipeline's Compile) are the only changes surfaced; both are Astra's to accept. F1/F2/F3 do not duplicate these figures: F2 adds the trace / candidate / effective-state distinction and the two gates; F1 adds ownership and the runtime boundary; F3 adds the runtime composition. Cross-references in F1–F3 point at F2 for effect and at F3 for composition, never back into these two figures, so the registry can keep them unchanged.
