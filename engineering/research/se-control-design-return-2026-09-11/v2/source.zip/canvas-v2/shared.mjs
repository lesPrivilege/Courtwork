// Shared vocabulary for every artboard. Values are lifted from
// Courtwork app/web/styles.css @ dbd1efe (a01dee8 ancestry) — not rounded.
import { writeFileSync } from 'node:fs';

export const CSS = `
:root{
  /* Effective default-slate cascade at dbd1efe (NOT the top-of-file palette):
     tier:S neutral strata, styles.css ~5500-5570, applied by
     html:not([data-skin="custom"]):not([data-skin="gray-steel"]):not([data-skin="dystopia"]).
     Fixed semantic/material primitives (~5966+) and the authored plane (~5906) follow. */
  --home-neutral-frame:#e0e4e7;--home-neutral-paper:#f4f5f6;--home-neutral-raised:#ffffff;--home-neutral-sunken:#e9edef;
  --home-neutral-line:#cbd2d6;--home-neutral-line-strong:#8b949a;--home-neutral-ink:#2a2c2c;--home-neutral-secondary:#616466;
  --home-neutral-hover:#e0e4e7;--home-neutral-selected:#d8dee2;--home-attention-review-foreground:#ae3630;
  --alpha-ink:28,32,36;--alpha-paper:253,253,254;--shadow-alpha:0.08;--glass-alpha:0.86;--rim-alpha:0.7;
  --system-focus:#2a2c2c;--system-danger:#9b3c35;--system-danger-soft:#feebec;--success-11:#3e704e;--success-3:#e6f6eb;
  --on-accent-s:#fdfdfe;--ink-max:#000;
  --authored-surface:#202426;--authored-raised:#303638;--authored-ink:#f5f7f8;--authored-muted:#c8cdd0;--authored-line:#596267;
}
.dark{
  --home-neutral-frame:#171a1b;--home-neutral-paper:#222627;--home-neutral-raised:#2e3335;--home-neutral-sunken:#1c2021;
  --home-neutral-line:#444d51;--home-neutral-line-strong:#737e84;--home-neutral-ink:#f4f5f6;--home-neutral-secondary:#b6bec2;
  --home-neutral-hover:#343b3f;--home-neutral-selected:#414a4f;--home-attention-review-foreground:#efaaa4;
  --alpha-ink:0,0,0;--alpha-paper:237,238,240;--shadow-alpha:0.4;--glass-alpha:0.1;--rim-alpha:0.12;
  --system-focus:#f4f5f6;--system-danger:#ff9592;--system-danger-soft:#3b1219;--success-11:#3dd68c;--success-3:#132d21;
  --on-accent-s:#111113;--ink-max:#fff;
  /* dark authored plane = existing float (5e3a504 / CW-PREF-20260911-01) */
  --authored-surface:#2e3335;--authored-raised:#343b3f;--authored-ink:#f4f5f6;--authored-muted:#b6bec2;--authored-line:#737e84;
}
:root,.dark{
  --frame:var(--home-neutral-frame);--panel:var(--home-neutral-paper);--panel-muted:var(--home-neutral-sunken);--float:var(--home-neutral-raised);
  --hover:var(--home-neutral-hover);--selected:var(--home-neutral-selected);--pressed:var(--home-neutral-selected);--line:var(--home-neutral-line);--line-strong:var(--home-neutral-line-strong);
  --ink:var(--home-neutral-ink);--ink-strong:var(--home-neutral-ink);--muted:var(--home-neutral-secondary);--muted-strong:var(--home-neutral-secondary);
  --accent:var(--home-neutral-ink);--accent-strong:var(--home-neutral-ink);--accent-soft:var(--home-neutral-sunken);--accent-ink:var(--home-neutral-ink);
  --attention-review:var(--home-attention-review-foreground);
  --focus:var(--home-neutral-ink);--on-accent:var(--on-accent-s);--danger:var(--system-danger);--danger-soft:var(--system-danger-soft);
  --success:var(--success-11);--success-soft:var(--success-3);
  --backdrop:rgba(var(--alpha-ink),0.22);--scrim:rgba(var(--alpha-ink),0.52);
  --shadow-float:0 12px 30px rgba(var(--alpha-ink),var(--shadow-alpha));--shadow:var(--shadow-float);
  --shadow-thumb:0 1px 2px rgba(var(--alpha-ink),0.12);--shadow-pressed:inset 0 1px 2px rgba(var(--alpha-ink),0.25);
  --glass:rgba(var(--alpha-paper),var(--glass-alpha));--rim:inset 0 0 0 1px rgba(var(--alpha-paper),var(--rim-alpha));
  --blur-chrome:12px;--blur-transient:16px;
  --space-1:4px;--space-2:8px;--space-3:12px;--space-4:16px;--space-5:20px;--space-6:24px;--space-8:32px;
  --page-gutter:24px;--column:740px;--content-inset:40px;--home-column:820px;--band-top:48px;--col-gap:24px;--nav:256px;
  --settings-nav:240px;--settings-gutter:48px;--settings-measure:820px;--settings-group-gap:40px;
  --control:28px;--radius-small:4px;--radius-control:8px;--radius-card:12px;--radius-container:16px;--radius-pill:999px;--radius:var(--radius-control);
  --text-title:18px;--text-navigation-title:15px;--text-reading:15px;--text-label:12px;--text-caption:10.5px;--text-section:13px;--text-body:14px;--text-meta:11.5px;
  --tracking-heading:-0.02em;--tracking-caps:0.08em;
  --font-mono:ui-monospace,SFMono-Regular,"SF Mono",Menlo,Consolas,"Liberation Mono",monospace;
  --duration-fast:120ms;--duration:180ms;--ease-out:cubic-bezier(0.2,0,0,1);
}
*{box-sizing:border-box}
body{margin:0;font:14px/1.5 ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:var(--ink);background:var(--frame);-webkit-font-smoothing:antialiased}
a{color:var(--accent-ink)}a:hover{color:var(--accent-strong)}
h1,h2,h3,h4,p{margin:0}
.ui-icon{display:inline-block;flex:none;vertical-align:middle}
button{display:inline-flex;align-items:center;justify-content:center;gap:8px;font:inherit;font-size:var(--text-label);min-height:var(--control);border:1px solid transparent;border-radius:var(--radius);padding:5px 10px;background:transparent;color:inherit;cursor:default}
.quiet-button:hover,.text-button:hover,.is-hover{background:var(--hover)}
.quiet-button:active,.text-button:active,.is-pressed{background:var(--pressed)}
.icon-only{width:var(--control);min-width:var(--control);padding:0}
.primary-button{background:var(--accent);color:var(--on-accent);border-color:var(--accent);font-weight:500}
.secondary-button{background:var(--panel);border-color:var(--line-strong)}
.text-button{color:var(--accent-ink);padding:3px 4px;font-size:var(--text-meta)}
.pill{border-radius:var(--radius-pill)}
.is-focus{outline:2px solid var(--focus);outline-offset:2px}
.is-selected,button[aria-pressed="true"],button[aria-checked="true"]{background:var(--selected);color:var(--ink)}
.is-disabled,button[aria-disabled="true"]{opacity:.55}
.eyebrow{font-size:var(--text-caption);line-height:1.5;font-weight:500;color:var(--muted-strong);letter-spacing:var(--tracking-caps);text-transform:uppercase}
.form-help{font-size:var(--text-meta);color:var(--muted-strong);line-height:1.6}
.inline-error{color:var(--danger);font-size:var(--text-label)}
.inline-notice{padding:12px;background:var(--panel-muted);border-radius:var(--radius-control);line-height:1.6;font-size:var(--text-label)}
.mono{font-family:var(--font-mono);font-size:12px;line-height:1.6}
select,input,textarea{font:inherit;color:inherit;background:var(--panel);border:1px solid var(--line-strong);border-radius:var(--radius-control);height:var(--control);padding:0 10px;font-size:var(--text-label)}
select{appearance:none;padding-right:28px;background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%2360646c' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='m6 9 6 6 6-6'/></svg>");background-repeat:no-repeat;background-position:right 8px center;background-size:14px}
textarea{height:auto;padding:8px 10px;line-height:1.5}
/* shell */
.app-shell{display:grid;grid-template-columns:var(--nav) minmax(0,1fr);height:100%;overflow:hidden;background:var(--frame);position:relative}
.sidebar{background:var(--frame);border-right:1px solid var(--line);display:flex;flex-direction:column;padding:0 12px 12px;min-width:0}
.sidebar>*+*{margin-top:var(--space-4)}.sidebar>.nav-home+.nav-home{margin-top:var(--space-1)}
.sidebar-header{display:flex;align-items:center;justify-content:space-between;gap:4px;height:var(--band-top);margin:0 -12px;padding:0 var(--space-4) 0 20px;border-bottom:1px solid var(--line)}
.workspace-brand{display:inline-flex;align-items:center;gap:6px;color:var(--ink);font-size:var(--text-label);font-weight:650;letter-spacing:-0.025em;text-decoration:none}
.nav-home{justify-content:flex-start;width:100%;min-height:32px;padding-left:8px;font-size:var(--text-body)}
.nav-home[aria-current="page"]{background:var(--selected);font-weight:600}
.nav-filter{position:relative;display:flex;align-items:center}
.nav-filter input{width:100%;border:1px solid var(--line);border-radius:var(--radius-control);background:transparent;padding:7px 30px;font-size:var(--text-meta);height:auto}
.nav-filter .ui-icon{position:absolute;left:9px;color:var(--muted)}
.section-heading{display:flex;justify-content:space-between;align-items:center;gap:12px}
.section-heading h2{font-size:var(--text-caption);font-weight:500;color:var(--muted-strong);letter-spacing:var(--tracking-caps);text-transform:uppercase;display:flex;gap:8px}
.project-row{display:flex;align-items:center;gap:8px;min-height:32px;padding:0 8px;font-size:var(--text-body);font-weight:600}
.chat-row{display:flex;align-items:center;justify-content:space-between;gap:8px;min-height:32px;padding:0 8px 0 27px;font-size:var(--text-body);border-radius:var(--radius);white-space:nowrap;overflow:hidden}
.chat-row span:first-child{overflow:hidden;text-overflow:ellipsis}
.chat-row .tag{font-size:var(--text-caption);color:var(--muted-strong)}
.chat-row[aria-current="page"]{background:var(--selected)}
.sidebar-foot{margin-top:auto;display:flex;gap:4px;padding-left:8px}
.main{display:flex;flex-direction:column;min-width:0;background:var(--panel);position:relative;overflow:hidden}
.chat-header{display:flex;align-items:center;gap:12px;padding:0 var(--col-gap);border-bottom:1px solid var(--line);height:var(--band-top);flex:none}
.chat-header-inner{flex:1;max-width:var(--column);margin:0 auto;display:flex;align-items:center;gap:12px;min-width:0}
.chat-title-wrap{min-width:0;flex:1;display:flex;align-items:baseline;gap:var(--space-2)}
.chat-title-wrap h1{font-size:var(--text-navigation-title);font-weight:600;letter-spacing:var(--tracking-heading);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.run-badge{font-size:var(--text-caption);font-weight:450;color:var(--muted-strong);display:inline-flex;align-items:center;gap:4px}
.run-badge.running,.run-badge.waiting_user{color:var(--accent-ink)}.run-badge.failed{color:var(--danger)}
.dot{width:6px;height:6px;border-radius:var(--radius-pill);background:var(--accent);flex:none}
.chat-header-actions{display:flex;gap:4px;align-items:center;flex:none}
/* messages */
.message-stream{flex:1;overflow:hidden;padding:var(--space-8) var(--content-inset) var(--space-6);display:flex;flex-direction:column}
.message-list{max-width:var(--column);margin:0 auto;width:100%;display:flex;flex-direction:column;gap:8px}
.message.user{align-self:flex-end;width:fit-content;max-width:82%;margin:16px 0 0}
.user-message-content{background:var(--authored-surface);color:var(--authored-ink);padding:12px 16px;border-radius:var(--radius-container);font-size:var(--text-reading);line-height:1.7}
.user-message-content .src{display:block;margin-top:4px;font-size:var(--text-meta);color:var(--authored-muted)}
.message-role{font-size:var(--text-caption);font-weight:500;color:var(--muted-strong);letter-spacing:var(--tracking-caps);text-transform:uppercase;margin:16px 0 8px}
.message-body{font-size:var(--text-reading);line-height:1.7;white-space:pre-wrap;overflow-wrap:anywhere}
.flow-row{display:flex;align-items:center;gap:8px;min-height:32px}
.flow-row>.ui-icon{color:var(--muted)}
.flow-title{min-width:0;flex:1}
.flow-meta{flex:none;color:var(--muted-strong);font-size:var(--text-meta);white-space:nowrap;display:inline-flex;align-items:center;gap:6px}
.flow-row.is-failed>.flow-meta{color:var(--danger)}
.flow-sep{border-bottom:1px solid var(--line)}
.chat-action-row{display:flex;align-items:center;gap:2px;flex-wrap:wrap;color:var(--muted-strong)}
.chat-action-row>.icon-only{width:32px;min-width:32px;height:32px}
.chat-action-status{margin:4px 0 0;color:var(--muted-strong);font-size:var(--text-meta)}
.chat-action-status[data-state="error"]{color:var(--danger)}
.question-card{border:1px solid var(--line-strong);border-radius:var(--radius-card);padding:20px;display:grid;gap:12px;background:var(--panel-muted)}
.message.error{border-left:2px solid var(--danger);padding:8px 16px;color:var(--danger)}
/* composer */
.composer-area{flex:none;padding:var(--space-2) var(--content-inset) var(--space-4)}
.composer-form{max-width:var(--column);margin:0 auto;border:1px solid var(--line-strong);border-radius:var(--radius-container);padding:12px;background:var(--float);box-shadow:var(--shadow-float)}
.composer-form.is-focus-within{border-color:var(--ink)}
.composer-input{min-height:calc(2 * 1.65em + 8px);padding:4px;line-height:1.65;font-size:var(--text-body);color:var(--muted)}
.composer-input.has-text{color:var(--ink)}
.composer-run-hint{display:flex;align-items:center;gap:8px;font-size:var(--text-meta);color:var(--muted-strong);padding:4px;font-variant-numeric:tabular-nums}
.composer-run-hint .dot{animation:se-pulse 1.6s var(--ease-out) infinite}
.composer-run-hint.is-waiting{color:var(--accent-ink)}.composer-run-hint.is-waiting .dot{animation:none}
.composer-run-hint.is-static .dot{animation:none}
.composer-controls{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:8px}
.composer-context,.composer-buttons{display:flex;align-items:center;gap:4px;min-width:0}
.composer-model{font-size:var(--text-meta);padding:4px 6px;font-family:var(--font-mono)}
.composer-notice{font-size:var(--text-meta);color:var(--muted-strong);padding:4px}
@keyframes se-pulse{0%,100%{opacity:1}50%{opacity:.25}}
.composer-below{max-width:var(--column);margin:8px auto 0;display:flex;gap:12px;font-size:var(--text-meta);color:var(--muted-strong);padding:0 12px}
/* dialog */
.dialog-scrim{position:absolute;inset:0;background:var(--scrim)}
.spark-dialog{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:880px;background:var(--panel);color:var(--ink);border:1px solid var(--line);border-radius:var(--radius-card);padding:24px;box-shadow:var(--shadow-float)}
.spark-header{display:flex;align-items:start;justify-content:space-between;gap:16px}
.spark-header h2,.dialog-title{font-size:var(--text-title);font-weight:600;letter-spacing:var(--tracking-heading);display:flex;align-items:center;gap:8px}
.spark-controls{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:12px 0}
.spark-tabs{display:flex;gap:20px;border-bottom:1px solid var(--line)}
.spark-tabs button{border:0;border-radius:0;background:transparent;padding:10px 0;font-size:var(--text-label)}
.spark-tabs button[aria-selected="true"]{border-bottom:2px solid var(--ink);color:var(--ink)}
.spark-tabs button[aria-selected="false"]{color:var(--muted-strong)}
.spark-section-heading{margin:20px 0 8px;font-size:var(--text-meta);text-transform:uppercase;letter-spacing:.04em;color:var(--muted-strong);font-weight:600}
.spark-section-heading.is-quiet{font-weight:400}
.spark-matter-row{padding:10px 0;border-bottom:1px solid var(--line)}
.spark-matter-open{display:block;padding:0;border:0;background:transparent;text-align:left;font-size:14px;font-weight:600;color:inherit}
.spark-matter-row.is-quiet .spark-matter-open{font-weight:400}
.spark-matter-meta{display:flex;gap:12px;flex-wrap:wrap;color:var(--muted-strong);font-size:var(--text-meta);margin-top:2px}
.spark-matter-row.is-unavailable{outline:2px dotted var(--muted-strong);outline-offset:4px}
.spark-unavailable{color:var(--muted-strong);font-style:italic}
.spark-chip-row{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}
.spark-chip{font-size:var(--text-meta);padding:2px 8px;border:1px solid var(--line);border-radius:var(--radius-pill);color:var(--muted-strong)}
.spark-source-change{margin:4px 0 0}
.spark-table{width:100%;border-collapse:collapse;font-size:var(--text-meta)}
.spark-table th,.spark-table td{padding:8px;text-align:right;border-bottom:1px solid var(--line);white-space:nowrap}
.spark-table th:first-child,.spark-table td:first-child{text-align:left;font-weight:400}
.spark-table thead th{color:var(--muted-strong);font-weight:500}
/* attention workspace */
.attention-workspace{padding:32px var(--page-gutter) 48px;overflow:hidden;flex:1}
.attention-workspace-inner{max-width:1040px;margin:0 auto}
.attention-workspace-heading{display:flex;align-items:center;justify-content:space-between;gap:24px;margin-bottom:24px}
.attention-workspace-heading h1{font-size:30px;letter-spacing:-0.02em;margin:4px 0 8px;font-weight:600}
.attention-eyebrow{font-size:var(--text-meta);letter-spacing:.08em;color:var(--muted-strong)}
.attention-toolbar{display:flex;gap:12px;margin-bottom:24px;align-items:center}
.attention-views{display:flex;gap:4px;margin-bottom:20px}
.attention-view-choice{padding:7px 12px;border-radius:var(--radius-control);white-space:nowrap;font-size:var(--text-label);color:var(--accent-ink)}
.attention-view-choice.is-current{background:var(--float);color:var(--ink);font-weight:500;box-shadow:inset 0 0 0 1px var(--line)}
.attention-columns{display:grid;grid-template-columns:minmax(220px,.8fr) minmax(0,1.3fr);gap:24px;align-items:start}
.attention-registry{padding:16px 0}
.attention-count{font-size:var(--text-meta);color:var(--muted-strong);margin-bottom:12px}
.attention-registry-row{width:100%;display:flex;flex-direction:column;gap:7px;align-items:start;text-align:left;padding:13px 12px;border:0;border-radius:var(--radius-small);background:none;margin-bottom:4px}
.attention-registry-row[aria-pressed="true"]{background:var(--float)}
.attention-row-title{font-weight:500;font-size:var(--text-body)}
.attention-row-meta{display:flex;align-items:baseline;justify-content:space-between;gap:12px;width:100%}
.attention-row-time{font-size:var(--text-meta);color:var(--muted-strong)}
.home-attention-state{font-size:var(--text-meta);color:var(--muted-strong)}
.home-attention-state.is-review,.attention-detail-state.is-review{color:var(--attention-review);font-weight:600}
.attention-reading{border-left:1px solid var(--line);padding:16px 24px;background:var(--float);min-height:480px}
.attention-detail-state{font-size:var(--text-label);color:var(--muted-strong)}
.attention-detail-head h2{font-size:24px;line-height:1.3;margin:12px 0;font-weight:600;letter-spacing:-0.02em}
.attention-detail-head p,.attention-decision p{font-size:var(--text-body);line-height:1.65}
.attention-decision{padding:20px 0}
.attention-decision h3{font-size:var(--text-label);color:var(--muted-strong);margin:14px 0 6px;font-weight:600}
.attention-decision h3:first-child{margin-top:0}
.attention-basis summary{font-size:var(--text-label);cursor:default}
.attention-actions{margin-top:28px;padding-top:20px;border-top:1px solid var(--line)}
.attention-actions h3{font-size:var(--text-label);color:var(--muted-strong);margin:0 0 12px;font-weight:600}
.attention-action-choices{display:flex;flex-wrap:wrap;gap:6px}
.attention-action-choice{padding:7px 12px;border-radius:var(--radius-control);font-size:var(--text-meta);color:var(--accent-ink)}
.attention-action-choice.is-current{background:var(--panel-muted);box-shadow:inset 0 0 0 1px var(--line);color:var(--ink)}
.attention-action-editor{margin-top:16px;display:flex;flex-direction:column;gap:14px}
.attention-action-editor fieldset{border:1px solid var(--line);border-radius:var(--radius-card);padding:14px;margin:0;display:flex;flex-direction:column;gap:12px}
.attention-action-editor legend{padding:0 6px;font-size:var(--text-label);color:var(--muted-strong)}
.attention-field{display:flex;flex-direction:column;gap:6px}
.attention-field-label{font-size:var(--text-label)}
/* attention agent dialog */
.attention-agent-dialog{position:absolute;right:20px;top:60px;width:640px;height:780px;border:1px solid var(--line);border-radius:var(--radius-card);background:var(--panel);color:var(--ink);box-shadow:var(--shadow-float);display:flex;flex-direction:column;overflow:hidden}
.attention-agent-header{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:20px 24px 12px}
.attention-agent-header h2{font-size:22px;letter-spacing:-.02em;font-weight:600;display:flex;align-items:center;gap:8px}
.attention-agent-header p{margin:5px 0 0}
.attention-agent-toolbar{display:flex;align-items:center;gap:8px;padding:0 24px 12px;flex-wrap:wrap;border-bottom:1px solid var(--line)}
.attention-agent-toolbar select{flex:1;min-width:160px}
.attention-agent-stream{flex:1;overflow:hidden;padding:20px 24px;display:flex;flex-direction:column;gap:22px;font-size:var(--text-reading)}
.attention-agent-composer{display:flex;align-items:center;gap:6px;margin:12px 20px 16px;padding:5px 6px 5px 16px;border:1px solid var(--line);border-radius:var(--radius-container);background:var(--float)}
.attention-agent-composer .ph{flex:1;color:var(--muted);font-size:var(--text-body)}
details>summary{list-style:none;cursor:default}
.disc{display:inline-flex;align-items:center;gap:6px;font-size:var(--text-label);color:var(--ink)}
.disc::before{content:"";width:0;height:0;border-left:5px solid currentColor;border-top:4px solid transparent;border-bottom:4px solid transparent}
.disc.open::before{transform:rotate(90deg)}
/* home modules */
.home-card{border:1px solid var(--line);border-radius:var(--radius-container);padding:20px;background:var(--panel-muted)}
.home-attention{background:var(--float);background-image:linear-gradient(155deg,var(--float),var(--panel));box-shadow:var(--rim),0 5px 18px rgba(var(--alpha-ink),var(--shadow-alpha));border-color:transparent}
.home-card-title{display:flex;align-items:center;gap:8px;font-size:var(--text-navigation-title);font-weight:600}
.home-attention-item{width:100%;display:grid;grid-template-columns:minmax(0,1fr) auto 14px;gap:8px;align-items:center;text-align:left;padding:11px 9px;border:0;border-radius:4px;font-size:var(--text-label);margin-bottom:3px}
/* settings */
.settings-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:4px 24px;align-items:center;padding:12px 0;border-bottom:1px solid var(--line)}
.settings-row-text{display:grid;gap:2px;min-width:0}
.settings-row-title{font-size:var(--text-body);font-weight:500}
.settings-row-help{font-size:var(--text-meta);color:var(--muted-strong);line-height:1.45}
.settings-row-control{display:flex;justify-content:flex-end;min-width:0}
.settings-row-control select,.settings-row-control input{min-width:200px}
.settings-row.wide{grid-template-columns:minmax(0,1fr)}
.settings-row.wide .settings-row-control{justify-content:flex-start}
.settings-row-foot{display:flex;justify-content:space-between;align-items:center;min-height:var(--control);font-size:var(--text-meta);color:var(--muted-strong)}
.segmented{position:relative;display:grid;grid-auto-flow:column;grid-auto-columns:1fr;gap:2px;padding:2px;border-radius:var(--radius-control);background:var(--hover);width:100%}
.segment{position:relative;display:inline-flex;align-items:center;justify-content:center;min-height:26px;padding:4px 6px;border-radius:calc(var(--radius-control) - 2px);font-size:var(--text-meta);color:var(--muted-strong);white-space:nowrap}
.segment.on{background:var(--panel);box-shadow:var(--shadow-thumb);color:var(--ink)}
.ui-tooltip{display:inline-block;max-width:260px;padding:6px 9px;border:1px solid var(--line-strong);border-radius:var(--radius-small);background:var(--float);color:var(--ink);font-size:var(--text-caption);line-height:1.5;box-shadow:var(--shadow)}
.popover{width:320px;padding:16px;border:1px solid var(--line-strong);border-radius:var(--radius-container);background:var(--float);box-shadow:var(--rim),var(--shadow-float)}
.menu{width:260px;padding:8px;border:1px solid var(--line-strong);border-radius:var(--radius-container);background:var(--float);box-shadow:var(--rim),var(--shadow-float)}
.menu>button{display:flex;justify-content:flex-start;gap:8px;width:100%;min-height:36px;padding:8px;font-size:var(--text-label)}
.surface-tabs{display:flex;align-items:stretch;gap:4px;height:44px;border-bottom:1px solid var(--line);padding:0 24px}
.surface-tab{border:0;border-radius:0;color:var(--muted-strong);padding:0 12px;height:100%;min-height:0;margin-bottom:-1px;font-size:var(--text-body)}
.surface-tab[aria-selected="true"]{color:var(--ink);border-bottom:2px solid var(--ink);font-weight:600}
.surface-tab-select{margin:8px 0;border:1px solid var(--line);border-radius:var(--radius-control);padding:0 12px;font-size:var(--text-body);height:28px;align-self:center}
/* design-board chrome (NOT product) */
.annot{background:var(--frame);border-top:1px dashed var(--line-strong);padding:10px 16px;font-size:11.5px;line-height:1.55;color:var(--muted-strong)}
.annot b{color:var(--ink)}
.tag.spec{color:var(--muted-strong)}
.board{padding:40px 48px;background:var(--frame);min-height:100%}
.board-title{font-size:22px;font-weight:600;letter-spacing:-0.02em;margin-bottom:6px}
.board-lede{font-size:var(--text-body);color:var(--muted-strong);max-width:880px;line-height:1.6}
.board-grid{display:grid;gap:24px;margin-top:28px}
.cell{background:var(--panel);border:1px solid var(--line);border-radius:var(--radius-card);padding:16px}
.cell h3{font-size:var(--text-section);font-weight:600;margin-bottom:4px}
.cell .why{font-size:var(--text-meta);color:var(--muted-strong);line-height:1.55;margin-top:8px}
.tag{display:inline-block;font-size:var(--text-caption);letter-spacing:.06em;text-transform:uppercase;color:var(--muted-strong);border:1px solid var(--line);border-radius:var(--radius-pill);padding:1px 7px;line-height:1.5}
.tag.rec{color:var(--on-accent);background:var(--accent);border-color:var(--accent)}
.tag.sample{color:var(--danger);border-color:var(--danger)}
.tag.live{color:var(--success);border-color:var(--success)}
.k{font-family:var(--font-mono);font-size:11px}
table.spec{border-collapse:collapse;width:100%;font-size:var(--text-label);line-height:1.5}
table.spec th{text-align:left;font-weight:600;color:var(--muted-strong);font-size:var(--text-meta);padding:6px 10px;border-bottom:1px solid var(--line-strong);vertical-align:bottom}
table.spec td{padding:8px 10px;border-bottom:1px solid var(--line);vertical-align:top}
table.spec td:first-child{font-weight:600;white-space:nowrap}
.swatch{display:inline-block;width:18px;height:18px;border-radius:4px;border:1px solid var(--line-strong);vertical-align:middle;margin-right:6px}
.doc{max-width:900px;margin:0 auto;padding:56px 48px 80px;background:var(--panel);color:var(--ink);line-height:1.6}
.doc h1{font-size:28px;letter-spacing:-0.02em;font-weight:600;margin-bottom:8px}
.doc h2{font-size:18px;font-weight:600;letter-spacing:-0.01em;margin:36px 0 10px;padding-top:16px;border-top:1px solid var(--line)}
.doc h3{font-size:14px;font-weight:600;margin:20px 0 6px}
.doc p,.doc li{font-size:var(--text-body);line-height:1.7}
.doc ul,.doc ol{padding-left:22px;margin:6px 0}
.doc table.spec{margin:10px 0 4px}
.doc table.spec td{font-size:var(--text-label)}
.note{font-size:var(--text-meta);color:var(--muted-strong)}
`;

// Lucide 1.41.0 static subset (app/web/vendor/icons.svg) + candidates drawn on the same 24 grid.
export const ICONS = {
  'activity':'<path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>',
  'arrow-up':'<path d="m5 12 7-7 7 7"/><path d="M12 19V5"/>',
  'arrow-down':'<path d="M12 5v14"/><path d="m19 12-7 7-7-7"/>',
  'chevron-down':'<path d="m6 9 6 6 6-6"/>',
  'chevron-right':'<path d="m9 18 6-6-6-6"/>',
  'copy':'<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
  'download':'<path d="M12 15V3"/><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/>',
  'ellipsis':'<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
  'external-link':'<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
  'file-text':'<path d="M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z"/><path d="M14 2v5a1 1 0 0 0 1 1h5"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
  'folder':'<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>',
  'git-branch':'<path d="M15 6a9 9 0 0 0-9 9V3"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/>',
  'house':'<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  'message-square':'<path d="M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z"/>',
  'panel-left':'<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/>',
  'panel-right':'<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M15 3v18"/>',
  'paperclip':'<path d="m16 6-8.414 8.586a2 2 0 0 0 2.829 2.829l8.414-8.586a4 4 0 1 0-5.657-5.657l-8.379 8.551a6 6 0 1 0 8.485 8.485l8.379-8.551"/>',
  'pause':'<rect x="14" y="3" width="5" height="18" rx="1"/><rect x="5" y="3" width="5" height="18" rx="1"/>',
  'pin':'<path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z"/>',
  'play':'<path d="M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z"/>',
  'plug':'<path d="M12 22v-5"/><path d="M15 8V2"/><path d="M17 8a1 1 0 0 1 1 1v4a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1z"/><path d="M9 8V2"/>',
  'plus':'<path d="M5 12h14"/><path d="M12 5v14"/>',
  'refresh-cw':'<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
  'rotate-ccw':'<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>',
  'search':'<path d="m21 21-4.34-4.34"/><circle cx="11" cy="11" r="8"/>',
  'settings-2':'<path d="M14 17H5"/><path d="M19 7h-9"/><circle cx="17" cy="17" r="3"/><circle cx="7" cy="7" r="3"/>',
  'share-2':'<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/><line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/>',
  'square-pen':'<path d="M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z"/>',
  'square':'<rect width="18" height="18" x="3" y="3" rx="2"/>',
  'thumbs-down':'<path d="M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22a3.13 3.13 0 0 1-3-3.88Z"/><path d="M17 14V2"/>',
  'thumbs-up':'<path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2a3.13 3.13 0 0 1 3 3.88Z"/><path d="M7 10v12"/>',
  'volume-2':'<path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"/><path d="M16 9a5 5 0 0 1 0 6"/><path d="M19.364 18.364a9 9 0 0 0 0-12.728"/>',
  'x':'<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  'maximize-2':'<path d="M15 3h6v6"/><path d="m21 3-7 7"/><path d="m3 21 7-7"/><path d="M9 21H3v-6"/>',
  'minimize-2':'<path d="m14 10 7-7"/><path d="M20 10h-6V4"/><path d="m3 21 7-7"/><path d="M4 14h6v6"/>',
  // ── Candidates (Courtwork-drawn on the Lucide grid: 24 box, 2px stroke, round cap/join, 1px safe edge) ──
  'spark-a':'<rect x="3" y="9" width="6" height="6" rx="1"/><path d="M9 12h3"/><path d="M12 7v10"/><path d="M12 7h9"/><path d="M12 12h9"/><path d="M12 17h9"/>',
  'spark-a2':'<rect x="3" y="8" width="6" height="8" rx="1"/><path d="M9 12h3"/><path d="M12 5v14"/><path d="M12 5h9"/><path d="M12 12h9"/><path d="M12 19h9"/>',
  'spark-b':'<path d="M3 18h5v-6h5V6h8"/><circle cx="21" cy="6" r="1"/>',
  'spark-c':'<path d="M4 20l7-7"/><path d="M11 13a5 5 0 0 1 5-5"/><path d="M14 4v2"/><path d="M20 10h-2"/><path d="m18.5 5.5-1.4 1.4"/>',
  'attn-a':'<path d="M3 7h5"/><path d="M3 12h5"/><path d="M3 17h5"/><path d="M8 12h4"/><circle cx="17" cy="12" r="4"/>',
  'attn-b':'<path d="M4 6h16"/><path d="M10 12h10"/><path d="M4 18h16"/><circle cx="5" cy="12" r="1"/>',
  'attn-c':'<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7"/><circle cx="12" cy="12" r="3"/>',
  // Lucide 1.41.0 donors referenced for the header pair (same family; not yet in the sprite — manifest row required)
  'text':'<path d="M17 6.1H3"/><path d="M21 12.1H3"/><path d="M15.1 18H3"/>',
  'list':'<path d="M3 5h.01"/><path d="M3 12h.01"/><path d="M3 19h.01"/><path d="M8 5h13"/><path d="M8 12h13"/><path d="M8 19h13"/>',
  'bell':'<path d="M10.268 21a2 2 0 0 0 3.464 0"/><path d="M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326"/>',
  'sparkles':'<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/>',
};

export function icon(name, size = 20, extra = '') {
  const body = ICONS[name];
  if (!body) throw new Error('unknown icon ' + name);
  return `<svg class="ui-icon" viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" ${extra}>${body}</svg>`;
}
export const iconBtn = (name, label, cls = 'quiet-button icon-only', size = 18, attrs = '') =>
  `<button type="button" class="${cls}" aria-label="${label}" title="${label}" ${attrs}>${icon(name, size)}</button>`;

// Sidebar exactly as the 1440 captures show it, with the two reopened slots switchable.
export function sidebar({ current = 'home', sparkGlyph = null, attnGlyph = null, projectOpen = 'cedar', chatCurrent = null } = {}) {
  const nav = (key, glyph, label) => `<button type="button" class="nav-home quiet-button" ${current === key ? 'aria-current="page"' : ''}>${glyph ? icon(glyph, 16) : ''}<span>${label}</span></button>`;
  const chat = (key, title, tag) => `<div class="chat-row" ${chatCurrent === key ? 'aria-current="page"' : ''}><span>${title}</span>${tag ? `<span class="tag" style="border:0;padding:0;text-transform:none;letter-spacing:0;font-size:10.5px">${tag}</span>` : ''}</div>`;
  return `<aside class="sidebar">
    <div class="sidebar-header"><a class="workspace-brand" href="#">${icon('panel-left', 16)}<span style="font-size:12px">CourtWork</span></a></div>
    ${nav('new', 'square-pen', 'New chat')}
    ${nav('home', 'house', 'Home')}
    ${nav('attention', attnGlyph, 'Attention')}
    ${nav('spark', sparkGlyph, 'Spark')}
    <div class="nav-filter">${icon('search', 16)}<input type="text" value="" placeholder="Find a chat"></div>
    <div class="section-heading"><h2>Projects <span style="font-weight:400">2</span></h2>${iconBtn('plus', 'New project', 'quiet-button icon-only', 16)}</div>
    <div style="display:flex;flex-direction:column;gap:2px;margin-top:8px">
      <div class="project-row">${icon('chevron-down', 14)}${icon('folder', 16)}<span>Project Cedar review</span></div>
      ${chat('continue', 'Continue Project Cedar re…', 'Work')}
      ${chat('memo', 'Final review memo — working ar…', '')}
      ${chat('refresh', 'Source refresh — Spark de…', 'Work')}
      ${chat('nda', 'Inbound NDA — Project Ce…', 'Work')}
      <div class="project-row" style="margin-top:8px">${icon('chevron-down', 14)}${icon('folder', 16)}<span>Northside housing le…</span></div>
      ${chat('north', 'Northside ledger reconciliation', '')}
    </div>
    <div class="sidebar-foot">${iconBtn('refresh-cw', 'Refresh', 'quiet-button icon-only', 18)}${iconBtn('settings-2', 'Settings', 'quiet-button icon-only', 18)}</div>
  </aside>`;
}

export function page({ file, title, body, dark = false, width = 1440, height = 900, extraCss = '', script = null }) {
  const html = `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
  <title>${title}</title>
  <style>${CSS}${extraCss}
  html,body{height:100%}
  .root{width:${width}px;min-height:${height}px;background:var(--frame);color:var(--ink);overflow:hidden;position:relative}
  </style>
</helmet>
<div class="root${dark ? ' dark' : ''}" style="width: ${width}px; min-height: ${height}px; background: var(--frame); color: var(--ink);">
${body}
</div>
</x-dc>${script ? `\n<script data-dc-script data-props='${script.props}'>\n${script.code}\n</script>` : ''}
</body>
</html>`;
  writeFileSync(file, html);
}
