# identity · 两宗署名与出版骨架（阶段 1）

作者：Claude（Fable 5.1）· 2026-09-11 · 候选，非独立验收。内容输入 CourtWork `0227673`，SE reader 源 `2817b824`。

## 消费来源

| 来源 | repo@SHA · path | SHA-256 | 用途 |
|---|---|---|---|
| 品牌几何（可继承色） | Courtwork@0227673 `brand/les-privilege/mark.svg` | `4535bec6e363cfef3d821a54e6004bbcc58cdea5755bd24301aa764af4f9de8a` | `reader/signature.svg` 的路径与几何来源；逐字复用 `path d` 与两条 `rect` |
| 黑色宗浅底 / 反白 | `mark-light.svg` / `mark-dark.svg` | `55e12a6…4e103` / `965a29d…27333` | 黑色宗明暗对照（reader 内以 `currentColor` 继承正文 ink） |
| 彩色宗上横红 浅底 / 深底 | `mark-tritone-light.svg` / `mark-tritone-dark.svg` | `a1b508e…4e3773` / `6136b08…db2775` | 彩色宗填色值来源 |
| 品牌清单 | `brand/les-privilege/manifest.json` | `f2df3f4047c7c4ffe1acb4760b7db1afa69905c031f2a5fbe5667e4754024ff6` | palette light/dark 六个固定导出值 |
| 品牌登记 | `brand/les-privilege/README.md` | `786a5652617616591cb3932113571f5cfcdd0ada8cfccb09a7443848e3b3ebd5` | 署名拼写、`le` 仅为图形、重复内联须唯一 ID |

品牌 SVG 未描摹、未改几何；`signature.svg` 只把三个填色改为 class 钩子（`lp-l`、`lp-bar-top`、`lp-bar-mid`），`<title>` ID 改为 `lp-mast-title`，以便同一页面内再次内联时不冲突。

## 署名位置与两宗

masthead 一行：左为作品（Schema Engineering · 工作论文 · Edition），右为 maker 署名（22px 标记 + "les Privilege"，系统 sans 550）。页脚右侧重复文字署名与候选标识，不再内联第二个标记。

| 宗 | 触发 | 浅底填色 | 深底填色 | 实例 |
|---|---|---|---|---|
| 黑色宗（默认阅读 masthead） | `body[data-signature="black"]`（`build.py` `SIGNATURE_FAMILY="black"`） | 全部 `currentColor` = `--ink #242d33` | `currentColor` = `--ink #e4ebef` | `masthead-black-light.png` `masthead-black-dark.png` `masthead-black-390-light.png` |
| 彩色宗（封面/发布用途可选） | `body[data-signature="color"]` | L `#242d33` · 上横 `#ad4844` · 中横 `#6f7e88` | L `#e4ebef` · 上横 `#df827b` · 中横 `#95a5af` | `masthead-color-light.png` `masthead-color-dark.png` `masthead-color-390-dark.png` |

两宗共用同一几何、同一排印位置，只换填色；彩色宗的红是身份用色，reader 内任何状态（review 提示、焦点、链接）均不引用它。`build/zh-black.html` 与 `build/zh-color.html` 是同一构建仅切换 `SIGNATURE_FAMILY` 的完整页面，供 Astra 对比。

## 出版骨架：来源 / 采用 / 适配

| 项 | 来源 | 处置 | 候选实现 |
|---|---|---|---|
| 顺序 masthead → metadata → 标题/dek → 封面 → 正文（PP-06） | 消费账 | adapt | masthead（作品+署名）→ 一行安静工具（三卷 · 主题/语言）→ 元数据 eyebrow → 论文自身 h1/h2 → 封面 → 摘要。元数据靠标题，不独占一排 |
| 68ch 阅读列（PP-07、site.css `--site-measure`） | 源索引 §6.3 | adapt | `--reading-width: 68ch`，中文实测列宽 ≈ 636px@1440（body 17px），英文同列；长标题/表/码/引用另行验证，见 verification |
| 冷灰/铅白/石墨材质（PP-04） | `app/web/styles.css@0227673` `:root[data-skin="dystopia"]` 215–261 与 role 288–318 | adopt as static mapping | canvas=paper `#edf1f3/#202b32`，surface=float-s `#f9fbfc/#2a363e`，surface-muted=gray-2 `#e4e9ec/#171f24`，ink=gray-12 `#242d33/#e4ebef`，ink-strong=ink-max `#172025/#f5f8fa`，muted=gray-11 `#54616a/#b2c1ca`，rule=gray-6 `#bdc8cf/#465762`，rule-strong=gray-8 `#7e8d96/#738994`。Review 红沿 reader 既有 `--review-ink` 系统角色，不映射 Dystopia，不映射品牌红 |
| 三卷/中英/主题/hash/back-forward/无脚本（PP-05、源索引 §5） | reader.js 2817b824 | adopt | 结构、`data-*` 钩子、`.view-controls`/`.mode-controls`/`.reader-actions`/`.reader-toc`/`.table-scroll` 类名与 `scroll-margin-top: 8rem` 全部保留；QA 脚本不改即可通过 |
| 宽 figure 突破正文列（PP-03、site.css figure 先例） | 源索引 §6.3 | adapt | ≥1100px 时表格、代码块与封面向右侧留白伸出 `--breakout`（1440: 14rem，1100–1300: 8rem）；<1100 回到列宽 |
| 目录 | 现行 `<details>` | adapt | 标记不变；≥1100px 由 JS 展开为左侧 sticky rail，窄屏折叠；无 JS 时保持折叠的 details |
| 控件 chrome | 现行盒状按钮 | adapt | 文字 tab + 2px 底线当前态，44px 触控高度，焦点环沿 `--focus`；不新增菜单 |
| 版本标识（PP-02） | ONE-SHOT | adopt | `<meta name="reader-candidate" content="paper-v1">`；eyebrow 与页脚写"阅读面候选 2026-09-11 / paper-v1"；Edition/9.6/source-commit 元数据不变；输出文件名加 `-paper-v1` 后缀，不覆盖已跟踪的 2026-09-11 reader 文件 |
| 标题字体 | 现行全 serif | 作者判断（待裁） | 显示标题与 dek 保持 serif；章节标题改系统 sans 600 建立层级；正文 serif 1.0625rem/1.85 |
| Anthropic 三种变体 | external-references | reference only | 只借"类别→标题→日期→封面→正文"的节奏与图文交替；不用其居中版式、暖底色、品牌字体 |
| 社区插画 skill | external-references | not consumed | 未安装、未 fork |
| 请求中的 hex / 尺寸 | 会话助手建议 | reject as source | 一律以 Dystopia 导出值与实测替代 |

## 未做

未改论文正文、译文、manifest；未推送、未部署；黑色宗/彩色宗均为作者渲染实例，未经非作者视觉验收。
