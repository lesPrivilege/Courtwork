# P1 · 来源变化之后，工作如何接续 — three compositions, one fact set

Mount: Home, after the two product atoms (Spark / Attention), before the research figures (DR-06 five beats). Not edited into `site/src/page.mjs`; the mount point is a proposal.

## Fixed claim and facts (identical in all three)

Source s-1 moves rev 1 → 2, so the Matter "Acme inbound NDA" reads source-set revision 3. Spark reads which derivations came from older revisions: c-9 (rev 1) and c-10 (rev 2, supersedes c-9) are behind. The Matter is where it was, at version 7. A person decides on the explicit object (c-10 at rev 3) with a recorded reason and receipt. A new derivation from the current source, c-11, is accepted and becomes version 8. The judgment did not clear the old derivations; c-9 and c-10 stay on the record as stale. The next run starts from what is in effect.

Capability account (kept apart from the story): Spark read = live (BE-41); Matter → Work = live for live rows; the typed human action with reason/receipt = live on Attention items; "new derivation from the current source" = what the Work Core contract allows (`revise_candidate` or a new Run with `supersedes`) — not an automatic rebuild, which does not ship.

| | P1-1 · Sequence | P1-2 · Before / after with a lens | P1-3 · Sheets, branches, convergence |
|---|---|---|---|
| expression | engineering-explanatory: five stations on a rail, owner words under each, a "kept on the record" band | product sequence: the same Matter card before and after, the column of events between, a lens on the kept stale row | abstract: the lifted source sheet (archive-stack), dashed derived views (spark.svg), convergence across a boundary to a ring (attention.svg / atom), a new sheet joining the record |
| borrowed assets | rail + node grammar of pipeline.svg; candidate dashes | fig-00 card language; state words from the App (pending / stale · kept / accepted) | archive-stack sheets, spark.svg derived layer, attention.svg threshold, productAtoms ring |
| abstraction | low | medium | high |
| read order | left → right along the rail, then the band | before card → event column → after card → lens | the arc: sheet → dashed views → boundary → ring → new sheet |
| red | one, station 04 "a person decides" (text equivalent in the caption) | one, the decision row in the event column | one, inside the ring; "a person decides on c-10" beside it |
| static complete | yes | yes | yes |
| min display | 720 plate (scrolls at 390) · compact variant 360 wide provided | same | same |
| motion (optional, not built) | none needed | none; a hover on the lens could show the row's revision — decline: static is complete | the atoms' existing 420 ms transform could shift the dashed views on pointer, reusing the current story toggle; not required |
| files | svg/P1-1-sequence.svg · -compact.svg | svg/P1-2-before-after.svg · -compact.svg | svg/P1-3-abstract.svg · -compact.svg |

## Recommendation

**P1-2 (before / after with a lens).** It is the only composition in which "nothing is erased" is visible without reading a caption: the two stale rows are still on the after card, dashed, next to the accepted one, and the version number moves on the card itself. P1-1 explains the mechanism best but reads as a process diagram on a product page; P1-3 is the most at home beside the atoms but carries the causality only in the caption. If the section must stay close to the atoms' abstraction, P1-3 with P1-2's after-card as an inset is the fallback.

## Author checks

Rendered 1440 / 390, light / dark (png/, render-receipt.json). At 390 the wide plates scroll horizontally inside the site's `.figure-scroll` region (min-width 720, as pipeline.svg does today); the compact variants are the intended 390 view. Text-in-viewBox check in `../text-check.json`. Not run: real site build, forced-colors emulation, greyscale, VoiceOver, 200 %.
