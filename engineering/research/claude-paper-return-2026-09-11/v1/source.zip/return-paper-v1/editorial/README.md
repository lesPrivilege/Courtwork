# editorial · 三个原创编辑插画构图（阶段 2）

作者：Claude（Fable 5.1）· 2026-09-11。同一总命题，三种构图；作者临时选择 E1 接入阅读面，E2/E3 留在对照。作者选择不等于 Astra 接受。

**总命题**（开工单固定）：运行中的执行者与一次输出之外，正式工作结构、证据与判断仍须持续存在。两个入口：E1「执行者可替换，工作结构仍在」；E2「候选经有据判断成为持续成果」；E3 是更简练的第三隐喻。三稿均不画自动恢复、自动过滤即正确或模型拔掉即无条件恢复；没有回流箭头，没有勾选记号。

## 共同语法与来源

- **借用的语法**：满版冷灰场、不规则铅白承载面、石墨手绘线、大面积留白与非对称（研究任务稿 PP-09 的候选语法；社区参考的"背景 / 浅色承载形 / 手绘线"三层只作为方法观察，未复制任何图形、比例或暖色）。
- **原创部分**：全部形状、隐喻、构图与生成器（`tools/gen-editorial.mjs`，固定种子，铅笔线 = 分段折线加低频正弦噪声，承载面 = 抖动多边形经 Catmull-Rom 平滑）。图内无文字；论点由 alt 与正文承担。
- **颜色只有角色**：SVG 内只有 `ed-*` 类，颜色由 CSS 变量给定，明暗是两套独立取值，不是反相。

| 角色 | 含义 | Light（Dystopia `styles.css@0227673`） | Dark |
|---|---|---|---|
| `--ed-field` | 冷灰场 | gray-5 `#c9d5dc` | gray-3 `#2b373f` |
| `--ed-plate` | 铅白承载面 | float-s `#f9fbfc` | gray-11 `#b2c1ca` |
| `--ed-ink-plate` | 承载面上的石墨 | gray-12 `#242d33` | ink-max(light) `#172025` |
| `--ed-ink-field` | 场上的石墨 | gray-12 `#242d33` | gray-11 `#b2c1ca` |
| `--ed-faded` | 已离场/未通过的残迹 | gray-8 `#7e8d96` | gray-7 `#566a76` |
| `--ed-red` | 人的判断点（仅 E2 一处） | reader `--review-ink` `#b42318` | `#ff8f86` |

红不是品牌红（`#ad4844`），也不表示 error/active；它沿 reader 既有 review 语义，只出现在有人裁决的位置，并在 alt 中有文字等价。

## E1 · 可替换的手，留下的结构（推荐）

- **claim**：「一次 Run 会结束，模型会替换，上下文会压缩；Matter、Artifact、Review decision、未完义务与适用边界仍然必须继续存在。正式工作不能与一次生成同时出现或消失。」— `papers/src/canonical.md` 摘要第 15 行；并见 §3 第 248–252 行 P1「Matter over Session」。
- **隐喻**：铅白承载面 = 受治理的 Matter；三张错叠的纸 = Artifact 版本；一行刻痕 = 已提交事件；虚线圆环 = 仍打开的义务；右侧从画外伸入的弧线 = 先后到来的执行者（虚线灰为已离场，实线为当前），每条只在触碰承载面处留下一个刻痕；右下一道离开画面的弧线 = 已经走掉的执行者。承载面不动，手在换。
- **红**：无。
- **alt（zh）**：编辑插画：一块铅白的承载面上留着工作的结构——几张成果的纸、一行已提交的刻痕、一个仍然打开的义务环；右侧几道石墨弧线是先后到来又离开的执行者，只有它们接触承载面时留下的记号被保留下来。
- **alt（en）**：Editorial illustration: on a lead-white bearing surface the structure of the work remains—a few sheets of results, a row of committed notches, one obligation ring still open; on the right, graphite arcs are executors that arrive and leave in turn, and only the marks they left where they touched the surface are kept.
- **裁切/安全区**（宽版 viewBox 1600×840）：必须保留 x 190–1600、y 120–770（承载面与三条触碰弧线延伸到右边缘，右侧不可裁）；可裁到 1600×700（y 70–770）作 21:9 横幅。竖向不裁切，改用紧凑版（780×880，承载面上移、弧线缩短）。
- **推荐理由**：直接对应论文标题「让工作存在于模型之外」与摘要第一句；两个入口中它把"结构持续存在"画成主体，把"执行者"画成来来去去的次要线，与正文责任层次一致；不需要红。

## E2 · 光圈（候选经有据判断成为持续成果）

- **claim**：「未经接受的 finding、plan 与候选成果可以为继续执行和 Review 被保存、检索并进入授权视图，但必须保留候选身份、来源和适用范围。只有通过相应 Contract 的变化，才能更新 authoritative state 或 active Artifact。可见性服务于工作，提交决定效力。」— `canonical.md` §5.5 第 466 行；并见第 470 行 P18「Context is a projection; output is a candidate state update」。
- **隐喻**：左侧虚线松散形 = 候选（带短柄小圆 = 附着的证据）；中央两块铅白之间的窄口 = Review/Authority 的提交边界；窄口边缘一个红点 = 人在此处裁决；右侧一列沉降的白块 = 取得效力的历次版本，最新一块略偏移；窄口下方一个更淡的虚线形 = 未通过的候选，仍可见、未被抹去。
- **红**：一处，含义"人的判断发生在此"；alt 有文字等价。
- **alt（zh）**：编辑插画：左侧几团虚线勾出的候选，各自带着几根短短的证据；中间两块铅白承载面之间只留一道窄口，口沿一个红点标出人作判断的位置；穿过窄口的一条线落到右侧一列沉降的白块上，那是历次取得效力的版本；一团没有通过的候选仍留在窄口下方，没有被擦掉。
- **alt（en）**：Editorial illustration: on the left, candidates sketched in dashed lines, each with a few short stems of evidence; in the middle two lead-white surfaces leave only a narrow aperture, with one red point on its lip where a person judges; a line through the aperture lands on a settled column of white blocks on the right, the versions that acquired effect; one candidate that did not pass remains below the aperture, not erased.
- **裁切/安全区**（1600×840）：必须保留 x 60–1700、y 40–800（三段横向并列，用满宽度）；不建议横向裁切；竖向使用紧凑版（三段改为上/中/下）。
- **说明**：不预设"通过即正确"：红点是判断位置，不是勾。

## E3 · 尾迹（简练的第三隐喻）

- **claim**：「one-shot quality 与 longitudinal work quality 属于不同指标：一次生成可以很好，跨时间工作仍可能因状态未更新、版本覆盖错误、来源失效或错误沉淀而失败。」— `canonical.md` §5.5 第 472 行；并见摘要第 15 行末句「正式工作不能与一次生成同时出现或消失」。
- **隐喻**：向右前行的铅白长形 = 持续中的 Matter；身后散开的虚线 = 已经结束的 Run；长形上带着的三道实刻痕 = 已提交，一道虚刻痕 = 仍是候选。
- **红**：无。
- **alt（zh）**：编辑插画：一块铅白的长形向右前行，身后散开几道虚线尾迹，那是已经结束的执行；长形上带着三道实的刻痕和一道虚的刻痕——已经生效的与仍是候选的。
- **alt（en）**：Editorial illustration: a lead-white elongated form moves to the right, trailing dashed wake lines that are executions already ended; it carries three solid notches and one dashed one—what has acquired effect, and what is still a candidate.
- **裁切/安全区**（1600×840）：保留 x 0–1500、y 100–700；可裁到 1600×600。

## 文件与真实显示尺寸

| 文件 | 说明 |
|---|---|
| `svg/E{1,2,3}-wide.svg` / `-compact.svg` | 独立 SVG，内嵌两套调色（`prefers-color-scheme` 与 `.dark` 类），可单独打开 |
| `svg/*.inline.svg` | 只含角色类，供页面内联（reader.css 定义颜色）；E1 两版即 `papers/reader/cover.svg` / `cover-compact.svg` |
| `png/E*-wide-{light,dark}.png` | 1440 CSS px 宽、DPR 2 → 2880×1512 |
| `png/E*-compact-{light,dark}.png` | 390 CSS px 宽、DPR 2 → 780×880 |
| `generated.json` / `render-receipt.json` | 生成与渲染回执 |

页面内实测（`tools/probe.mjs`，E1 挂载后）：

| 视口 | 使用版本 | 显示尺寸（CSS px） | 线宽换算 |
|---|---|---|---|
| 1440 | wide 1600×840 | 867×455（列 643 + 右侧 breakout） | 2.4 → 1.3 px |
| 1280 | wide | 771×405 | 2.4 → 1.2 px |
| 390 | compact 780×880 | 366×413 | 2.4 → 1.1 px |

无 motion；无字体、位图、滤镜或外部引用。
