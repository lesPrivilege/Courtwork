// source-manifest.json for return-ui-followthrough-v1: consumed inputs, fixed commits, per-file hashes.
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import { join, relative } from 'node:path';
import { execSync } from 'node:child_process';
const [, , ROOT, CW] = process.argv;
const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex');
const walk = (d, out = []) => { for (const n of readdirSync(d).sort()) { const p = join(d, n); const s = statSync(p); if (s.isDirectory()) walk(p, out); else if (!['source-manifest.json', '.DS_Store'].includes(n)) out.push(p); } return out; };
const git = (args) => execSync(`git -C "${CW}" ${args}`, { encoding: 'utf8' }).trim();
const commits = git('log --format=%H%x09%s 26d949b7a24b06b3280b0a3d19f721a76b9b5aef..HEAD').split('\n').reverse().map((l) => { const [h, s] = l.split('\t'); return { sha: h, subject: s }; });
const changed = git('diff --name-only 26d949b7a24b06b3280b0a3d19f721a76b9b5aef HEAD').split('\n').map((f) => ({ path: f, sha256: sha(join(CW, f)) }));
const manifest = {
  package: 'return-ui-followthrough-v1', author: 'Claude (Fable 5.1)', date: '2026-09-11',
  baseline: { courtwork_input: '26d949b7a24b06b3280b0a3d19f721a76b9b5aef', shared_head_at_work: '803cd2a', isolated_branch: 'claude/ui-followthrough-v1', candidate_head: git('rev-parse HEAD'), commits },
  consumed: [
    { repo: 'Courtwork', sha: '26d949b7a24b06b3280b0a3d19f721a76b9b5aef', path: 'engineering/release/claude-ui-followthrough-2026-09-11/ONE-SHOT.md', use: 'dispatch (read at 803cd2a; same bytes at 320e77d+)' },
    { repo: 'Courtwork', sha: '803cd2a', path: 'engineering/research/motto-diff-2026-09-11/{README.md,luna-source-report.md,user-mono-diff.png,user-mono-diff-detail.png}', use: 'visual reference and display-semantics reference' },
    { repo: 'Courtwork', sha: '26d949b7a24b06b3280b0a3d19f721a76b9b5aef', path: 'engineering/research/chat-attention-2026-09-11/README.md', use: 'CA-01 scope' },
    { repo: 'Courtwork', sha: '26d949b7a24b06b3280b0a3d19f721a76b9b5aef', path: 'engineering/design/agent-interface-2026-09-10/{frontend-contract.md,precedent-map.md,change-template.md}', use: 'continuity contract' },
    { repo: 'Courtwork', sha: '26d949b7a24b06b3280b0a3d19f721a76b9b5aef', path: 'engineering/mvp/execution/work-surface-kit/contracts/color-governance.md', use: 'role registration' },
    { repo: 'lesPrivilege/motto', sha: 'a510036ec0ba2a55bbd41bfb8313debd14588fc2', path: 'packages/coding-agent/src/modes/interactive/components/diff.ts', use: 'reference only via Luna report; not read directly, not ported' },
  ],
  changed_files: changed,
  commands: {
    app: ['node --test app/tests/diff-view.test.mjs app/tests/chat-entry.test.mjs', 'npm --prefix app test', 'node tools/lint-colors.mjs', 'node tools/contrast-report.mjs', 'node tools/lint-interaction.mjs', 'node tools/lint-shapes.mjs', 'node tools/lint-materials.mjs', 'node tools/check-doc-links.mjs'],
    site: ['node site/scripts/render-diff-figure.mjs', 'node site/build.mjs', 'node site/scripts/check-figures.mjs', 'node site/scripts/check-links.mjs', 'node site/scripts/check-material.mjs', 'node tools/check-pages-semantics.mjs', 'node site/scripts/preview.mjs --port 8942', 'node site/scripts/verify.mjs --origin http://127.0.0.1:8942/Courtwork/ --cdp-port 19993'],
    app_preview: ['node app/server/index.mjs --data-dir <scratch> --port 8846 (synthetic data dir; one sample project/session created over the local API)'],
  },
  dependencies: { node: '25.9.0 (22+)', app_node_modules: 'symlinked from the shared checkout, read-only', browser: 'headless Google Chrome via CDP', network: 'none' },
  not_run: ['native screen readers / IME', 'real forced-colors render', 'physical print', 'deployment', 'non-author acceptance'],
  outputs: walk(ROOT).map((p) => ({ path: relative(ROOT, p), bytes: statSync(p).size, sha256: sha(p) })),
};
writeFileSync(join(ROOT, 'source-manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
console.log('manifest', manifest.outputs.length, 'files;', commits.length, 'commits');
