// Writes release-manifest.json (the single release manifest) and source-manifest.json (package inventory).
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, statSync, writeFileSync, existsSync } from 'node:fs';
import { join, relative } from 'node:path';
const [, , ROOT, SE] = process.argv; // return dir, isolated SE clone
const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex');
const walk = (d, out = []) => { for (const n of readdirSync(d).sort()) { const p = join(d, n); const s = statSync(p); if (s.isDirectory()) walk(p, out); else if (!['source-manifest.json', '.DS_Store'].includes(n)) out.push(p); } return out; };
const res = (dir) => JSON.parse(readFileSync(join(ROOT, 'verification', dir, 'results.json'), 'utf8')).results;
const count = (rs) => ({ total: rs.length, pass: rs.filter((r) => r.pass).length, fail: rs.filter((r) => !r.pass).map((r) => r.id) });
const dist = (f) => ({ path: `papers/dist/${f}`, bytes: statSync(join(SE, 'papers/dist', f)).size, sha256: sha(join(SE, 'papers/dist', f)) });
const src = (f) => ({ path: f, sha256: sha(join(SE, f)) });
const release = {
  manifest: 'release-manifest.json',
  status: 'pre-publication candidate · NOT PUBLISHED · author checks only',
  author: 'Claude (Fable 5.1)',
  date: '2026-09-11',
  paper_content: { text_revision: '9.6', edition: '2026-09-07', adopted_commit: 'd78fd312955c1f594e59cbdcbb0d3074ac355940', translation_source_commit: 'a0234bc42dda75767554a2da89c247d66c2ad022', unchanged_in_this_candidate: true },
  reader_source: { base: '0f23ad1ebed4ff2ef42394a5b1744eaaff30dd75', candidate_head_in_isolated_clone: 'a6bf14002f165c13a2b164a0ccb556e806e41589 (branch claude/paper-prepublish-v1, scratchpad only)', patch: readdirSync(join(ROOT, 'reader/patch')).filter((f) => f.endsWith('.patch')).map((f) => ({ path: `reader/patch/${f}`, sha256: sha(join(ROOT, 'reader/patch', f)) })), files: ['papers/reader/reader.css', 'papers/reader/reader.js', 'papers/reader/signature.svg', 'papers/reader/cover.svg', 'papers/reader/cover-compact.svg', 'papers/build.py', 'papers/validate.py'].map(src), reader_revision: '2026-09-11', reader_candidate: 'paper-v1' },
  courtwork_baseline: { dispatch_input: 'bf4b8081a1e4c6c3d680d388472f6f5c93092e62', brand_assets_at_input: '0227673 geometry (mark.svg 4535bec6…9de8a); no newer brand asset at bf4b808/HEAD' },
  signature: { status: 'awaiting-astra-icon-finalization', current_asset: src('papers/reader/signature.svg'), geometry_source: 'brand/les-privilege/mark.svg@0227673 sha256 4535bec6e363cfef3d821a54e6004bbcc58cdea5755bd24301aa764af4f9de8a', replace_procedure: 'RELEASE-PLAN.md §4', evidence_for_current_asset: 'identity/signature-specimen-2x.png (16/20/24/32 × mono/colour × light/dark), identity/masthead-*.png (1440/1280/390), verification/run2-fixed print + forced-colors' },
  candidate_outputs: ['index.html', 'index-en.html', 'schema-engineering-2026-09-07-reader-2026-09-11-paper-v1.html', 'schema-engineering-2026-09-07-reader-2026-09-11-paper-v1-en.html'].map(dist),
  reproducibility: { method: 'build_en.py + build.py run twice in the isolated clone; sha256 of index.html and index-en.html compared', result: 'identical' },
  unchanged: { checked: 'papers/src, papers/translations, README, CHANGELOG, build_en.py, qa/, reader.js, signature.svg, cover*.svg and all tracked historical dist files vs 0f23ad1', result: 'unchanged (git diff --quiet + per-file blob hash equality)' },
  commands: { build: ['python3 -m pip install -r papers/requirements.txt', 'python3 papers/build_en.py', 'python3 papers/build.py', 'python3 papers/validate.py'], tests: ['python3 papers/check_translation_alignment.py --self-test', 'python3 papers/qa/test_translation_gate.py', 'python3 papers/qa/test_reader_assets.py'], browser: ['python3 -m http.server 8978 --directory papers/dist', 'node papers/qa/verify_reader.mjs --origin http://127.0.0.1:8978/ --out verification/qa-110 --cdp-port 19983', 'node tools/verify_prepublish.mjs --origin http://127.0.0.1:8978/ --out verification/run2-fixed --cdp-port 19982'], identity: ['node tools/icon-specimen.mjs papers/reader identity "signature@0f23ad1"', 'node tools/shot.mjs identity/list.json identity/receipt.json'] },
  dependencies: { python: '3.10+ (used 3.14) with markdown2==2.5.5', node: '22+ (used 25.9.0), no packages', browser: 'headless Google Chrome via CDP, temporary profile, no network for the reader', fonts: 'system stacks only' },
  verification: { qa_110: count(res('qa-110')), prepublish_baseline_run1: count(res('run1-baseline')), prepublish_after_fix_run2: count(res('run2-fixed')), static_links: 'fragment links 0 missing (zh 240 / en 240); 3–4 external GitHub links HEAD 200; chatgpt-conversation:// scheme links are source citations, not fetched', offline: 'file:// load with mode+hash works; single inline stylesheet, no external scripts; network cut after load keeps mode switching' },
  simulated_not_native: ['200% zoom = 720px viewport at deviceScaleFactor 2 (device metrics), not native browser zoom', 'forced-colors = CDP media-feature emulation; SVG role mapping verified by computed styles, not a native Windows High Contrast render', 'print = CDP print media emulation + Page.printToPDF; no physical print', 'reduced-motion = media emulation'],
  not_run: ['git push / workflow_dispatch / deployment', 'native VoiceOver, NVDA, IME', 'physical printing', 'live site byte comparison (candidate not published)', 'non-author acceptance'],
};
writeFileSync(join(ROOT, 'release-manifest.json'), JSON.stringify(release, null, 2) + '\n');
const outputs = walk(ROOT).map((p) => ({ path: relative(ROOT, p), bytes: statSync(p).size, sha256: sha(p) }));
writeFileSync(join(ROOT, 'source-manifest.json'), JSON.stringify({ package: 'return-paper-prepublish-v1', author: 'Claude (Fable 5.1)', date: '2026-09-11', release_manifest: 'release-manifest.json', consumed: [
  { repo: 'Schema-Engineering', sha: '0f23ad1ebed4ff2ef42394a5b1744eaaff30dd75', path: 'papers/**', use: 'reader base; isolated clone' },
  { repo: 'Courtwork', sha: 'bf4b8081a1e4c6c3d680d388472f6f5c93092e62', path: 'engineering/research/claude-paper-return-2026-09-11/v1/README.md', use: 'eight rulings, integration receipt' },
  { repo: 'Courtwork', sha: '02276730db8a32c24dddd8d514fb4f3b29bf5a5c', path: 'brand/les-privilege/*', use: 'signature geometry and palette (unchanged through bf4b808)' },
], outputs }, null, 2) + '\n');
console.log('release-manifest + source-manifest written', outputs.length);
