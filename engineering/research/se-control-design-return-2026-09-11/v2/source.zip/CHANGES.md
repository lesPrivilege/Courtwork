# Design return v2 · 2026-09-11 · after Astra's ruling (Courtwork main 3f5daf4)

Grant: visualization candidates and canvas revision only. No app/, backend or Pages file was written; nothing here is accepted or published on the site.

## A · Architecture figure candidates (figures/)

| Contract row | Delivered | Not done |
|---|---|---|
| F1 ownership | svg/F1-ownership.svg (new view; Pi in use, Codex/DSH dashed candidates; stable runtime boundary; Work API bypasses the compiler; observations return dotted) | registry row, placement, README compact variant |
| F2 compile / execute / commit | svg/F2-compile-commit.svg (compile → run plan → adapter → runtime; trace ≠ candidate ≠ effective state; Review · Authority with the page's one red; commit via Core; return edge) | same |
| F3 runtime anatomy | svg/F3-runtime-anatomy.svg (Model Adapter + Harness Core + Capabilities + Profile as one composition; Environment below; protocol state beside; Matter outside the chain) | replacing the ASCII figure in architecture.md is Astra's |
| F4 continuity / commitment | F4-continuity-review.md: state-to-commit, pipeline and anatomy-instrument checked edge by edge — all keep; one caption relabel candidate; one README footnote | no redraw (by contract) |
| F5 Schema / Contract / Expert | svg/F5-expert-composition.svg as an optional inset (composition, not containment) | only if F1/F2 leave Expert unclear |

Per-figure sources + hashes, claim/audience, node/edge/maturity lists, red rule, alt text, placement and the author render receipt: figures/FIGURES-README.md. Renders: figures/png (1440 + 390, light + dark, headless Chrome with the site's .fig CSS copied into figures/render.mjs). Semantic checks from the contract's "下一轮接收条件" were walked by the author; independent review is Astra's.

## B · Canvas v2 (canvas-v2/, same artifact URL, version labelled "v2 after Astra ruling")

- Tokens: every board now resolves the effective default-slate cascade (styles.css ~5500–5570 roles, authored plane ~5906, dark authored = float). "Pixel-perfect" withdrawn; boards are drawn specimens at those values.
- Main: depth maps sunken / frame / paper / raised + authored with resolved values; dark chips paint their own ink; states and selection orthogonal; sunken legal; motion row records the 1.6s pulse, 1.8s shimmer and raw 140ms as facts for DR-04.
- Icons: Spark A2 optical candidate (18×14) for DR-02; ring = attention object / judgment convergence; counts abstract; single-colour column relabelled (hand-drawn, not forced-colors).
- HeaderPair: aria-expanded / aria-controls with Open / Hide / Collapse; donor to be vendored by real Lucide filename + sha.
- SparkRebuild: all controls inert with row-level sample tags; invented route removed.
- SparkActivityDark, SparkNarrow, AttentionNarrow, ChatSpace, PagesStory: implementation notes moved to a dashed annotation strip outside the product frame.
- AttentionStates: state / selection / focus may coexist; live = list/detail/query, actions live only when advertised.
- ChatSpace: read-only inspection question (no rebuild path); ChatActions labelled presentation specimen, error status independent of hover.
- ComposerMotion: source-inferred specimen; Stop stays 28×28 through Stopping; shimmer and raw values acknowledged; "CSS-only" withdrawn.
- Settings: Request timeout removed from as-shipped; bracketed numeric gate example in its own not-shipped cell.
- PagesStory: bilingual product copy without construction asides; capability account in the annotation strip.
- Frames raised to hold content; Return widened to 1200. Renders of all 19 boards: canvas-v2/renders.
- RETURN-design.md carries the same list under "v2 · changes" plus two new ledger rows (Astra ruling; CR-01…04 scope).

## Verification (author)

Executed: headless-Chrome renders of all 19 boards and 4 figures; seed --check passes. Source-inferred: token values and selector scope, figure semantics against the canon. Unverified: everything the ruling already listed (VoiceOver, IME, forced-colors emulation, 200% zoom, 1280 product regression, IC-6 blur test, real Pages build).
