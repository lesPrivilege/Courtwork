// Render every SVG in a directory with the site's .fig CSS and campaign palette
// (site/src/site.css @bf7fa82), light + dark, 1440 + 390. Writes html/ and png/
// beside the svg/ directory and a render-receipt.json. Author render only.
import { readFileSync, writeFileSync, mkdirSync, readdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const dir = path.resolve(process.argv[2]);
const FIG_CSS = `
.fig text { fill: currentColor; } .fig .fig-th { font-weight: 600; } .fig .fig-muted { fill: var(--muted-strong); }
.fig .fig-label { font-family: var(--font-mono); letter-spacing: .06em; fill: var(--muted-strong); }
.fig .fig-node { fill: var(--campaign-raised); stroke: currentColor; stroke-width: 1; } .fig .fig-centre, .fig .fig-engaged { stroke-width: 2; }
.fig .fig-set { fill: var(--campaign-soft); stroke-width: 1.5; } .fig .fig-stock { fill: var(--campaign-soft); stroke: currentColor; stroke-width: 1; }
.fig .fig-strata { stroke: var(--muted); stroke-width: 12; stroke-dasharray: 1 7; }
.fig .fig-candidate, .fig .fig-derived { fill: none; stroke: currentColor; stroke-width: 1; stroke-dasharray: 4 3; }
.fig .fig-exiting, .fig .fig-slot, .fig .fig-quiet { fill: none; stroke: var(--muted); stroke-width: 1; } .fig .fig-slot { stroke-dasharray: 4 3; }
.fig .fig-edge { fill: none; stroke: currentColor; stroke-width: 1.5; } .fig .fig-trace { fill: none; stroke: currentColor; stroke-width: 1; stroke-dasharray: 2 3; }
.fig .fig-rule { stroke: var(--campaign-rule); stroke-width: 1; } .fig .fig-threshold { stroke: currentColor; stroke-dasharray: 6 4; }
.fig .fig-attention { fill: var(--campaign-attention-review); }
.fig .fig-sheet { fill: var(--campaign-raised); stroke: var(--campaign-rule); stroke-width: 1; }
.fig .fig-sheet-candidate { fill: var(--campaign-raised); stroke: currentColor; stroke-width: 1; stroke-dasharray: 4 3; }
.fig .fig-paper { fill: var(--campaign-paper); stroke: var(--campaign-rule); stroke-width: 1; }
.fig .fig-serif { font-family: Georgia, 'Times New Roman', serif; }
.fig .fig-ink { fill: currentColor; }
.fig .fig-wire { fill: none; stroke: var(--campaign-rule); stroke-width: 1; }
@media (forced-colors: active) { .fig { color: CanvasText; } .fig text, .fig .fig-muted, .fig .fig-label { fill: CanvasText; }
  .fig .fig-node, .fig .fig-set, .fig .fig-stock, .fig .fig-sheet, .fig .fig-sheet-candidate, .fig .fig-paper { fill: Canvas; stroke: CanvasText; }
  .fig .fig-candidate, .fig .fig-derived, .fig .fig-exiting, .fig .fig-slot, .fig .fig-quiet, .fig .fig-strata, .fig .fig-edge, .fig .fig-trace, .fig .fig-rule, .fig .fig-threshold, .fig .fig-wire { stroke: CanvasText; }
  .fig .fig-attention, .fig .fig-ink { fill: CanvasText; } }`;
const THEMES = {
  light: `--campaign-paper:#f4f5f6;--campaign-raised:#ffffff;--campaign-ink:#282b2d;--campaign-soft:#e1e5e8;--campaign-rule:#a7aeb2;--campaign-attention-review:#b3262d;--ink:#282b2d;--muted-strong:#54616a;--muted:#7e8d96;`,
  dark: `--campaign-paper:#202224;--campaign-raised:#303335;--campaign-ink:#eef0f2;--campaign-soft:#272b2e;--campaign-rule:#62696e;--campaign-attention-review:#ed9396;--ink:#eef0f2;--muted-strong:#b2c1ca;--muted:#82939d;`,
};
const svgDir = path.join(dir, 'svg'); mkdirSync(path.join(dir, 'png'), { recursive: true }); mkdirSync(path.join(dir, 'html'), { recursive: true });
const receipts = [];
for (const name of readdirSync(svgDir).filter(f => f.endsWith('.svg')).sort()) {
  const f = name.replace(/\.svg$/, '');
  const svg = readFileSync(path.join(svgDir, name), 'utf8');
  const vb = svg.match(/viewBox="0 0 ([\d.]+) ([\d.]+)"/); const [w, h] = [Number(vb[1]), Number(vb[2])];
  const compact = /compact/.test(f) || w <= 480;
  for (const [theme, vars] of Object.entries(THEMES)) for (const width of [1440, 390]) {
    // site rule: plate min-width 720 (scrolls at 390); compact/object figures scale to width.
    const plate = compact ? `max-width:${w}px` : (width >= 720 ? `max-width:${Math.min(w, 960)}px` : 'min-width:720px');
    const html = `<!doctype html><html><head><meta charset="utf-8"><style>
:root{${vars}--font-mono:ui-monospace,SFMono-Regular,Menlo,monospace}
html,body{margin:0;background:var(--campaign-paper);color:var(--ink);font:15px/1.6 ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif}
.figure{margin:0;padding:24px;overflow-x:auto}.figure svg.fig{display:block;width:100%;height:auto;color:var(--ink);font-family:inherit;${plate}}
${FIG_CSS}</style></head><body><figure class="figure figure-plate">${svg}</figure></body></html>`;
    const file = path.join(dir, 'html', `${f}-${theme}-${width}.html`); writeFileSync(file, html);
    const drawn = compact ? Math.min(w, width - 48) : (width >= 720 ? Math.min(w, 960) : 720);
    const height = Math.ceil(h * drawn / w) + 48 + 16;
    const out = path.join(dir, 'png', `${f}-${width}-${theme}.png`);
    execFileSync(CHROME, ['--headless=new', '--hide-scrollbars', '--disable-gpu', '--force-device-scale-factor=2', `--window-size=${width},${height}`, `--screenshot=${out}`, `file://${file}`], { stdio: 'ignore' });
    receipts.push({ figure: f, theme, viewport: width, window: [width, height], drawnWidth: drawn, scrolls: !compact && width < 720, file: path.relative(dir, out), viewBox: [w, h], dpr: 2 });
  }
}
writeFileSync(path.join(dir, 'png', 'render-receipt.json'), JSON.stringify({ chrome: 'Google Chrome.app headless (new)', at: new Date().toISOString(), css: 'site/src/site.css .fig rules @bf7fa82 copied into tools/render-figures.mjs (plus .fig-sheet/.fig-paper/.fig-serif/.fig-wire additions used only by candidate figures; listed for Astra)', receipts }, null, 2));
console.log(receipts.length, 'renders →', path.join(dir, 'png'));
