import { page, icon, iconBtn, sidebar } from './shared.mjs';

const sw = (hex) => `<span class="swatch" style="background:${hex}"></span>`;

export function buildSystem(out) {
  // ── Main: recommended system (DG-09) ────────────────────────────────────────
  const grammar = `
  <table class="spec">
    <tr><th style="width:150px">Axis</th><th>Legal combinations (existing tokens only)</th><th style="width:300px">Counter-example / boundary</th></tr>
    <tr><td>Surface</td><td>L0 <span class="k">--frame</span> (sidebar, canvas) → L1 <span class="k">--panel</span> (reading plane) → L2 <span class="k">--float</span> (composer, popover, dialog, selected registry row). Light: L1 = L2 in hue, separated by <span class="k">--line-strong</span> + <span class="k">--shadow-float</span>. Dark: each step is lighter (#111113 → #212225 → #272a2d). Authored plane (user bubble): light = dark authored #202426, dark = <span class="k">--float</span> (CW-PREF-20260911-01).</td><td>No third L0, no "raised" card inside a card, no darker-than-background component in dark (Carbon/Atlassian rule, UE-VG01/02). Attention detail = L2 because it is the object under decision, not because it is "important".</td></tr>
    <tr><td>State</td><td>default → hover <span class="k">--hover</span> (gray-3) → pressed <span class="k">--pressed</span> (gray-5) → selected <span class="k">--selected</span> (gray-4, aria-current/pressed) → focus 2px <span class="k">--focus</span> ring, offset 2. <b>Active ≠ selected</b>: activity is a word (Working / Waiting for you) in <span class="k">--accent-ink</span> plus the 6px dot; selection is a background.</td><td>A running row never gets the selected background; a selected row never gets the accent word. Color-only state is forbidden everywhere (forced-colors, SE-08).</td></tr>
    <tr><td>Color</td><td>Ink roles only: <span class="k">--ink</span>, <span class="k">--muted-strong</span> (text ≥ 4.5:1), <span class="k">--muted</span> (icons, hairlines ≥ 3:1), <span class="k">--accent</span> = ink (solid submit), <span class="k">--danger</span> (text + 2px left rule, never a flood), <span class="k">--success</span> (loaded word), <span class="k">--attention-review</span> (Needs you word, 600 weight).</td><td>New Spark/Attention glyphs take <span class="k">currentColor</span> and inherit the row's role. They never carry a color of their own, never a badge, never a dot.</td></tr>
    <tr><td>Type</td><td>Productive ladder: title 18/600, nav-title 15/600, reading 15 @1.7, body 14 @1.5, section 13/600, label 12, meta 11.5, caption 10.5 caps @0.08em. Mono 12/1.6 for paths, hashes, model ids. Hierarchy by size + weight, not color or rules (WK-120).</td><td>Pages keeps its expressive serif (Georgia campaign) for editorial moments only; no serif enters App controls, tables or composer (UE-VG07 adapt).</td></tr>
    <tr><td>Material</td><td>Solid content planes. Two registered blur consumers only: chrome 12px (Back to latest chip), transient 16px (context popover). Glass always has a solid <span class="k">--float</span> fallback under reduced-transparency and forced-colors.</td><td>No glass on cards, dialogs, message stream, Spark/Attention rows. Material never encodes agent state (EX-SC1 8/8 ignore; iridescent status = anti-example).</td></tr>
    <tr><td>Shape</td><td>control.compact 6 · control.default 8 · surface.card 12 · surface.container 16 · full 999 (only the composer's floating Send/Stop) · 0 for tab strips and edge-flush planes. Concentric: R<sub>child</sub> = max(4, R<sub>parent</sub> − inset).</td><td>New glyph slots do not become circles; the Spark dialog stays 12; Attention registry rows stay 4.</td></tr>
    <tr><td>Motion</td><td>Two durations, one curve: 120ms (color, opacity, border) · 180ms (transform, translate, enter/exit) · <span class="k">cubic-bezier(.2,0,0,1)</span>. One long-lived animation: the 6px running dot pulses 1.6s. Reduced motion = static (no fade, no slide, dot still).</td><td>No shimmer for unknown, no progress for running, no token-rate, no replay of streamed text on reopen; state changes are word changes first, motion second.</td></tr>
    <tr><td>Icons</td><td>Lucide 1.41.0 static subset (35 glyphs), 24 grid, 2px stroke, round cap/join, sizes 16 row / 18 control / 20 nav, hit ≥ 32 desktop, 44 touch. Two reopened slots (Spark, Attention) get Courtwork-drawn glyphs on the same grid + text kept.</td><td>No family migration (WK-163 D). No sparkle, bell, eye. The header pair (overview vs work surface) is resolved by a same-family donor, not a redesign.</td></tr>
  </table>`;

  const depth = (dark) => `
  <div class="cell${dark ? ' dark' : ''}" style="background:var(--frame);border-color:var(--line)">
    <div class="eyebrow" style="margin-bottom:10px">${dark ? 'Dark' : 'Light'} depth map</div>
    <div style="display:flex;gap:10px;align-items:flex-end">
      <div style="flex:1;background:var(--frame);border:1px solid var(--line);border-radius:8px;padding:10px;font-size:11.5px"><div class="k" style="color:var(--muted-strong)">L0 --frame</div><div style="font-weight:600;margin-top:2px">${dark ? '#111113' : '#f0f0f3'}</div><div class="form-help">sidebar · canvas</div></div>
      <div style="flex:1;background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:10px;font-size:11.5px"><div class="k" style="color:var(--muted-strong)">L1 --panel</div><div style="font-weight:600;margin-top:2px">${dark ? '#212225' : '#fdfdfe'}</div><div class="form-help">reading plane</div></div>
      <div style="flex:1;background:var(--float);border:1px solid var(--line-strong);border-radius:8px;padding:10px;font-size:11.5px;box-shadow:var(--shadow-float)"><div class="k" style="color:var(--muted-strong)">L2 --float</div><div style="font-weight:600;margin-top:2px">${dark ? '#272a2d' : '#fdfdfe + shadow'}</div><div class="form-help">composer · popover · dialog</div></div>
      <div style="flex:1;background:var(--authored-surface);color:var(--authored-ink);border-radius:8px;padding:10px;font-size:11.5px"><div class="k" style="color:var(--authored-muted)">authored</div><div style="font-weight:600;margin-top:2px">${dark ? '= --float' : '#202426'}</div><div style="font-size:11.5px;color:var(--authored-muted)">user message</div></div>
    </div>
  </div>`;

  page({
    file: `${out}/Main.dc.html`, title: 'Recommended system', width: 1440, height: 1380,
    body: `<div class="board">
      <div class="eyebrow">Courtwork · SE control surfaces · independent Design return · 2026-09-11 · packet dbd1efe · product a01dee8 · captures f1373cde</div>
      <h1 class="board-title" style="margin-top:8px">One system, two new glyphs, no new tokens.</h1>
      <p class="board-lede">Spark and Attention become visible in the sidebar, in their titles and in small controls through two Courtwork-drawn glyphs that share one reading direction — <b>from work on the left toward the object of judgment on the right</b>. Everything else this packet asked for is expressed with the tokens, states and motion the app already ships: the grammar below is a legal-combination table over existing values, not a parallel token system (DG-09). Sample-only states are marked <span class="tag sample">sample</span>; wired states are marked <span class="tag live">live</span>.</p>
      <div class="board-grid" style="grid-template-columns:1fr 1fr">${depth(false)}${depth(true)}</div>
      <div class="board-grid" style="grid-template-columns:1fr"><div class="cell"><h3>DG-09 · Surface / State / Color / Type / Material / Shape / Motion / Icons — legal combinations</h3>${grammar}</div></div>
      <div class="board-grid" style="grid-template-columns:1fr 1fr 1fr">
        <div class="cell"><h3>Suggested PR order</h3><ol style="padding-left:18px;font-size:12px;line-height:1.7;margin:6px 0 0">
          <li><b>DG-09</b> grammar table into <span class="k">engineering/design/atlas</span> (docs only, no CSS)</li>
          <li><b>DG-01</b> two glyph source SVGs + manifest rows + sprite regen (asset PR); then <span class="k">nav.spark</span> / <span class="k">nav.attention</span> semantic slots switch from text-reserved to glyph+text</li>
          <li><b>DG-06/07</b> header pair: <span class="k">text</span> donor for Chat overview; open-state <span class="k">aria-pressed</span> on the work-surface control</li>
          <li><b>DG-02</b> Spark: state copy + snapshot-conflict + narrow layout (read-only); rebuild stays sample until BE-4x</li>
          <li><b>DG-03</b> Attention: receipt / uncertain / conflict states already live — visual parity pass only</li>
          <li><b>DG-04</b> composer timeline: CSS-only; no new state vocabulary</li>
          <li><b>DG-05</b> Explore: sample adapter behind a flag; backend gap registered</li>
          <li><b>DG-08</b> Pages: Home story revision with before/after; media stays f137</li></ol></div>
        <div class="cell"><h3>What this return does not claim</h3><ul style="padding-left:18px;font-size:12px;line-height:1.7;margin:6px 0 0">
          <li>No acceptance by Astra, no merge, no gate closed.</li><li>No VoiceOver, IME, forced-colors emulation or true 200% zoom was run: those rows read <i>unverified</i>.</li><li>Glyph optical checks are source-inferred on the 24 grid; bbox ratio was computed, blur test was not run.</li><li>Rebuild / recover, Explore lifecycle, read-aloud, feedback, fork, share, pin, download remain capability gaps; drawn only as samples.</li><li>f137 captures are not relabelled; every scene here is a drawn specimen at 1440×900 / 390×844.</li></ul></div>
        <div class="cell"><h3>Open disagreements for Astra</h3><ul style="padding-left:18px;font-size:12px;line-height:1.7;margin:6px 0 0">
          <li><b>Spark glyph A vs B</b> — fan-out (derivations from one source) vs revision ladder. Recommendation: A.</li><li><b>Header pair</b> — donor glyph for overview (recommended) vs folding overview into the work surface as a tab (bigger scope).</li><li><b>Attention item open-state</b> — L2 float row (current) vs selected gray-4. Recommendation: keep float; it is the object under decision, not a selection.</li><li><b>Pages hero</b> — no change proposed; the story section gains a static "after" frame only.</li></ul></div>
      </div>
    </div>`,
  });

  // ── Icons: DG-01 glyph board ────────────────────────────────────────────────
  const sizes = [16, 18, 20, 24];
  const row = (name, label, note, tagHtml) => `
    <div style="display:grid;grid-template-columns:200px 1fr 1fr 1fr 1fr;gap:12px;align-items:center;padding:12px 0;border-bottom:1px solid var(--line)">
      <div><div style="font-weight:600;font-size:13px;display:flex;gap:8px;align-items:center">${label} ${tagHtml || ''}</div><div class="form-help">${note}</div></div>
      <div style="display:flex;gap:18px;align-items:center;background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:10px 14px">${sizes.map(s => `<span style="display:inline-flex;flex-direction:column;align-items:center;gap:4px;color:var(--ink)">${icon(name, s)}<span class="k" style="color:var(--muted-strong)">${s}</span></span>`).join('')}</div>
      <div class="dark" style="display:flex;gap:18px;align-items:center;background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:10px 14px;color:var(--ink)">${sizes.map(s => `<span style="display:inline-flex;flex-direction:column;align-items:center;gap:4px">${icon(name, s)}<span class="k" style="color:var(--muted-strong)">${s}</span></span>`).join('')}</div>
      <div style="display:flex;gap:18px;align-items:center;background:#fff;border:1px solid #000;border-radius:0;padding:10px 14px;color:#000">${sizes.map(s => `<span style="display:inline-flex;flex-direction:column;align-items:center;gap:4px">${icon(name, s)}<span class="k">${s}</span></span>`).join('')}</div>
      <div style="display:flex;gap:10px;align-items:center;background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:10px 14px;color:var(--ink)">${icon('house', 16)}${icon(name, 16)}${icon('activity', 16)}${icon('panel-right', 16)}<span class="form-help" style="margin-left:6px">neighbours at 16</span></div>
    </div>`;

  page({
    file: `${out}/Icons.dc.html`, title: 'Spark & Attention glyphs', width: 1440, height: 1560,
    body: `<div class="board">
      <div class="eyebrow">DG-01 · P0 · native identification for the two reopened slots · input: SE-10 (Lucide 1.41.0 subset), IC-6 canonical geometry, WK-163 D, user reopening 2026-09-11</div>
      <h1 class="board-title" style="margin-top:8px">Two glyphs, one reading direction.</h1>
      <p class="board-lede"><b>Principle.</b> Spark's question is "what derives from this source and is it still current?"; Attention's is "which of the things in motion needs me?". Both glyphs read left → right: <b>Spark</b> is one source block fanning into three derivations; <b>Attention</b> is three streams of work, one of which crosses to the ring of human judgment. Neither carries a state, a badge or a permission — the word next to it does (SE-01, IC-1). Geometry: 24 grid, 2px stroke, round cap/join, 1px safe edge, bbox 18×10–12 (ratio ≈ 0.69, the Lucide median WK-163 measured). Text stays: the nav row is glyph + "Spark" / "Attention"; the accessible name is unchanged.</p>
      <div style="display:grid;grid-template-columns:200px 1fr 1fr 1fr 1fr;gap:12px;margin-top:24px;padding-bottom:6px;border-bottom:1px solid var(--line-strong)"><div class="eyebrow">Candidate</div><div class="eyebrow">Light · 16 / 18 / 20 / 24</div><div class="eyebrow">Dark</div><div class="eyebrow">Forced colors (mono)</div><div class="eyebrow">Optical match · Lucide neighbours</div></div>
      ${row('spark-a', 'Spark A · Fan-out', 'One source (rect 6×6) → wire → spine → three derivations. Reads "derived from" at 16; no collision with git-branch (nodes+curve) or share-2 (three circles).', '<span class="tag rec">recommended</span>')}
      ${row('spark-b', 'Spark B · Revision ladder', 'A rising step line: revision 1 → 2 → 3, ending in the current point. Says "behind by" well, says "sources" less well; can read as chart at 16.', '<span class="tag">alternate</span>')}
      ${row('spark-c', 'Spark C · Strike', 'A flint stroke meeting an arc with rays. Literal spark, but the ray cluster is optically a sparkle/wand — the borrowed AI mark the packet forbids.', '<span class="tag sample">rejected · anti-example</span>')}
      ${row('attn-a', 'Attention A · Stream to ring', 'Three short streams of work; the middle one continues across into a ring (the human). Ring r=4 keeps a 2px inner at 16.', '<span class="tag rec">recommended</span>')}
      ${row('attn-b', 'Attention B · Lifted item', 'A three-line list whose middle line is lifted and marked. Says "one item needs you" but competes with Lucide list/menu at 16.', '<span class="tag">alternate</span>')}
      ${row('attn-c', 'Attention C · Eye', 'Eye + pupil. Semantic collision: visibility / show-password / watch; implies surveillance, not judgment.', '<span class="tag sample">rejected · collision</span>')}
      ${row('bell', 'Not this · bell', 'Generic notification/alarm. Attention is a queue of human decisions, not an alert (SE proposition §1).', '<span class="tag sample">rejected</span>')}
      ${row('sparkles', 'Not this · sparkles', 'Generic AI mark. Spark is source-maintenance, not generation; the glyph would claim a capability the surface does not have.', '<span class="tag sample">rejected</span>')}

      <div class="board-grid" style="grid-template-columns:1fr 1fr 1fr">
        <div class="cell"><h3>In place · nav (20) and title (18)</h3>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:8px">
            <div style="background:var(--frame);border:1px solid var(--line);border-radius:8px;padding:8px"><div class="eyebrow" style="margin:0 0 6px 8px">Recommended</div>
              <button type="button" class="nav-home quiet-button">${icon('house',16)}<span>Home</span></button>
              <button type="button" class="nav-home quiet-button" style="margin-top:4px">${icon('attn-a',16)}<span>Attention</span></button>
              <button type="button" class="nav-home quiet-button" style="margin-top:4px" aria-current="page">${icon('spark-a',16)}<span>Spark</span></button></div>
            <div style="background:var(--frame);border:1px solid var(--line);border-radius:8px;padding:8px"><div class="eyebrow" style="margin:0 0 6px 8px">Baseline · text-reserved (current)</div>
              <button type="button" class="nav-home quiet-button">${icon('house',16)}<span>Home</span></button>
              <button type="button" class="nav-home quiet-button" style="margin-top:4px"><span>Attention</span></button>
              <button type="button" class="nav-home quiet-button" style="margin-top:4px" aria-current="page"><span>Spark</span></button></div>
          </div>
          <div style="display:flex;gap:24px;margin-top:14px;align-items:center"><span class="spark-header" style="gap:8px"><span class="dialog-title">${icon('spark-a',18)}Spark</span></span><span class="dialog-title">${icon('attn-a',18)}Attention</span><span class="form-help">dialog titles, 18</span></div>
          <p class="why">Glyph sits before the word in the row (IC-1: icon + text for navigation). The baseline stays valid as a fallback: if Astra defers DG-01, nothing else in this return depends on the glyphs.</p></div>
        <div class="cell"><h3>Semantic collision ledger</h3>
          <table class="spec"><tr><th>Glyph</th><th>Nearest existing</th><th>Why distinct</th></tr>
          <tr><td>spark-a</td><td>git-branch · share-2 · settings-2</td><td>filled-corner block + straight spine; no circles, no curve</td></tr>
          <tr><td>spark-a</td><td>panel-right</td><td>open right side; no enclosing frame</td></tr>
          <tr><td>attn-a</td><td>activity · search</td><td>ring is right-anchored and entered by a line; no pulse, no handle</td></tr>
          <tr><td>attn-a</td><td>ellipsis</td><td>lines, not dots; ring is 8px wide at 24</td></tr>
          <tr><td>text (donor)</td><td>panel-right</td><td>three lines, no frame — the point of the header pair fix</td></tr></table>
          <p class="why">Construction source: hand-drawn path data on the Lucide 24 grid (this file). Licence: Courtwork-owned; Lucide ISC applies only to the donor rows. Manifest rows: <span class="k">spark.svg</span>, <span class="k">attention.svg</span> under a <span class="k">courtwork</span> block, not under <span class="k">lucide.files</span>.</p></div>
        <div class="cell"><h3>Verification account</h3>
          <table class="spec"><tr><th>Check</th><th>Status</th></tr>
          <tr><td>bbox ratio vs Lucide neighbours</td><td>computed from path extents (18×10 / 18×10) · <i>source-inferred</i></td></tr>
          <tr><td>16px legibility</td><td>rendered on this board at 16/18/20/24 in light, dark, mono · <i>executed (canvas)</i></td></tr>
          <tr><td>Circle/square blur test (IC-6)</td><td><i>unverified</i> — needs the icon specimen page at 8px blur</td></tr>
          <tr><td>forced-colors</td><td>currentColor only, no fills → CanvasText · <i>source-inferred</i></td></tr>
          <tr><td>VoiceOver name</td><td>unchanged ("Spark", "Attention"); glyph aria-hidden · <i>unverified on device</i></td></tr>
          <tr><td>200% zoom</td><td>SVG scales; hit area stays 32/44 · <i>unverified</i></td></tr></table>
          <p class="why">Taste Memory: A/B for each slot are <b>Open Taste</b> until the user or Astra chooses; C rows are <b>Exemplars (rejected)</b> with reasons kept.</p></div>
      </div>
    </div>`,
  });

  // ── HeaderPair: two adjacent panel-right (DG-06/07 input) ───────────────────
  const hdr = (leftGlyph, rightGlyph, rightPressed, label) => `
    <div class="main" style="border:1px solid var(--line);border-radius:8px;overflow:hidden">
      <div class="chat-header"><div class="chat-header-inner"><div class="chat-title-wrap"><h1>Source inspection</h1><span class="run-badge running"><span class="dot"></span>Running</span></div>
        <div class="chat-header-actions">${iconBtn(leftGlyph, 'Chat overview')}${iconBtn(rightGlyph, rightPressed ? 'Hide work surface' : 'Open work surface', 'quiet-button icon-only', 18, rightPressed ? 'aria-pressed="true"' : 'aria-pressed="false"')}</div></div></div>
      <div class="form-help" style="padding:8px 24px">${label}</div>
    </div>`;
  page({
    file: `${out}/HeaderPair.dc.html`, title: 'Header pair: overview vs work surface', width: 1100, height: 720,
    body: `<div class="board">
      <div class="eyebrow">DG-06 / DG-07 input · user screenshot header-controls-user.png · app.mjs show-run-button (openContextSummary) and show-surface-button both take panel-right</div>
      <h1 class="board-title" style="margin-top:8px">Same shape, different object: split them by what they open.</h1>
      <p class="board-lede"><b>Chat overview</b> opens a transient popover summarising this chat's context (a reading of text). <b>Work surface</b> toggles a persistent L2 panel on the right (a place). Only the second one is a panel, so only the second one keeps <span class="k">panel-right</span>. The overview takes the same-family Lucide donor <span class="k">text</span> (three lines) at 18 — a summary, not a place. The work-surface control also gains an open state (<span class="k">aria-pressed</span> → <span class="k">--selected</span>), because "open / hide" is a toggle, while the overview is a one-shot opener and stays stateless.</p>
      <div class="board-grid" style="grid-template-columns:1fr 1fr">
        <div><div class="eyebrow" style="margin-bottom:8px">Current · two panel-right, label-only difference</div>${hdr('panel-right', 'panel-right', false, 'aria-label differs ("Chat overview" / "Open work surface"); visually identical; no open state')}</div>
        <div><div class="eyebrow" style="margin-bottom:8px">Recommended · text + panel-right, surface open</div>${hdr('text', 'panel-right', true, 'overview = text (summary); surface = panel-right with pressed state while the surface is open')}</div>
      </div>
      <div class="board-grid" style="grid-template-columns:1fr 1fr 1fr">
        <div class="cell"><h3>Alternative B · fold overview into the surface</h3><p class="why">Overview becomes the first tab of the work surface; one control remains. Cleaner header, but it changes navigation scope (SE-04 composition, WK-113 tab contract) and makes the summary unreachable while the surface is collapsed on 1024–1679. Not recommended this round; listed for Astra.</p></div>
        <div class="cell"><h3>Alternative C · text label beside the glyph</h3><p class="why">"Overview" as a visible word next to the glyph. Solves the pair, but the 48px band already holds the title + run word; on 1280 the label ellipsizes first. Keep as the narrow fallback only if the donor is refused.</p></div>
        <div class="cell"><h3>Wiring boundary</h3><p class="why"><span class="k">text</span> is a new manifest row (Lucide 1.41.0, same commit bca7e75, sha to be recorded at vendoring — <i>not fetched here</i>). Semantic keys stay: <span class="k">chat.overview</span> glyphRef → <span class="k">text</span>; <span class="k">surface.toggle</span> unchanged. The pressed state is a class + aria on the existing button; no new handler.</p></div>
      </div>
    </div>`,
  });
}
