// Generates the six Pages candidates (+ compact 390 variants) as .fig SVGs.
// Same fact set per passage; three expressions each. Vocabulary: site .fig classes
// plus fig-sheet / fig-sheet-candidate / fig-paper / fig-serif / fig-wire (listed in the receipt).
import { writeFileSync, mkdirSync } from 'node:fs';
import path from 'node:path';
const OUT = path.resolve(process.argv[2]);
mkdirSync(path.join(OUT, 'P1', 'svg'), { recursive: true }); mkdirSync(path.join(OUT, 'P2', 'svg'), { recursive: true });

const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const marker = (id) => `<defs><marker id="${id}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="currentColor" /></marker></defs>`;
const T = (x, y, s, cls = '', size = 12, extra = '') => `<text class="${cls}" x="${x}" y="${y}" font-size="${size}" ${extra}>${esc(s)}</text>`;
const label = (x, y, s) => T(x, y, s, 'fig-label', 11);
// wrap long captions: ~6.1px per char at 11.5px
const para = (x, y, text, width, size = 11.5, lh = 17, cls = 'fig-muted') => {
  const max = Math.floor(width / (size * 0.53)); const words = text.split(' '); const lines = []; let cur = '';
  for (const w of words) { if ((cur + ' ' + w).trim().length > max) { lines.push(cur.trim()); cur = w; } else cur += ' ' + w; }
  if (cur.trim()) lines.push(cur.trim());
  return lines.map((l, i) => T(x, y + i * lh, l, cls, size)).join('');
};
const box = (x, y, w, h, cls = 'fig-node', extra = '') => `<rect class="${cls}" x="${x}" y="${y}" width="${w}" height="${h}" ${extra}/>`;
const edge = (d, id, m, cls = 'fig-edge') => `<path class="${cls}" data-edge="${id}" d="${d}" marker-end="url(#${m})" />`;
const line = (x1, y1, x2, y2, cls = 'fig-rule', extra = '') => `<line class="${cls}" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" ${extra}/>`;
const red = (cx, cy, r = 5, id = 'person') => `<circle class="fig-attention" data-red="${id}" cx="${cx}" cy="${cy}" r="${r}" />`;
const svg = (id, w, h, title, desc, body) => `<svg class="fig" viewBox="0 0 ${w} ${h}" role="img" aria-labelledby="${id}-title ${id}-desc" xmlns="http://www.w3.org/2000/svg">
  <title id="${id}-title">${esc(title)}</title>
  <desc id="${id}-desc">${esc(desc)}</desc>
  ${marker(id + '-arrow')}
${body}
</svg>
`;

// ── shared fact set, P1 ─────────────────────────────────────────────────────
const P1DESC = 'One source, s-1, moves from revision 1 to revision 2, so the Matter "Acme inbound NDA" now reads source set revision 3. Spark reads which derivations came from an older revision: candidates c-9 (from revision 1) and c-10 (from revision 2, superseding c-9) are behind. The Matter is where it was, at version 7, with its recorded versions and candidates. A person decides on the explicit object — c-10 at source revision 3 — with a recorded reason and receipt. A new derivation from the current source, c-11, is accepted and becomes version 8; the judgment itself did not clear the old derivations, and c-9 and c-10 remain on the record as stale. The next run starts from what is now in effect.';

// P1-1 · sequence along a rail (engineering-explanatory)
{
  const W = 960, H = 480, m = 'p1a-arrow';
  const st = (i, x, title, lines, fig) => {
    const y = 60;
    return `<g data-node="station-${i}">${T(x, y, `0${i}`, 'fig-label', 11)}${T(x, y + 22, title, 'fig-th', 14)}${lines.map((l, k) => T(x, y + 42 + k * 16, l, 'fig-muted', 11)).join('')}${fig}</g>`;
  };
  const rail = `${line(16, 250, 944, 250, 'fig-edge', 'stroke-width="1"')}`;
  const stations = [
    st(1, 16, 'A source moves', ['s-1 · revision 1 → 2', 'source set · rev 2 → 3', 'recorded as an event'],
      `${box(24, 150, 56, 70, 'fig-sheet')}${line(36, 172, 68, 172, 'fig-edge', 'stroke-width="2"')}${line(36, 186, 62, 186, 'fig-edge', 'stroke-width="2"')}${line(36, 200, 54, 200, 'fig-edge', 'stroke-width="2"')}<circle class="fig-ink" cx="80" cy="150" r="5" />${T(92, 154, 'rev 2', 'fig-muted', 10)}`),
    st(2, 200, 'Spark reads', ['c-9 · from rev 1 · behind by 2', 'c-10 · from rev 2 · behind by 1', 'counts and words, no alarm'],
      `${box(208, 150, 120, 26, 'fig-candidate')}${T(216, 167, 'c-9 · behind', 'fig-muted', 10.5)}${box(208, 186, 120, 26, 'fig-candidate')}${T(216, 203, 'c-10 · behind', 'fig-muted', 10.5)}`),
    st(3, 384, 'The Matter is found', ['Acme inbound NDA · version 7', 'sources · candidates · decisions', 'all still where they were'],
      `${box(392, 150, 150, 70, 'fig-node fig-centre')}${T(404, 172, 'Acme inbound NDA', 'fig-th', 11.5)}${T(404, 190, 'v7 · source set rev 3', 'fig-muted', 10.5)}${T(404, 206, '2 candidates behind', 'fig-muted', 10.5)}`),
    st(4, 600, 'A person decides', ['on c-10, at source rev 3', 'reason recorded · receipt returned', 'the decision clears nothing'],
      `${box(608, 150, 150, 70, 'fig-node')}${red(622, 172)}${T(634, 176, 'decided', 'fig-th', 11.5)}${T(620, 194, 'request a new derivation', 'fig-muted', 10.5)}${T(620, 210, 'reason · rev 3 · request id', 'fig-muted', 10.5)}`),
    st(5, 800, 'A new version', ['c-11 · from rev 3 · accepted', 'Matter → version 8', 'c-9, c-10 stay recorded'],
      `${box(808, 150, 136, 30, 'fig-node')}${T(818, 169, 'c-11 · rev 3 · v8', 'fig-th', 11)}${box(808, 190, 136, 30, 'fig-node fig-set')}${T(818, 209, 'next run reads v8', 'fig-muted', 10.5)}`),
  ].join('');
  const arrows = [[176, 190], [360, 190], [576, 190], [784, 190]].map(([x, y]) => edge(`M ${x - 12} ${y} H ${x + 4}`, `s${x}`, m)).join('');
  const kept = `${label(16, 300, 'KEPT ON THE RECORD · NOTHING IS ERASED')}${box(200, 316, 744, 56, 'fig-candidate')}${T(212, 338, 'c-9 · derived from rev 1 · stale', 'fig-muted', 11)}${T(212, 356, 'c-10 · derived from rev 2 · stale · supersedes c-9', 'fig-muted', 11)}${T(600, 338, 'reason · request id · receipt', 'fig-muted', 11)}${T(600, 356, 'c-11 · derived from rev 3 · accepted · v8', 'fig-th', 11)}`;
  const foot = `${para(16, 412, 'Red marks the one moment a person judges; every other step is a recorded fact. The kept band is the reason the story can continue: what was decided, and on what, stays readable.', 920)}${T(16, 458, 'Facts: source s-1 rev 1→2 · set rev 3 · c-9 (rev 1), c-10 (rev 2) behind · Matter v7 → v8 via c-11 (rev 3).', 'fig-muted', 11.5)}`;
  writeFileSync(path.join(OUT, 'P1', 'svg', 'P1-1-sequence.svg'), svg('p1a', W, H, 'After a source changes: five things you can check', P1DESC, `${label(16, 24, 'ONE CHANGE OF SOURCE · READ LEFT TO RIGHT')}${rail}${stations}${arrows}${kept}${foot}`));

  // compact: vertical
  const CW = 360, CH = 760, mc = 'p1ac-arrow';
  const cst = (i, y, title, sub1, sub2, fig) => `<g data-node="c-station-${i}">${T(16, y, `0${i}`, 'fig-label', 11)}${T(44, y, title, 'fig-th', 13)}${T(44, y + 16, sub1, 'fig-muted', 10.5)}${T(44, y + 30, sub2, 'fig-muted', 10.5)}${fig}</g>`;
  const cbody = `${label(16, 20, 'ONE CHANGE OF SOURCE · READ TOP TO BOTTOM')}${line(28, 40, 28, 640, 'fig-edge', 'stroke-width="1"')}
${cst(1, 60, 'A source moves', 's-1 · rev 1 → 2 · source set rev 3', 'recorded as an event', `${box(250, 44, 40, 48, 'fig-sheet')}<circle class="fig-ink" cx="290" cy="44" r="4" />`)}
${cst(2, 160, 'Spark reads', 'c-9 (rev 1), c-10 (rev 2) are behind', 'counts and words, no alarm', `${box(250, 146, 96, 18, 'fig-candidate')}${T(256, 159, 'c-9 · behind', 'fig-muted', 9.5)}${box(250, 170, 96, 18, 'fig-candidate')}${T(256, 183, 'c-10 · behind', 'fig-muted', 9.5)}`)}
${cst(3, 260, 'The Matter is found', 'Acme inbound NDA · version 7', 'sources, candidates, decisions in place', `${box(250, 246, 96, 40, 'fig-node fig-centre')}${T(258, 262, 'NDA · v7', 'fig-th', 10)}${T(258, 277, 'rev 3', 'fig-muted', 9.5)}`)}
${cst(4, 360, 'A person decides', 'on c-10 at rev 3 · reason · receipt', 'the decision clears nothing', `${box(250, 346, 96, 40, 'fig-node')}${red(262, 366, 4.5)}${T(272, 370, 'decided', 'fig-th', 10)}`)}
${cst(5, 460, 'A new version', 'c-11 from rev 3 accepted → v8', 'c-9, c-10 stay recorded', `${box(250, 446, 96, 40, 'fig-node')}${T(258, 462, 'c-11 · v8', 'fig-th', 10)}${T(258, 477, 'next run', 'fig-muted', 9.5)}`)}
${[100, 200, 300, 400].map(y => edge(`M 28 ${y + 20} V ${y + 44}`, `c${y}`, mc)).join('')}
${label(16, 560, 'KEPT ON THE RECORD')}${box(16, 572, 330, 56, 'fig-candidate')}${T(26, 592, 'c-9 · stale · c-10 · stale · supersedes c-9', 'fig-muted', 10.5)}${T(26, 610, 'reason · request id · receipt · c-11 accepted · v8', 'fig-muted', 10.5)}
${T(16, 680, 'Red = the one moment a person judges.', 'fig-muted', 11)}${T(16, 698, 'Every other step is a recorded fact.', 'fig-muted', 11)}${T(16, 730, 'Facts shared with the wide view.', 'fig-muted', 10.5)}`;
  writeFileSync(path.join(OUT, 'P1', 'svg', 'P1-1-sequence-compact.svg'), svg('p1ac', CW, CH, 'After a source changes — compact', P1DESC, cbody));
}

// P1-2 · before / after of the same object with a lens (product sequence)
{
  const W = 960, H = 500, m = 'p1b-arrow';
  const card = (x, title, tag, rows, version, set) => `<g data-node="${tag}">${label(x, 44, tag)}${box(x, 56, 300, 250, 'fig-node')}${T(x + 16, 84, title, 'fig-th', 15)}${T(x + 16, 104, `version ${version} · source set revision ${set}`, 'fig-muted', 11)}${line(x + 16, 116, x + 284, 116)}
    ${rows.map(([id, from, state, cls], i) => `${box(x + 16, 128 + i * 40, 268, 30, cls)}${T(x + 26, 147 + i * 40, id, cls === 'fig-candidate' ? 'fig-muted' : 'fig-th', 11.5)}${T(x + 70, 147 + i * 40, from, 'fig-muted', 10.5)}${T(x + 196, 147 + i * 40, state, cls === 'fig-candidate' ? 'fig-muted' : 'fig-th', 10.5)}`).join('')}
    ${T(x + 16, 292, 'obligations · decisions · sources: kept', 'fig-muted', 10.5)}</g>`;
  const before = card(16, 'Acme inbound NDA', 'BEFORE · SOURCE SET REV 2', [['c-9', 'from rev 1', 'pending', 'fig-node'], ['c-10', 'rev 2 · supersedes c-9', 'pending', 'fig-node']], 7, 2);
  const after = card(644, 'Acme inbound NDA', 'AFTER · SOURCE SET REV 3', [['c-9', 'from rev 1', 'stale · kept', 'fig-candidate'], ['c-10', 'from rev 2', 'stale · kept', 'fig-candidate'], ['c-11', 'from rev 3', 'accepted · v8', 'fig-node fig-engaged']], 8, 3);
  const events = `${label(356, 44, 'WHAT HAPPENED IN BETWEEN')}
    ${box(356, 56, 260, 44, 'fig-sheet')}${T(368, 74, 's-1 · revision 1 → 2', 'fig-th', 11.5)}${T(368, 90, 'source set becomes revision 3', 'fig-muted', 10.5)}
    ${edge('M 486 102 V 118', 'e1', m)}
    ${box(356, 120, 260, 44, 'fig-node')}${T(368, 138, 'Spark reads: 2 of 2 behind', 'fig-th', 11.5)}${T(368, 154, 'c-9 (rev 1) · c-10 (rev 2)', 'fig-muted', 10.5)}
    ${edge('M 486 166 V 182', 'e2', m)}
    ${box(356, 184, 260, 58, 'fig-node fig-centre')}${red(372, 204)}${T(384, 208, 'a person decides on c-10', 'fig-th', 11.5)}${T(368, 228, 'request a new derivation · reason · rev 3', 'fig-muted', 10.5)}
    ${edge('M 486 244 V 260', 'e3', m)}
    ${box(356, 262, 260, 44, 'fig-node')}${T(368, 280, 'c-11 from rev 3 · accepted', 'fig-th', 11.5)}${T(368, 296, 'Matter version 7 → 8 · receipt recorded', 'fig-muted', 10.5)}
    ${edge('M 318 180 H 352', 'in', m)}${edge('M 620 180 H 640', 'out', m)}`;
  // lens on the "stale · kept" row of the AFTER card
  const lens = `<g data-node="lens"><circle class="fig-paper" cx="800" cy="420" r="70" /><circle class="fig-rule" cx="800" cy="420" r="70" fill="none" stroke-width="1.5" /><line class="fig-trace" x1="812" y1="160" x2="800" y2="350" />
    ${box(748, 392, 104, 22, 'fig-candidate')}${T(756, 407, 'c-10 · stale · kept', 'fig-muted', 10)}${T(744, 434, 'still readable · bound to rev 2', 'fig-muted', 9)}${T(752, 448, 'superseded, never erased', 'fig-muted', 9)}</g>`;
  const foot = `${para(16, 352, 'The same object, before and after. Nothing left the card: the two stale candidates stayed and one accepted candidate joined; the version moved because a person decided and a new derivation was accepted, not because Spark read a change.', 690)}
    ${T(16, 406, 'Red marks the person’s judgment. Dashed rows are stale candidates kept on the record.', 'fig-muted', 11.5)}
    ${label(16, 450, 'READ ORDER')}${T(16, 470, '1 before card → 2 the column of events → 3 after card → 4 the lens', 'fig-muted', 11)}`;
  writeFileSync(path.join(OUT, 'P1', 'svg', 'P1-2-before-after.svg'), svg('p1b', W, H, 'The same Matter, before and after a source change', P1DESC, `${before}${events}${after}${lens}${foot}`));

  const CW = 360, CH = 820, mc = 'p1bc-arrow';
  const ccard = (y, tag, rows, version, set) => `${label(16, y, tag)}${box(16, y + 10, 328, 60 + rows.length * 34, 'fig-node')}${T(28, y + 32, 'Acme inbound NDA', 'fig-th', 13)}${T(28, y + 48, `version ${version} · source set rev ${set}`, 'fig-muted', 10.5)}${rows.map(([id, from, state, cls], i) => `${box(28, y + 58 + i * 34, 304, 26, cls)}${T(36, y + 75 + i * 34, `${id} · ${from} · ${state}`, cls === 'fig-candidate' ? 'fig-muted' : 'fig-th', 10.5)}`).join('')}`;
  const cbody = `${ccard(20, 'BEFORE · REV 2', [['c-9', 'from rev 1', 'pending', 'fig-node'], ['c-10', 'from rev 2', 'pending', 'fig-node']], 7, 2)}
${edge('M 180 172 V 196', 'c1', mc)}
${label(16, 214, 'IN BETWEEN')}${box(16, 224, 328, 122, 'fig-sheet')}${T(28, 244, 's-1 · rev 1 → 2 · source set rev 3', 'fig-muted', 10.5)}${T(28, 264, 'Spark reads: c-9, c-10 behind', 'fig-muted', 10.5)}${red(34, 286, 4.5)}${T(44, 290, 'a person decides on c-10 · reason · rev 3', 'fig-th', 10.5)}${T(28, 312, 'c-11 from rev 3 · accepted · v7 → v8', 'fig-muted', 10.5)}${T(28, 332, 'receipt recorded', 'fig-muted', 10.5)}
${edge('M 180 348 V 372', 'c2', mc)}
${ccard(390, 'AFTER · REV 3', [['c-9', 'rev 1', 'stale · kept', 'fig-candidate'], ['c-10', 'rev 2', 'stale · kept', 'fig-candidate'], ['c-11', 'rev 3', 'accepted · v8', 'fig-node fig-engaged']], 8, 3)}
${T(16, 580, 'Nothing left the card: two stale candidates', 'fig-muted', 11)}${T(16, 596, 'stayed, one accepted candidate joined.', 'fig-muted', 11)}${T(16, 620, 'The version moved because a person decided', 'fig-muted', 11)}${T(16, 636, 'and a new derivation was accepted.', 'fig-muted', 11)}
${T(16, 670, 'Red = the person’s judgment.', 'fig-muted', 11)}${T(16, 686, 'Dashed = stale candidates kept on the record.', 'fig-muted', 11)}`;
  writeFileSync(path.join(OUT, 'P1', 'svg', 'P1-2-before-after-compact.svg'), svg('p1bc', CW, CH, 'The same Matter, before and after — compact', P1DESC, cbody));
}

// P1-3 · abstract: sheets, branches, convergence
{
  const W = 960, H = 510, m = 'p1c-arrow';
  const body = `${label(16, 24, 'A SOURCE LIFTS · ITS DERIVATIONS FALL BEHIND · ONE OBJECT IS BROUGHT TO A PERSON · A NEW SHEET JOINS THE RECORD')}
  <!-- source sheets: rev 1 below, rev 2 lifted -->
  <g data-node="source-rev1">${box(40, 150, 120, 150, 'fig-sheet', 'transform="rotate(-6 100 225)"')}${T(58, 290, 's-1 · rev 1', 'fig-muted', 10.5, 'transform="rotate(-6 100 225)"')}</g>
  <g data-node="source-rev2">${box(70, 100, 120, 150, 'fig-sheet')}${T(88, 122, 'SOURCE', 'fig-label', 10)}${line(88, 150, 168, 150, 'fig-edge', 'stroke-width="3"')}${line(88, 168, 158, 168, 'fig-edge', 'stroke-width="3"')}${line(88, 186, 140, 186, 'fig-edge', 'stroke-width="3"')}<circle class="fig-ink" cx="190" cy="100" r="6" />${T(88, 238, 's-1 · rev 2 · set rev 3', 'fig-th', 10.5)}</g>
  <!-- branches to derived views -->
  ${line(190, 175, 260, 175, 'fig-wire')}${line(260, 175, 260, 90, 'fig-wire')}${line(260, 90, 330, 90, 'fig-wire')}${line(260, 175, 330, 175, 'fig-wire')}${line(260, 175, 260, 260, 'fig-wire')}${line(260, 260, 330, 260, 'fig-wire')}
  <g data-node="derived-c9">${box(330, 72, 170, 36, 'fig-derived')}${T(342, 94, 'c-9 · from rev 1 · behind', 'fig-muted', 11)}</g>
  <g data-node="derived-c10">${box(330, 157, 170, 36, 'fig-derived')}${T(342, 179, 'c-10 · from rev 2 · behind', 'fig-muted', 11)}</g>
  <g data-node="derived-c11">${box(330, 242, 170, 36, 'fig-node fig-engaged')}${T(342, 264, 'c-11 · from rev 3 · current', 'fig-th', 11)}</g>
  ${label(330, 56, 'DERIVED · CAN BE REBUILT')}${label(330, 300, 'OLD VIEWS STAY DASHED')}
  <!-- convergence to a person -->
  ${line(500, 175, 700, 175, 'fig-edge', 'stroke-width="2"')}${line(500, 90, 640, 160, 'fig-trace')}${line(560, 40, 560, 320, 'fig-rule', 'stroke-dasharray="3 6"')}
  <g data-node="person"><circle class="fig-paper" cx="724" cy="175" r="26" /><circle class="fig-rule" cx="724" cy="175" r="26" fill="none" /><circle class="fig-rule" cx="724" cy="175" r="26" fill="none" stroke="currentColor" />${red(724, 175, 5)}${T(760, 170, 'a person decides on c-10', 'fig-th', 12)}${T(760, 188, 'reason · at rev 3 · receipt', 'fig-muted', 10.5)}</g>
  ${label(580, 326, 'HUMAN JUDGMENT · ONE OBJECT, NOT EVERY CHANGE')}
  <!-- new sheet joins the record -->
  ${edge('M 724 203 V 384 H 594', 'to-record', m)}
  <g data-node="record">${box(480, 340, 100, 60, 'fig-sheet', 'transform="rotate(-4 530 370)"')}${box(490, 354, 100, 60, 'fig-sheet')}${T(502, 376, 'MATTER', 'fig-label', 10)}${T(502, 396, 'v7 → v8', 'fig-th', 11)}</g>
  ${T(330, 356, 'c-9, c-10 recorded as stale', 'fig-muted', 10.5)}${T(330, 372, 'c-11 accepted · the next', 'fig-muted', 10.5)}${T(330, 388, 'run starts from v8', 'fig-muted', 10.5)}
  ${para(16, 428, 'Read the arc: the lifted source sheet, the dashed views it left behind, the one object carried across to a person, the new sheet that joins the record. The dashed views do not vanish; the sheet moved because a person decided and a new derivation was accepted.', 920)}
  ${T(16, 490, 'Red marks the judgment; the boundary line is where work in motion meets a person.', 'fig-muted', 11.5)}`;
  writeFileSync(path.join(OUT, 'P1', 'svg', 'P1-3-abstract.svg'), svg('p1c', W, H, 'A source lifts; one object is brought to a person; a new sheet joins the record', P1DESC, body));

  const CW = 360, CH = 780, mc = 'p1cc-arrow';
  const cbody = `${label(16, 20, 'A SOURCE LIFTS')}
  <g>${box(40, 50, 90, 110, 'fig-sheet', 'transform="rotate(-6 85 105)"')}${box(60, 36, 90, 110, 'fig-sheet')}${line(74, 66, 134, 66, 'fig-edge', 'stroke-width="3"')}${line(74, 82, 124, 82, 'fig-edge', 'stroke-width="3"')}<circle class="fig-ink" cx="150" cy="36" r="5" />${T(74, 134, 's-1 · rev 2', 'fig-th', 10)}${T(170, 60, 'source set', 'fig-muted', 10.5)}${T(170, 76, 'rev 2 → 3', 'fig-muted', 10.5)}</g>
  ${label(16, 190, 'ITS DERIVATIONS FALL BEHIND')}
  ${box(16, 200, 328, 26, 'fig-derived')}${T(24, 217, 'c-9 · from rev 1 · behind (dashed = stale, kept)', 'fig-muted', 10)}
  ${box(16, 234, 328, 26, 'fig-derived')}${T(24, 251, 'c-10 · from rev 2 · behind (kept)', 'fig-muted', 10)}
  ${label(16, 300, 'ONE OBJECT IS BROUGHT TO A PERSON')}
  ${line(16, 340, 200, 340, 'fig-edge', 'stroke-width="2"')}${line(150, 316, 150, 364, 'fig-rule', 'stroke-dasharray="3 6"')}
  <circle class="fig-paper" cx="224" cy="340" r="20" /><circle cx="224" cy="340" r="20" fill="none" stroke="currentColor" />${red(224, 340, 4.5)}${T(254, 337, 'decides on c-10', 'fig-th', 10.5)}${T(254, 352, 'reason · rev 3', 'fig-muted', 10)}
  ${label(16, 410, 'A NEW SHEET JOINS THE RECORD')}
  ${box(30, 430, 100, 60, 'fig-sheet', 'transform="rotate(-4 80 460)"')}${box(40, 444, 100, 60, 'fig-sheet')}${T(52, 466, 'MATTER', 'fig-label', 10)}${T(52, 486, 'v7 → v8', 'fig-th', 11)}
  ${box(170, 444, 174, 26, 'fig-node fig-engaged')}${T(178, 461, 'c-11 · from rev 3 · accepted', 'fig-th', 10)}
  ${T(170, 490, 'c-9, c-10 stay recorded', 'fig-muted', 10)}${T(170, 506, 'next run reads v8', 'fig-muted', 10)}
  ${T(16, 560, 'The dashed views do not vanish;', 'fig-muted', 11)}${T(16, 576, 'the sheet moved because a person', 'fig-muted', 11)}${T(16, 592, 'decided and a new derivation', 'fig-muted', 11)}${T(16, 608, 'was accepted.', 'fig-muted', 11)}
  ${T(16, 640, 'Red = the judgment.', 'fig-muted', 11)}`;
  writeFileSync(path.join(OUT, 'P1', 'svg', 'P1-3-abstract-compact.svg'), svg('p1cc', CW, CH, 'A source lifts — compact', P1DESC, cbody));
}

// ── shared fact set, P2 ─────────────────────────────────────────────────────
const P2DESC = 'Governed work state (the Matter at version 7, its active artifact and open obligations) is projected into a bounded context for one run; with the requirements and permissions this becomes the frozen input of the run. Execution produces two different things: run observations, which stay with their owner as a record and are not work facts, and a candidate, bound to the source revision it was derived from. The candidate becomes part of the work only after validation, evidence and an authority decision — the instance drawn here is a person accepting this version with a reason — which the Work Core commits in one transaction: an artifact is created, the version advances to 8, obligations are updated, and the decision is recorded with its receipt. The next run projects from what is now in effect. The compiler is not on the decision path; runtime control and events belong to the host runtime owner.';

// P2-1 · boundary and loop (engineering)
{
  const W = 960, H = 520, m = 'p2a-arrow';
  const body = `${label(16, 24, 'GOVERNED WORK · ABOVE THE LINE')}${label(16, 330, 'EXECUTION · BELOW THE LINE · RECORDS STAY WITH THEIR OWNER')}
  ${line(16, 312, 944, 312, 'fig-threshold', 'stroke-width="1.5"')}
  <g data-node="state">${box(16, 40, 220, 96, 'fig-node fig-centre')}${T(32, 64, 'Work state · v7', 'fig-th', 14)}${T(32, 84, 'active artifact · obligations', 'fig-muted', 11)}${T(32, 100, 'sources at their revisions', 'fig-muted', 11)}${T(32, 116, 'decisions on record', 'fig-muted', 11)}</g>
  ${edge('M 238 88 H 282', 'state-proj', m)}${T(240, 80, 'projects', 'fig-muted', 10)}
  <g data-node="projection">${box(286, 40, 200, 96, 'fig-node fig-set')}${T(302, 64, 'Context projection', 'fig-th', 13)}${T(302, 84, 'selected versions · s-1 @ rev 2', 'fig-muted', 11)}${T(302, 100, 'contract · obligations', 'fig-muted', 11)}${T(302, 116, 'bounded, rebuildable', 'fig-muted', 11)}</g>
  ${edge('M 488 88 H 532', 'proj-plan', m)}${T(492, 80, '+ policy', 'fig-muted', 10)}
  <g data-node="plan">${box(536, 40, 180, 96, 'fig-node fig-set')}${T(552, 64, 'Run input', 'fig-th', 13)}${T(552, 84, 'frozen for this run', 'fig-muted', 11)}${T(552, 100, 'requirements · permissions', 'fig-muted', 11)}${T(552, 116, 'expected outputs', 'fig-muted', 11)}</g>
  ${edge('M 626 138 V 352', 'plan-exec', m)}
  <g data-node="execution">${box(536, 356, 180, 60, 'fig-node fig-engaged')}${T(552, 380, 'Execution', 'fig-th', 13)}${T(552, 400, 'runtime in use · model · tools', 'fig-muted', 11)}</g>
  ${edge('M 718 386 H 762', 'exec-obs', m)}
  <g data-node="observations">${box(766, 356, 178, 60, 'fig-node')}${T(782, 380, 'Run observations', 'fig-th', 12)}${T(782, 398, 'a record, not a work fact', 'fig-muted', 10.5)}${T(782, 412, 'owner: host runtime store', 'fig-muted', 10.5)}</g>
  ${edge('M 534 386 H 490', 'exec-cand', m)}
  <g data-node="candidate">${box(286, 356, 200, 60, 'fig-candidate')}${T(302, 380, 'Candidate · c-11', 'fig-th', 12)}${T(302, 398, 'bound to source rev 3', 'fig-muted', 10.5)}${T(302, 412, 'not yet part of the work', 'fig-muted', 10.5)}</g>
  ${edge('M 386 354 V 232', 'cand-review', m)}${T(394, 300, 'crosses the line only through the gate', 'fig-muted', 10)}
  <g data-node="review">${box(286, 170, 200, 60, 'fig-node fig-centre')}${T(302, 192, 'Review · Authority', 'fig-th', 13)}${T(302, 210, 'validation · evidence · decision', 'fig-muted', 10.5)}${T(302, 224, 'a Work API action, with a reason', 'fig-muted', 10.5)}</g>
  ${edge('M 284 200 H 240', 'review-commit', m)}${T(238, 192, 'accepts', 'fig-muted', 9.5)}
  <g data-node="commit">${box(16, 170, 220, 60, 'fig-node')}${T(32, 192, 'Commit · one transaction', 'fig-th', 13)}${T(32, 210, 'artifact · version 7 → 8', 'fig-muted', 10.5)}${T(32, 224, 'obligations · decision · receipt', 'fig-muted', 10.5)}</g>
  ${edge('M 126 168 V 140', 'commit-state', m)}${T(134, 156, 'now in effect · next run projects v8', 'fig-muted', 10)}
  ${T(740, 60, 'Two products of one run:', 'fig-th', 12)}${T(740, 80, 'the candidate can become the work;', 'fig-muted', 11)}${T(740, 96, 'the observations never do.', 'fig-muted', 11)}
  ${T(740, 130, 'Neither the projection nor the run', 'fig-muted', 11)}${T(740, 146, 'input decides anything; the Work', 'fig-muted', 11)}${T(740, 162, 'API decision and the Core commit do.', 'fig-muted', 11)}
  ${T(740, 196, 'Run control and events belong to', 'fig-muted', 11)}${T(740, 212, 'the host runtime owner (below).', 'fig-muted', 11)}
  ${para(16, 448, 'Read the loop counter-clockwise: state → projection → run input → execution → candidate → review → commit → state. The dashed line is the one boundary; only a candidate that has been decided crosses it upward.', 920)}
  ${T(16, 500, 'No red: this is a mechanism. The human instance of the decision is drawn in the companion views.', 'fig-muted', 11.5)}`;
  writeFileSync(path.join(OUT, 'P2', 'svg', 'P2-1-boundary-loop.svg'), svg('p2a', W, H, 'How a candidate becomes the work: one boundary, one loop', P2DESC, body));

  const CW = 360, CH = 860, mc = 'p2ac-arrow';
  const nb = (y, h, title, l1, l2, cls = 'fig-node') => `${box(16, y, 328, h, cls)}${T(28, y + 20, title, 'fig-th', 12)}${T(28, y + 37, l1, 'fig-muted', 10.5)}${l2 ? T(28, y + 52, l2, 'fig-muted', 10.5) : ''}`;
  const cbody = `${label(16, 20, 'GOVERNED WORK')}
  ${nb(30, 62, 'Work state · v7', 'active artifact · obligations', 'sources at their revisions', 'fig-node fig-centre')}${edge('M 180 94 V 112', 'a', mc)}
  ${nb(114, 62, 'Context projection', 'selected versions · s-1 @ rev 2', 'bounded, rebuildable', 'fig-node fig-set')}${edge('M 180 178 V 196', 'b', mc)}
  ${nb(198, 62, 'Run input · frozen', 'requirements · permissions', 'expected outputs', 'fig-node fig-set')}${edge('M 180 262 V 290', 'c', mc)}
  ${line(16, 276, 344, 276, 'fig-threshold', 'stroke-width="1.5"')}${label(16, 270, 'EXECUTION · BELOW THE LINE')}
  ${nb(292, 48, 'Execution', 'runtime in use · model · tools', '', 'fig-node fig-engaged')}
  ${edge('M 100 342 V 360', 'd', mc)}${edge('M 260 342 V 360', 'e', mc)}
  ${box(16, 362, 156, 60, 'fig-candidate')}${T(24, 382, 'Candidate · c-11', 'fig-th', 11)}${T(24, 398, 'bound to rev 3', 'fig-muted', 10)}${T(24, 412, 'not yet the work', 'fig-muted', 10)}
  ${box(188, 362, 156, 60, 'fig-node')}${T(196, 382, 'Observations', 'fig-th', 11)}${T(196, 398, 'a record, not a fact', 'fig-muted', 10)}${T(196, 412, 'host runtime store', 'fig-muted', 10)}
  ${edge('M 94 424 V 452', 'f', mc)}${T(104, 442, 'through the gate only', 'fig-muted', 9.5)}
  ${line(16, 446, 344, 446, 'fig-threshold', 'stroke-width="1.5"')}
  ${nb(454, 62, 'Review · Authority', 'validation · evidence · decision', 'a Work API action, with a reason', 'fig-node fig-centre')}${edge('M 180 518 V 536', 'g', mc)}
  ${nb(538, 62, 'Commit · one transaction', 'artifact · version 7 → 8', 'obligations · decision · receipt')}
  ${edge('M 344 570 H 356 V 60 H 346', 'h', mc, 'fig-trace')}${T(24, 626, 'now in effect · next run projects v8', 'fig-muted', 10.5)}
  ${T(16, 670, 'Two products of one run: the candidate', 'fig-muted', 11)}${T(16, 686, 'can become the work; observations never do.', 'fig-muted', 11)}${T(16, 710, 'Only a decided candidate crosses the line.', 'fig-muted', 11)}${T(16, 740, 'No red: a mechanism, not an instance.', 'fig-muted', 11)}`;
  writeFileSync(path.join(OUT, 'P2', 'svg', 'P2-1-boundary-loop-compact.svg'), svg('p2ac', CW, CH, 'One boundary, one loop — compact', P2DESC, cbody));
}

// P2-2 · cross-section strata of one object (product sequence)
{
  const W = 960, H = 530, m = 'p2b-arrow';
  const stratum = (y, h, name, cls, l1, l2, l3) => `<g data-node="${name.toLowerCase().replace(/\W+/g, '-')}">${box(200, y, 520, h, cls)}${T(216, y + 22, name, 'fig-th', 13)}${T(216, y + 40, l1, 'fig-muted', 10.5)}${l2 ? T(216, y + 55, l2, 'fig-muted', 10.5) : ''}${l3 ? T(216, y + 70, l3, 'fig-muted', 10.5) : ''}</g>`;
  const body = `${label(16, 24, 'ONE MATTER, CUT ACROSS · WHAT SINKS INTO THE RECORD, AND THROUGH WHICH LAYER')}
  ${T(16, 70, 'ABOVE THE RECORD', 'fig-label', 10)}${T(16, 90, 'ephemeral', 'fig-muted', 10.5)}
  ${stratum(48, 56, 'Proposal', 'fig-paper', 'what the run drafted · from context projection v7 · s-1 @ rev 2', 'exists only inside the run', '')}
  ${edge('M 460 106 V 122', 'p-c', m)}
  ${T(16, 150, 'SUBMITTED', 'fig-label', 10)}${T(16, 170, 'bound, not yet the work', 'fig-muted', 10.5)}
  ${stratum(124, 72, 'Candidate · c-11', 'fig-candidate', 'bound to source revision 3 · evidence attached · pending', 'readable and reviewable; confers nothing', '')}
  ${edge('M 460 198 V 214', 'c-d', m)}
  ${T(16, 246, 'THE DECISION LAYER', 'fig-label', 10)}${T(16, 266, 'the only way down', 'fig-muted', 10.5)}
  <g data-node="decision">${box(200, 216, 520, 82, 'fig-node fig-centre')}${red(216, 240)}${T(228, 244, 'A person accepts this version', 'fig-th', 13)}${T(216, 264, 'on c-11 · reason recorded · request id bound to the exact content', 'fig-muted', 10.5)}${T(216, 279, 'validation · evidence · authority checked in the same transaction', 'fig-muted', 10.5)}${T(216, 293, 'reject or request evidence would stop here; nothing sinks', 'fig-muted', 10.5)}</g>
  ${edge('M 460 300 V 316', 'd-r', m)}
  ${T(16, 348, 'THE RECORD', 'fig-label', 10)}${T(16, 368, 'in effect · durable', 'fig-muted', 10.5)}
  ${stratum(318, 88, 'Committed · version 8', 'fig-node fig-engaged', 'artifact created · version 7 → 8 · obligations updated', 'decision event + receipt recorded · c-9 and c-10 remain, stale', 'the next run projects from here')}
  ${line(200, 420, 720, 420, 'fig-rule')}${T(216, 440, 'older layers below: v7 · v6 · … (never rewritten)', 'fig-muted', 10.5)}
  <!-- trace column, outside the strata -->
  <g data-node="trace">${line(760, 48, 760, 440, 'fig-rule', 'stroke-dasharray="3 6"')}${label(776, 60, 'BESIDE, NOT INSIDE')}${box(776, 72, 168, 70, 'fig-node')}${T(788, 94, 'Run observations', 'fig-th', 12)}${T(788, 112, 'events · tool calls · usage', 'fig-muted', 10.5)}${T(788, 127, 'a record with its own owner', 'fig-muted', 10.5)}${T(776, 166, 'It never sinks into the', 'fig-muted', 10.5)}${T(776, 181, 'record; you can read it,', 'fig-muted', 10.5)}${T(776, 196, 'it proves nothing about', 'fig-muted', 10.5)}${T(776, 211, 'the work.', 'fig-muted', 10.5)}</g>
  ${para(16, 462, 'Read top to bottom: a proposal is drafted, becomes a bound candidate, passes the decision layer, and only then sinks into the record as version 8. The red dot is the instance where a person decides on this candidate; the trace stays beside the strata.', 920)}
  ${T(16, 508, 'Facts: Matter v7 → v8 · c-11 bound to source rev 3 · accept with reason and request id · c-9 / c-10 kept stale.', 'fig-muted', 11.5)}`;
  writeFileSync(path.join(OUT, 'P2', 'svg', 'P2-2-strata.svg'), svg('p2b', W, H, 'One Matter, cut across: what sinks into the record', P2DESC, body));

  const CW = 360, CH = 760, mc = 'p2bc-arrow';
  const cs = (y, h, name, cls, l1, l2) => `${box(16, y, 328, h, cls)}${T(28, y + 20, name, 'fig-th', 12)}${T(28, y + 37, l1, 'fig-muted', 10)}${l2 ? T(28, y + 52, l2, 'fig-muted', 10) : ''}`;
  const cbody = `${label(16, 20, 'ONE MATTER, CUT ACROSS')}
  ${label(16, 44, 'ABOVE THE RECORD · EPHEMERAL')}${cs(50, 50, 'Proposal', 'fig-paper', 'drafted from projection v7 · s-1 @ rev 2', '')}${edge('M 180 102 V 118', 'a', mc)}
  ${label(16, 136, 'SUBMITTED · BOUND, NOT THE WORK')}${cs(142, 62, 'Candidate · c-11', 'fig-candidate', 'bound to source rev 3 · evidence · pending', 'confers nothing')}${edge('M 180 206 V 222', 'b', mc)}
  ${label(16, 240, 'THE DECISION LAYER · THE ONLY WAY DOWN')}${box(16, 246, 328, 78, 'fig-node fig-centre')}${red(30, 270, 4.5)}${T(40, 274, 'A person accepts this version', 'fig-th', 12)}${T(28, 292, 'reason · request id bound to the content', 'fig-muted', 10)}${T(28, 307, 'reject / request evidence stop here', 'fig-muted', 10)}${edge('M 180 326 V 342', 'c', mc)}
  ${label(16, 360, 'THE RECORD · IN EFFECT')}${cs(366, 78, 'Committed · version 8', 'fig-node fig-engaged', 'artifact · v7 → v8 · obligations updated', 'decision + receipt · c-9 / c-10 kept stale')}
  ${line(16, 456, 344, 456, 'fig-rule')}${T(28, 474, 'older layers below · never rewritten', 'fig-muted', 10)}
  ${label(16, 520, 'BESIDE, NOT INSIDE')}${box(16, 528, 328, 50, 'fig-node')}${T(28, 548, 'Run observations', 'fig-th', 11)}${T(28, 565, 'a record with its own owner · proves nothing about the work', 'fig-muted', 9.5)}
  ${T(16, 620, 'Only the decision layer lets a candidate', 'fig-muted', 11)}${T(16, 636, 'sink into the record.', 'fig-muted', 11)}${T(16, 664, 'Red = the person deciding on this candidate.', 'fig-muted', 11)}`;
  writeFileSync(path.join(OUT, 'P2', 'svg', 'P2-2-strata-compact.svg'), svg('p2bc', CW, CH, 'One Matter, cut across — compact', P2DESC, cbody));
}

// P2-3 · abstract: sheets, projection beam, boundary crossing
{
  const W = 960, H = 560, m = 'p2c-arrow';
  const stackSheet = (x, y, rot, txt) => `${box(x, y, 150, 100, 'fig-sheet', `transform="rotate(${rot} ${x + 75} ${y + 50})"`)}${txt ? T(x + 14, y + 24, txt, 'fig-label', 10) : ''}`;
  const body = `${label(16, 24, 'THE RECORD IS A STACK · A BEAM PROJECTS IT · A DASHED SHEET RETURNS · ONLY THE GATE LETS IT LAND')}
  <!-- stack of committed sheets, bottom-left -->
  <g data-node="stack">${stackSheet(60, 340, -6, '')}${stackSheet(72, 320, 3, '')}${stackSheet(84, 300, -2, 'MATTER · v7 · IN EFFECT')}${T(98, 352, 'artifact · obligations', 'fig-muted', 10.5)}${T(98, 368, 'decisions · sources', 'fig-muted', 10.5)}</g>
  <!-- projection beam -->
  ${line(234, 310, 420, 120, 'fig-trace')}${line(234, 360, 420, 200, 'fig-trace')}${line(234, 335, 420, 160, 'fig-trace')}
  <g data-node="projection">${box(420, 100, 150, 100, 'fig-paper', 'transform="rotate(4 495 150)"')}${T(436, 124, 'CONTEXT', 'fig-label', 10, 'transform="rotate(4 495 150)"')}${T(436, 146, 'a bounded working set', 'fig-muted', 10.5, 'transform="rotate(4 495 150)"')}${T(436, 162, 's-1 @ rev 2 · contract', 'fig-muted', 10.5, 'transform="rotate(4 495 150)"')}${T(436, 178, 'rebuildable, not the record', 'fig-muted', 10.5, 'transform="rotate(4 495 150)"')}</g>
  ${label(250, 250, 'PROJECTED, NOT MOVED')}
  <!-- execution region -->
  ${box(600, 60, 344, 200, 'fig-paper', 'stroke-dasharray="4 3"')}${label(612, 80, 'EXECUTION · A RUN')}${T(612, 100, 'the working set goes in with the run input', 'fig-muted', 10.5)}
  ${edge('M 572 150 H 598', 'ctx-run', m)}
  <g data-node="candidate-sheet">${box(700, 120, 150, 100, 'fig-sheet-candidate', 'transform="rotate(-5 775 170)"')}${T(716, 144, 'CANDIDATE · c-11', 'fig-label', 10, 'transform="rotate(-5 775 170)"')}${T(716, 166, 'bound to rev 3', 'fig-muted', 10.5, 'transform="rotate(-5 775 170)"')}${T(716, 182, 'dashed: not the work yet', 'fig-muted', 10.5, 'transform="rotate(-5 775 170)"')}</g>
  <g data-node="trace-dots">${[0,1,2,3,4,5].map(i => `<circle class="fig-quiet" cx="${620 + i * 16}" cy="236" r="3" />`).join('')}${T(720, 240, 'observations stay here, with their owner', 'fig-muted', 10)}</g>
  <!-- gate -->
  ${edge('M 775 262 V 330', 'cand-gate', m)}
  <g data-node="gate">${line(700, 340, 750, 340, 'fig-edge', 'stroke-width="2"')}${line(800, 340, 850, 340, 'fig-edge', 'stroke-width="2"')}${red(775, 340, 5)}${T(700, 322, 'a person decides · accept · reason · receipt', 'fig-th', 11.5)}${label(700, 380, 'THE GATE · REVIEW · AUTHORITY')}</g>
  <!-- landed sheet -->
  ${edge('M 775 352 V 440 H 492', 'gate-stack', m)}
  <g data-node="landed">${box(290, 390, 200, 100, 'fig-node fig-engaged')}${T(306, 414, 'MATTER · v8 · IN EFFECT', 'fig-label', 10)}${T(306, 436, 'c-11 accepted · obligations updated', 'fig-muted', 10.5)}${T(306, 452, 'c-9 / c-10 kept as stale', 'fig-muted', 10.5)}${T(306, 468, 'lands on top of the stack', 'fig-muted', 10.5)}</g>${edge('M 288 440 H 250', 'landed-stack', m, 'fig-trace')}${T(60, 462, 'next beam projects from v8', 'fig-muted', 10)}
  ${para(16, 512, 'Read the circuit: the stack is projected as a beam onto a working sheet; the run returns a dashed sheet; only through the gate does it land, solid, on top of the stack. The trace dots never leave the execution region.', 920)}
  ${T(16, 552, 'Red marks the gate where a person decides on this candidate.', 'fig-muted', 11.5)}`;
  writeFileSync(path.join(OUT, 'P2', 'svg', 'P2-3-sheets-gate.svg'), svg('p2c', W, H, 'A stack, a beam, a dashed sheet, a gate', P2DESC, body));

  const CW = 360, CH = 820, mc = 'p2cc-arrow';
  const cbody = `${label(16, 20, 'THE RECORD IS A STACK')}
  ${box(40, 60, 140, 80, 'fig-sheet', 'transform="rotate(-5 110 100)"')}${box(52, 44, 140, 80, 'fig-sheet')}${T(64, 66, 'MATTER · v7', 'fig-label', 10)}${T(64, 86, 'artifact · obligations', 'fig-muted', 10)}${T(64, 102, 'decisions · sources', 'fig-muted', 10)}
  ${line(192, 84, 260, 84, 'fig-trace')}${line(192, 100, 260, 100, 'fig-trace')}${T(210, 130, 'projected', 'fig-muted', 10)}
  ${label(16, 170, 'A BEAM PROJECTS IT')}${box(200, 180, 144, 60, 'fig-paper', 'transform="rotate(3 272 210)"')}${T(212, 200, 'CONTEXT', 'fig-label', 10)}${T(212, 218, 'bounded working set', 'fig-muted', 10)}${T(212, 232, 's-1 @ rev 2', 'fig-muted', 10)}
  ${label(16, 280, 'A RUN RETURNS A DASHED SHEET')}${box(16, 290, 328, 120, 'fig-paper', 'stroke-dasharray="4 3"')}${box(40, 306, 144, 60, 'fig-sheet-candidate')}${T(52, 326, 'CANDIDATE · c-11', 'fig-label', 10)}${T(52, 344, 'bound to rev 3 · not the work', 'fig-muted', 9.5)}${[0,1,2,3].map(i => `<circle class="fig-quiet" cx="${212 + i * 14}" cy="330" r="3" />`).join('')}${T(206, 352, 'observations stay', 'fig-muted', 9.5)}${T(206, 366, 'with their owner', 'fig-muted', 9.5)}
  ${edge('M 112 412 V 440', 'a', mc)}
  ${label(16, 460, 'ONLY THE GATE LETS IT LAND')}${line(40, 480, 96, 480, 'fig-edge', 'stroke-width="2"')}${line(128, 480, 184, 480, 'fig-edge', 'stroke-width="2"')}${red(112, 480, 4.5)}${T(200, 477, 'a person decides', 'fig-th', 11)}${T(200, 492, 'accept · reason · receipt', 'fig-muted', 10)}
  ${edge('M 112 492 V 520', 'b', mc)}
  ${box(40, 560, 140, 80, 'fig-sheet', 'transform="rotate(-5 110 600)"')}${box(52, 544, 140, 80, 'fig-node fig-engaged')}${T(64, 566, 'MATTER · v8', 'fig-label', 10)}${T(64, 586, 'c-11 accepted', 'fig-muted', 10)}${T(64, 602, 'c-9 / c-10 kept stale', 'fig-muted', 10)}
  ${T(206, 590, 'lands solid, on top', 'fig-muted', 10)}${T(206, 606, 'next beam from here', 'fig-muted', 10)}
  ${T(16, 680, 'The trace dots never leave the run.', 'fig-muted', 11)}${T(16, 696, 'Only a decided sheet lands on the stack.', 'fig-muted', 11)}${T(16, 724, 'Red = the gate where a person decides.', 'fig-muted', 11)}`;
  writeFileSync(path.join(OUT, 'P2', 'svg', 'P2-3-sheets-gate-compact.svg'), svg('p2cc', CW, CH, 'A stack, a beam, a gate — compact', P2DESC, cbody));
}
console.log('candidates written');
