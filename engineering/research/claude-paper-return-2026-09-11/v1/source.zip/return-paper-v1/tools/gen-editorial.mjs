// Editorial illustration generator · Schema Engineering paper cover candidates.
// Deterministic (seeded) hand-drawn geometry; no text inside the drawings. Roles only —
// colours come from CSS custom properties so light/dark are independent palettes, not inversions.
import { writeFileSync, mkdirSync } from 'node:fs';
const OUT = process.argv[2];
mkdirSync(OUT + '/svg', { recursive: true }); mkdirSync(OUT + '/html', { recursive: true });

function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const f1 = (n) => Math.round(n * 10) / 10;
// pencil line: subdivide and add smooth perpendicular noise
function pencil(points, R, amp = 1.6, step = 11) {
  const ph = [R() * 6.28, R() * 6.28, R() * 6.28];
  const fr = [0.9 + R() * 0.6, 2.1 + R() * 0.8, 4.3 + R() * 1.4];
  const out = []; let dist = 0;
  for (let i = 0; i < points.length - 1; i++) {
    const [x0, y0] = points[i], [x1, y1] = points[i + 1];
    const len = Math.hypot(x1 - x0, y1 - y0); const n = Math.max(2, Math.ceil(len / step));
    const nx = -(y1 - y0) / len, ny = (x1 - x0) / len;
    for (let k = (i === 0 ? 0 : 1); k <= n; k++) {
      const t = k / n; const d = dist + t * len; const u = d / 90;
      const w = amp * (0.5 * Math.sin(u * fr[0] + ph[0]) + 0.3 * Math.sin(u * fr[1] + ph[1]) + 0.2 * Math.sin(u * fr[2] + ph[2]));
      out.push([x0 + (x1 - x0) * t + nx * w, y0 + (y1 - y0) * t + ny * w]);
    }
    dist += len;
  }
  return 'M' + out.map(([x, y]) => `${f1(x)} ${f1(y)}`).join('L');
}
function bez(p0,p1,p2,n=40){const o=[];for(let i=0;i<=n;i++){const t=i/n,u=1-t;o.push([u*u*p0[0]+2*u*t*p1[0]+t*t*p2[0],u*u*p0[1]+2*u*t*p1[1]+t*t*p2[1]]);}return o;}
// arc as polyline
function arcPts(cx, cy, r, a0, a1, n = 40) { const p = []; for (let i = 0; i <= n; i++) { const a = a0 + (a1 - a0) * i / n; p.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]); } return p; }
// irregular plate: jittered polygon smoothed with Catmull-Rom
function plate(cx, cy, rx, ry, n, jitter, R, rot = 0) {
  const pts = [];
  for (let i = 0; i < n; i++) { const a = rot + i / n * 6.2832 + (R() - 0.5) * 0.25; const j = 1 + (R() - 0.5) * jitter; pts.push([cx + rx * j * Math.cos(a), cy + ry * j * Math.sin(a)]); }
  return smooth(pts, 0.75);
}
function smooth(pts, tension = 0.5) {
  const n = pts.length; let d = `M${f1(pts[0][0])} ${f1(pts[0][1])}`;
  for (let i = 0; i < n; i++) {
    const p0 = pts[(i - 1 + n) % n], p1 = pts[i], p2 = pts[(i + 1) % n], p3 = pts[(i + 2) % n];
    const c1 = [p1[0] + (p2[0] - p0[0]) / 6 * tension, p1[1] + (p2[1] - p0[1]) / 6 * tension];
    const c2 = [p2[0] - (p3[0] - p1[0]) / 6 * tension, p2[1] - (p3[1] - p1[1]) / 6 * tension];
    d += `C${f1(c1[0])} ${f1(c1[1])} ${f1(c2[0])} ${f1(c2[1])} ${f1(p2[0])} ${f1(p2[1])}`;
  }
  return d + 'Z';
}
function sheet(x, y, w, h, R, tilt = 0) { // small hand-cut rectangle
  const c = [[x, y], [x + w, y + 1.5], [x + w - 1, y + h], [x - 1, y + h - 1.5]];
  const cx = x + w / 2, cy = y + h / 2, s = Math.sin(tilt), co = Math.cos(tilt);
  const r = c.map(([px, py]) => [cx + (px - cx) * co - (py - cy) * s, cy + (px - cx) * s + (py - cy) * co]);
  return pencil([...r, r[0]], R, 0.8, 8);
}
const P = (d, cls, extra = '') => `<path class="${cls}" d="${d}"${extra}/>`;

// ---------- E1 · Replaceable hand, kept structure ----------
function E1(W, H, compact) {
  const R = rng(11); const out = [];
  out.push(`<rect class="ed-field" x="0" y="0" width="${W}" height="${H}"/>`);
  // plate
  const cx = compact ? W * 0.46 : W * 0.37, cy = compact ? H * 0.36 : H * 0.5;
  const rx = compact ? W * 0.40 : W * 0.27, ry = compact ? H * 0.23 : H * 0.33;
  out.push(P(plate(cx, cy, rx, ry, 9, 0.16, R, 0.4), 'ed-plate'));
  // structure on the plate: three sheets, a ledger of notches, an open obligation ring
  const sx = cx - rx * 0.55, sy = cy - ry * 0.55, sw = rx * 0.5, sh = ry * 0.62;
  out.push(P(sheet(sx + 26, sy + 22, sw, sh, R, -0.05), 'ed-ink-plate ed-thin'));
  out.push(P(sheet(sx + 13, sy + 11, sw, sh, R, 0.02), 'ed-ink-plate ed-thin'));
  out.push(P(sheet(sx, sy, sw, sh, R, 0), 'ed-ink-plate'));
  // lines on the front sheet (content, not text)
  for (let i = 0; i < 4; i++) out.push(P(pencil([[sx + 14, sy + 22 + i * 18], [sx + sw - (i === 3 ? 60 : 18), sy + 22 + i * 18]], R, 0.6, 9), 'ed-ink-plate ed-thin'));
  // ledger: baseline with notches (committed events)
  const lx0 = cx - rx * 0.05, lx1 = cx + rx * 0.72, ly = cy + ry * 0.42;
  out.push(P(pencil([[lx0, ly], [lx1, ly]], R, 0.7, 9), 'ed-ink-plate'));
  const notch = [0.06, 0.22, 0.31, 0.5, 0.63, 0.86];
  notch.forEach((t, i) => { const x = lx0 + (lx1 - lx0) * t; out.push(P(pencil([[x, ly - (i % 2 ? 14 : 18)], [x, ly + 4]], R, 0.5, 6), 'ed-ink-plate')); });
  // open obligation ring (dashed, unfinished)
  out.push(P(pencil(arcPts(cx + rx * 0.58, cy - ry * 0.3, compact ? 26 : 30, 0.4, 5.6, 30), R, 0.9, 8), 'ed-ink-plate ed-dashed'));
  // executors: arcs from the right field touching the plate edge
  const edge = (a) => [cx + rx * 1.0 * Math.cos(a), cy + ry * 1.0 * Math.sin(a)];
  const hands = compact
    ? [{ a: -0.55, r: 150, faded: true, off: 0.25 }, { a: -0.15, r: 190, faded: true, off: 0.45 }, { a: 0.28, r: 230, faded: false, off: 0.6 }]
    : [{ a: -0.7, r: 240, faded: true, off: 0.3 }, { a: -0.25, r: 300, faded: true, off: 0.5 }, { a: 0.22, r: 340, faded: false, off: 0.75 }];
  hands.forEach((h, i) => {
    const [ex, ey] = edge(h.a);
    // a reaching arm from the right edge of the field, bulging upward, ending at the contact point
    const startX = W + 10, startY = ey - h.r * (0.55 + 0.25 * i);
    const ctrl = [ex + h.r * 0.55, ey - h.r * h.off];
    out.push(P(pencil(bez([startX, startY], ctrl, [ex + 2, ey], 48), R, 1.8, 12), h.faded ? 'ed-ink-field ed-faded ed-dashed' : 'ed-ink-field ed-heavy'));
    // contact mark kept on the plate
    out.push(P(pencil([[ex - 12, ey + (h.faded ? 2 : 0)], [ex - 30, ey + 3]], R, 0.5, 6), 'ed-ink-plate'));
  });
  // one arc leaving the frame (executor gone)
  const gx = compact ? W * 0.62 : W * 0.72, gy = compact ? H * 0.78 : H * 0.82;
  out.push(P(pencil(arcPts(gx + 260, gy - 120, 300, 2.2, 2.95, 36), R, 1.6, 12), 'ed-ink-field ed-faded ed-dashed'));
  return out.join('');
}

// ---------- E2 · Aperture ----------
function E2(W, H, compact) {
  const R = rng(23); const out = [];
  out.push(`<rect class="ed-field" x="0" y="0" width="${W}" height="${H}"/>`);
  // candidates on the left: loose overlapping shapes, dashed = candidate identity
  const cxL = compact ? W * 0.3 : W * 0.2, cyL = compact ? H * 0.24 : H * 0.48;
  const sizes = compact ? [[110, 70], [90, 60], [120, 58]] : [[170, 110], [140, 90], [190, 84]];
  sizes.forEach(([a, b], i) => {
    const ox = (i - 1) * (compact ? 40 : 60) + (R() - 0.5) * 30, oy = (i - 1) * (compact ? 34 : 50) + (R() - 0.5) * 30;
    out.push(P(plate(cxL + ox, cyL + oy, a, b, 8, 0.28, R, R() * 3), 'ed-ink-field ed-dashed ed-fill-none'));
    // evidence stems: short lines with tiny circles attached to the candidate
    for (let k = 0; k < 2; k++) {
      const ang = R() * 6.28; const px = cxL + ox + a * 1.05 * Math.cos(ang), py = cyL + oy + b * 1.05 * Math.sin(ang);
      const qx = px + 34 * Math.cos(ang), qy = py + 34 * Math.sin(ang);
      out.push(P(pencil([[px, py], [qx, qy]], R, 0.6, 7), 'ed-ink-field ed-thin'));
      out.push(`<circle class="ed-ink-field ed-fill-none ed-thin" cx="${f1(qx + 5 * Math.cos(ang))}" cy="${f1(qy + 5 * Math.sin(ang))}" r="5"/>`);
    }
  });
  // threshold: tall lead-white plate with an aperture (two pieces)
  const tx = compact ? W * 0.62 : W * 0.5, gap = compact ? 42 : 56, tw = compact ? 130 : 200;
  const top = compact ? H * 0.06 : H * 0.08, bot = compact ? H * 0.62 : H * 0.92, mid = compact ? H * 0.34 : H * 0.52;
  out.push(P(plate(tx, (top + mid - gap / 2) / 2, tw / 2, (mid - gap / 2 - top) / 2, 9, 0.12, R, 1.1), 'ed-plate'));
  out.push(P(plate(tx, (mid + gap / 2 + bot) / 2, tw / 2, (bot - mid - gap / 2) / 2, 9, 0.12, R, 0.3), 'ed-plate'));
  // the judging point: one red mark at the aperture lip (a person judges here)
  out.push(`<circle class="ed-red" cx="${f1(tx - tw * 0.36)}" cy="${f1(mid - gap / 2 - 10)}" r="${compact ? 6 : 7}"/>`);
  // path of the accepted candidate through the aperture to the settled column
  const colx = compact ? W * 0.62 : W * 0.78, colBase = compact ? H * 0.94 : H * 0.86;
  const blockW = compact ? 120 : 150, blockH = compact ? 30 : 36;
  const nBlocks = compact ? 5 : 6;
  // settled blocks (accepted versions), newest on top slightly offset
  for (let i = 0; i < nBlocks; i++) {
    const y = colBase - (i + 1) * (blockH + 6); const dx = (R() - 0.5) * 10;
    const bx = colx - blockW / 2 + dx + (i === nBlocks - 1 ? 14 : 0);
    out.push(P(smooth([[bx, y], [bx + blockW, y + 1], [bx + blockW - 2, y + blockH], [bx + 1, y + blockH - 1]], 0.2), 'ed-plate ed-plate-edge'));
  }
  const newestY = colBase - nBlocks * (blockH + 6);
  const from = [tx, mid], to = compact ? [colx - blockW / 2 + 14, newestY + blockH / 2] : [colx - blockW / 2 + 14, newestY + blockH / 2];
  const via = compact ? [[tx + 40, mid + 40], [colx - 60, newestY - 60]] : [[tx + 120, mid - 10], [to[0] - 60, to[1] - 10]];
  out.push(P(pencil([from, ...via, to], R, 1.2, 10), 'ed-ink-field'));
  // small arrow head hint (a solid dot at arrival, not an arrow glyph)
  out.push(`<circle class="ed-ink-fill-field" cx="${f1(to[0])}" cy="${f1(to[1])}" r="4"/>`);
  // one candidate that did not pass stays as a faint ghost near the threshold, not erased
  out.push(P(plate(tx - (compact ? 120 : 170), mid + (compact ? 120 : 140), compact ? 60 : 90, compact ? 34 : 50, 8, 0.25, R, 2.0), 'ed-ink-field ed-faded ed-dashed ed-fill-none'));
  return out.join('');
}

// ---------- E3 · Wake ----------
function E3(W, H, compact) {
  const R = rng(37); const out = [];
  out.push(`<rect class="ed-field" x="0" y="0" width="${W}" height="${H}"/>`);
  const cx = compact ? W * 0.58 : W * 0.68, cy = compact ? H * 0.3 : H * 0.42;
  const rx = compact ? W * 0.3 : W * 0.19, ry = compact ? H * 0.11 : H * 0.15;
  // wake: dashed pencil lines fanning to the left/behind, fading with distance
  const lanes = compact ? 5 : 7;
  for (let i = 0; i < lanes; i++) {
    const t = (i / (lanes - 1) - 0.5);
    const y0 = cy + t * ry * 2.6, x0 = cx - rx * 0.9;
    const len = (compact ? W * 0.55 : W * 0.5) * (0.55 + 0.45 * (1 - Math.abs(t) * 1.4)) + R() * 60;
    const yEnd = y0 + t * (compact ? 90 : 160) + (R() - 0.5) * 40;
    const x1 = compact ? x0 - len * 0.9 : x0 - len; const y1 = compact ? yEnd + len * 0.55 : yEnd;
    out.push(P(pencil(bez([x0, y0], [x0 - len * 0.5, y0 + t * (compact ? 30 : 60)], [x1, y1], 30), R, 2.4, 12), `ed-ink-field ed-dashed ${Math.abs(t) > 0.3 ? 'ed-faded' : ''}`));
  }
  // the matter: an elongated lead-white form
  out.push(P(plate(cx, cy, rx, ry, 10, 0.14, R, 0.1), 'ed-plate'));
  // committed marks carried on the form: three solid, one dashed candidate
  const marks = [[-0.55, -0.1], [-0.2, 0.15], [0.15, -0.2], [0.5, 0.1]];
  marks.forEach(([mx, my], i) => {
    const x = cx + rx * mx, y = cy + ry * my;
    const d = pencil([[x - 14, y + 10], [x + 14, y - 10]], R, 0.5, 6);
    out.push(P(d, i === 3 ? 'ed-ink-plate ed-dashed' : 'ed-ink-plate ed-heavy'));
  });
  return out.join('');
}

const STYLE_INLINE = ''; // reader.css owns the roles when mounted in the page
const STYLE_STANDALONE = `<style>
svg{--ed-field:#c9d5dc;--ed-plate:#f9fbfc;--ed-ink-plate:#242d33;--ed-ink-field:#242d33;--ed-faded:#7e8d96;--ed-red:#b42318}
@media (prefers-color-scheme:dark){svg{--ed-field:#2b373f;--ed-plate:#b2c1ca;--ed-ink-plate:#172025;--ed-ink-field:#b2c1ca;--ed-faded:#566a76;--ed-red:#ff8f86}}
svg.dark{--ed-field:#2b373f;--ed-plate:#b2c1ca;--ed-ink-plate:#172025;--ed-ink-field:#b2c1ca;--ed-faded:#566a76;--ed-red:#ff8f86}
${roleCss()}</style>`;
function roleCss() {
  return `.ed-field{fill:var(--ed-field)}.ed-plate{fill:var(--ed-plate);stroke:none}.ed-plate-edge{stroke:var(--ed-ink-plate);stroke-width:1;stroke-opacity:.35}
.ed-ink-plate{fill:none;stroke:var(--ed-ink-plate);stroke-width:2.4;stroke-linecap:round;stroke-linejoin:round}
.ed-ink-field{fill:none;stroke:var(--ed-ink-field);stroke-width:2.4;stroke-linecap:round;stroke-linejoin:round}
.ed-ink-fill-field{fill:var(--ed-ink-field)}.ed-fill-none{fill:none}
.ed-thin{stroke-width:1.5}.ed-heavy{stroke-width:3.2}.ed-dashed{stroke-dasharray:7 8}.ed-faded{stroke:var(--ed-faded)}
.ed-red{fill:var(--ed-red)}`;
}
export { roleCss };
const comps = { E1, E2, E3 };
const sizes = { wide: [1600, 840], compact: [780, 880] };
const manifest = [];
for (const [name, fn] of Object.entries(comps)) {
  for (const [kind, [W, H]] of Object.entries(sizes)) {
    const body = fn(W, H, kind === 'compact');
    const inline = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" data-editorial="${name}-${kind}">${body}</svg>`;
    const standalone = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="Schema Engineering editorial illustration ${name} (${kind})">${STYLE_STANDALONE}${body}</svg>`;
    writeFileSync(`${OUT}/svg/${name}-${kind}.svg`, standalone);
    writeFileSync(`${OUT}/svg/${name}-${kind}.inline.svg`, inline);
    for (const theme of ['light', 'dark']) {
      const html = `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0;background:${theme === 'dark' ? '#202b32' : '#edf1f3'}}svg{display:block;width:100vw;height:auto}</style>${standalone.replace('<svg ', `<svg class="${theme}" `)}`;
      writeFileSync(`${OUT}/html/${name}-${kind}-${theme}.html`, html);
      manifest.push({ name, kind, theme, html: `${OUT}/html/${name}-${kind}-${theme}.html`, w: W, h: H });
    }
  }
}
writeFileSync(`${OUT}/generated.json`, JSON.stringify(manifest, null, 2));
console.log('generated', manifest.length, 'render pages');
