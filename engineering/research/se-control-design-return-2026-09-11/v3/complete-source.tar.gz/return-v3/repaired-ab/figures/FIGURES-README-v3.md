# Architecture figure candidates · v3 (repaired per the v2 receipt)

Content input `bf7fa82abe4b1e02bc470ff077ef6aba52000654`; checkout HEAD at authoring `b7b7be8fdd64261385978e3e41bcc1a9c63aeed1` (docs-only difference: the dispatched one-shot). Semantic sources unchanged from v2 (canon, architecture.md, reconciliation, figures.json, diagram.svg, pipeline.svg — hashes in `../../source-manifest.json`). **Correction:** the v2 README mistyped the roles.svg hash; the correct value is `a6ec15e1d79c19e3e443186ebde1ece956043c43a378ad69e07eedc211901` (verified against the checkout). The v2 file is left as archived.

| Figure | v2 receipt item | v3 change |
|---|---|---|
| F1 ownership | long labels overflowed Expert / Compiler / Run Plan / adapter; right side unbalanced | boxes widened to 300, copy shortened; right column now carries a MATURITY block (Core / Surface / adapter seam implemented; Compiler + Run Plan target; boundary target — service still calls the Pi session manager; Codex / DSH candidates) |
| F1 | merged return edge mixed trace and candidates | split: candidates → Work Core via the extension work adapter (dotted, left); run events · telemetry → a new "Host runtime store" node (dotted, from Pi) |
| F2 compile / commit | Review subtext overflowed; Runtime → candidate edge had a gap | Review box 72 high with two lines; edge start moved to the Runtime box edge |
| F2 | "record" wording; owners | observations = "a record, not a work fact"; left prose separates Work queries / decisions (Core) from run control / events (host runtime owner); desc says "the instance where a person decides" |
| F3 runtime anatomy | fidelity stated as done; observations exclusive to adapter | protocol state: "the execution owner is obliged to keep it recoverable · recoverability unproven today (DRT-02)"; right column: candidates via work adapter, events to host store; today vs target split |
| F4 | caption / footnote | see `F4-captions.md` — proposed copy only |
| F5 composition | surface implied UI authority; no real compact view | "surface metadata · presentation, not UI authority"; `F5-expert-composition-compact.svg` (360×330, stacked) |

Per-figure claim, audience, placement, node / edge lists and the red rule are unchanged from v2 and stay in the archived v2 README; alt text lives in each SVG's `<title>` / `<desc>`.

## Checks (author)

Renders: png/ (1440 / 390 × light / dark, DPR 2), receipt png/render-receipt.json. Text-in-viewBox check: png/text-check.json (0 outside for all five). Wide plates scroll at 390 inside the site's figure-scroll region; F5 compact is the 390 view. Not run: real site build, forced-colors emulation, greyscale, VoiceOver, 200 %.
