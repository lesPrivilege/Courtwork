# verification · 作者检查记录

作者：Claude（Fable 5.1）· 2026-09-11。全部为作者检查，不构成独立验收。对象：`reader/dist/index.html` 与 `index-en.html`（隔离副本构建，与带日期文件字节相同）。浏览器：本机 headless Google Chrome（CDP），独立临时 profile。

## 已跑

| 检查 | 命令 / 脚本 | 结果 | 证据 |
|---|---|---|---|
| SE 构建与校验 | `python3 papers/build_en.py && python3 papers/build.py && python3 papers/validate.py` | PASS：3 中文源、14 项 reader 检查、English=reviewed、历史 9.6 字节不变、中英当前入口与带日期文件相同 | `../reader/README.md` |
| 译文结构守恒与发布门反例 | `python3 papers/check_translation_alignment.py --self-test`；`python3 papers/qa/test_translation_gate.py` | 5/5、8 tests OK | 本文 |
| 构建可复现 | 连续两次构建比较 sha256 | 中英均相同 | 本文 |
| SE 自带 reader QA | `node papers/qa/verify_reader.mjs --origin http://127.0.0.1:8977/`（SE 仓 2817b824 原脚本，未改） | **72 PASS / 0 FAIL**：zh/en × desktop/mobile/dark/zoom200 单卷可见与无横向溢出；全部文本对比度 ≥ 4.5:1（大字 3:1）；三卷 `?mode=`；目录跳转落点 128px；语言切换保留卷与章节 hash；390/720 三卷无溢出与对比度；系统深色下切换与切语言保留主题；畸形 hash 回落；无脚本三卷可见；无外部请求；Tab 首焦点为带焦点环的链接；打印三卷可见 | `qa/results.json`、`qa/log.txt`、`qa/*.png` |
| 溢出测量 | `tools/measure.mjs`（zh 390/1440，en 390/1280） | 文本溢出 0、SVG 文字越界 0、被裁容器 0；修复前 Index 390 因脚注长 URL 纯文本溢出到 439px，已改 `overflow-wrap` 后三视图 390 均为 390 | `measure-receipt.json`；`tools/probe.mjs` 复测 |
| 截图矩阵 | `tools/shot.mjs verification/screens-list.json` | 44 张：zh/en Canonical 顶部 1440/1280/390 × light/dark；表格、代码块、Practice、Index 脚注、英文长标题各 1440/1280/390；引用、列表、200%（720 视口 × DPR2 等价）、无脚本 1440/390、打印、封面整页明暗、页脚 | `screens/*.png`、`screens-receipt.json` |
| 插画 | grep `<text`；渲染 12 张 | 图内无文字元素；宽/紧凑 × 明暗全部渲染 | `../editorial/` |
| 两宗署名 | 同一构建切换 `SIGNATURE_FAMILY` | 黑/彩 × 明暗 × 1440/390 六张 masthead 实例 | `../identity/` |
| 长文项 | 截图目视 | 中英长标题（zh「从通用能力到…」、en「A method of weak compilation…」）、段落、引用块（P 系列原则）、列表、代码块（`text` 管线）、最宽 5 列表格（§8.5）、脚注 | `screens/` |

## 未跑（如实标注）

- 真实 SE `main` 推送与 GitHub Pages workflow：未跑；候选未部署。
- 外部链接可达性检查：未跑（validate 只校验页内 fragment 链接）。
- 原生 VoiceOver / 屏幕阅读器、IME、真实浏览器缩放（以 720 视口 × DPR2 等价替代）、forced-colors、灰度、`prefers-contrast`：未跑。
- 非作者视觉验收：未做。
- Practice/Index 视图的封面（仅 Canonical 挂载）与 en 紧凑封面单独截图：未单列（en 390 顶部截图已含）。
- 打印只做 `media: print` 仿真截图，未生成 PDF。
