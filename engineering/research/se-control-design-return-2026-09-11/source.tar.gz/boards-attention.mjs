import { page, icon, iconBtn, sidebar } from './shared.mjs';

const views = (cur = 'all') => `<div class="attention-views" role="group" aria-label="Attention views">${[['all','All'],['investigating','Investigating'],['needs_you','Needs you'],['waiting','Waiting'],['later','Later'],['resolved','Resolved']].map(([v,l]) => `<button type="button" class="attention-view-choice${cur===v?' is-current':''}" aria-pressed="${cur===v}">${l}</button>`).join('')}</div>`;

const regRow = ({ title, status, label, time, selected = false, review = false, focus = false }) => `
  <div role="listitem"><button type="button" class="attention-registry-row${focus ? ' is-focus' : ''}" aria-pressed="${selected}"><span class="attention-row-title">${title}</span><span class="attention-row-meta"><span class="home-attention-state${review ? ' is-review' : ''}">${label}</span><time class="attention-row-time">Updated ${time}</time></span></button></div>`;

const detail = ({ status = 'Investigating', review = false, title, summary, reason, next, due = null, editor = null, notice = null, revision = 1, grant = null, actions = ['Mark as seen','Resume','Set waiting','Snooze','Resolve'], current = null, pending = false }) => `
  <section class="attention-reading" aria-label="Attention details">
    <button type="button" class="text-button">Back to items</button>
    <div class="attention-detail-head" style="margin-top:8px"><span class="attention-detail-state${review ? ' is-review' : ''}">${status}</span><h2>${title}</h2><p>${summary}</p></div>
    <div class="attention-decision"><h3>Why this needs attention</h3><p>${reason}</p><h3>Next step</h3><p>${next}</p>${due ? `<p class="form-help">Recorded due time: ${due}</p>` : ''}</div>
    <details class="attention-basis" open><summary><span class="disc open">Recorded context</span></summary>
      <div style="font-size:12px;line-height:1.7;color:var(--muted-strong);margin-top:6px">Revision ${revision} · Updated 2026-09-11 04:12<br>This view reads the recorded item. Opening it does not acknowledge or resolve it.<br>Retained source · core://matter/m-1/source/s-1@2<br>${grant ?? 'Runtime disclosure: None'}<br>Recorded basis: revision ${revision} · Event ev-3f1c. External availability is unconfirmed; execution references describe historical observations.</div></details>
    <section class="attention-actions" aria-label="Attention actions"><h3>Actions</h3>
      <div class="attention-action-choices">${actions.map(a => `<button type="button" class="text-button attention-action-choice${current===a?' is-current':''}" ${current===a?'aria-expanded="true"':''}>${a}</button>`).join('')}</div>
      ${editor ?? ''}${notice ?? ''}
    </section>
    <button type="button" class="text-button" style="margin-top:12px">Open Attention</button>
  </section>`;

const waitingEditor = ({ error = null, sending = false }) => `
  <div class="attention-action-editor" data-attention-editor="set_waiting">
    <label class="attention-field"><span class="attention-field-label">Reason</span><textarea rows="3" ${error==='reason'?'aria-invalid="true" style="border-color:var(--danger)"':''}>${error==='reason'?'':'Counsel is re-checking the purpose clause against the refreshed source.'}</textarea>${error==='reason'?'<p class="inline-error" role="alert">A reason is required.</p>':''}</label>
    <fieldset class="attention-next-action"><legend>Next action</legend>
      <label class="attention-field"><span class="attention-field-label">Kind</span><select><option>Wait</option></select></label>
      <label class="attention-field"><span class="attention-field-label">Label</span><input type="text" value="Hear back from counsel"></label>
      <label class="attention-field"><span class="attention-field-label">Trigger</span><select><option>At a recorded time</option></select></label>
      <label class="attention-field"><span class="attention-field-label">Due time</span><input type="text" value="2026-09-12 09:00"><span class="form-help">Recorded on the item. Nothing is delivered at this time.</span></label>
    </fieldset>
    <button type="button" class="primary-button" aria-label="Set waiting · Review Project Cedar source change" ${sending?'aria-disabled="true"':''} style="align-self:flex-start">${sending?'Sending…':'Set waiting'}</button>
  </div>`;

export function buildAttention(out) {
  const workspace = (inner) => `<div class="main" style="background:var(--frame)"><div class="chat-header" style="border-bottom:1px solid var(--line);background:var(--frame)"><div class="chat-header-inner"><div class="chat-title-wrap"></div></div></div><div class="attention-workspace"><div class="attention-workspace-inner">${inner}</div></div></div>`;

  const heading = `<div class="attention-workspace-heading"><div><p class="attention-eyebrow">YOUR WORKSPACE</p><h1 style="display:flex;align-items:center;gap:10px">${icon('attn-a',24)}Attention items</h1><p class="form-help">Keep the next human decision in view.</p></div><button type="button" class="text-button">Back to workspace</button></div>
    <div class="attention-toolbar"><select style="width:auto;min-width:200px"><option>Project Cedar review</option></select><button type="button" class="text-button">Refresh</button></div>`;

  // ── AttentionQueue (light) ───────────────────────────────────────────────────
  page({
    file: `${out}/AttentionQueue.dc.html`, title: 'Attention items · editor open · light 1440', width: 1440, height: 980,
    body: `<div class="app-shell" style="height:980px">${sidebar({ current: 'attention', sparkGlyph: 'spark-a', attnGlyph: 'attn-a' })}${workspace(`${heading}${views('all')}
      <div class="attention-columns">
        <section class="attention-registry" aria-label="Attention items"><p class="attention-count">3 items · all states</p><div role="list">
          ${regRow({ title: 'Review Project Cedar source change', label: 'Investigating', time: '19m ago', selected: true })}
          ${regRow({ title: 'Approve the redlined termination clause', label: 'Needs you', time: '2h ago', review: true })}
          ${regRow({ title: 'Northside ledger: confirm opening balance', label: 'Waiting', time: '3d ago' })}
        </div></section>
        ${detail({ title: 'Review Project Cedar source change', summary: 'A human should inspect the refreshed source before deciding.', reason: 'The source-backed review needs human inspection after a source refresh.', next: 'Inspect refreshed sources', current: 'Set waiting', editor: waitingEditor({}) })}
      </div>`)}</div>`,
  });

  // ── AttentionAssistant (dark) ────────────────────────────────────────────────
  const homeDim = `<div class="main"><div class="chat-header" style="border-bottom:0"><div class="chat-header-inner"></div></div><div style="max-width:var(--home-column);margin:24px auto;width:100%;color:var(--muted-strong)"><div class="home-card home-attention" style="width:420px"><span class="home-card-title">${icon('attn-a',16)}Attention items</span><div class="form-help" style="margin-top:6px">0 items · all states</div><p class="form-help" style="margin:22px 0">No attention items recorded in this project.</p></div><h2 style="font-size:28px;letter-spacing:-.02em;margin:48px 0 16px;font-weight:600;color:var(--ink)">Work that exists beyond the model.</h2><div class="composer-form" style="max-width:820px;margin:0"><div class="composer-input">Describe the work you want to do…</div><div class="composer-controls"><span class="composer-model">Local test</span>${iconBtn('arrow-up','Send','primary-button icon-only pill',18)}</div></div></div></div>`;
  page({
    file: `${out}/AttentionAssistant.dc.html`, title: 'Attention · global assistant · dark 1440', width: 1440, height: 900, dark: true,
    body: `<div class="app-shell" style="height:900px">${sidebar({ current: 'home', sparkGlyph: 'spark-a', attnGlyph: 'attn-a' })}${homeDim}<div class="dialog-scrim"></div>
      <div class="attention-agent-dialog" role="dialog" aria-labelledby="attention-agent-title">
        <header class="attention-agent-header"><div><h2 id="attention-agent-title">${icon('attn-a',20)}Attention</h2><p class="form-help">Your global assistant</p></div>${iconBtn('x','Close Attention','quiet-button icon-only',18)}</header>
        <div class="attention-agent-toolbar"><select><option>Attention · 9/11/2026, 12:04</option></select>${iconBtn('refresh-cw','Refresh Attention')}<button type="button" class="text-button">Conversations</button><button type="button" class="text-button">Attention items</button><button type="button" class="text-button">Open conversation</button>${iconBtn('settings-2','Configure Attention Runtime')}</div>
        <div class="attention-agent-stream">
          <details><summary><span class="disc">Threads &amp; messages</span></summary></details>
          <div class="message user" style="margin:0"><div class="user-message-content">Help me inspect the review item for Project Cedar.<span class="src">▸ Source</span></div></div>
          <div><span class="disc">Tool activity</span>
            <div class="question-card" style="margin-top:8px"><b style="font-size:15px">Question</b><span style="font-size:15px">Proceed with the disclosed Project Cedar review item?</span><span class="form-help">Request resolved · answered at revision 1</span></div></div>
          <div><span class="disc open">Tool activity</span>
            <div style="display:flex;flex-direction:column;gap:2px;margin-top:6px;font-size:15px"><span class="disc">attention_projects</span><span class="disc">attention_list</span><span class="disc">attention_inspect</span></div></div>
          <div class="inline-notice" style="font-size:12px"><b>Disclosure requested</b> · fields <span class="k">reason, source_refs</span> on item at-7 · scope: this conversation · until 2026-09-11 06:00<div style="display:flex;gap:8px;margin-top:8px"><button type="button" class="primary-button">Allow this disclosure</button><button type="button" class="secondary-button">Deny</button></div><p class="form-help" style="margin-top:6px">Granting records a Runtime grant at revision 2. It does not acknowledge or resolve the item.</p></div>
          <div><p class="message-role" style="margin:0 0 6px">Attention</p><p class="message-body">I inspected the disclosed Project Cedar review item and its source-backed context. It remains pending human Review.</p><span class="disc" style="margin-top:6px">Runtime &amp; memory</span></div>
        </div>
        <div class="attention-agent-composer"><span class="ph">What needs your attention?</span><span class="composer-model">Local test</span>${iconBtn('arrow-up','Send to Attention','primary-button icon-only pill',18)}</div>
      </div></div>`,
  });

  // ── AttentionStates matrix ───────────────────────────────────────────────────
  const cell = (title, tagHtml, inner, note) => `<div class="cell" style="padding:0;overflow:hidden"><div style="padding:10px 14px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:center"><h3 style="margin:0">${title}</h3>${tagHtml}</div><div style="padding:14px;min-height:130px;background:var(--panel)">${inner}</div><div class="why" style="padding:10px 14px;border-top:1px solid var(--line);margin:0">${note}</div></div>`;
  const list = (rows) => `<div role="list">${rows}</div>`;
  page({
    file: `${out}/AttentionStates.dc.html`, title: 'Attention · state matrix', width: 1440, height: 1320,
    body: `<div class="board">
      <div class="eyebrow">DG-03 · queue · detail · disclosure · typed actions · receipts (attention-view.mjs WK-156…158, attention-agent-view.mjs) · five contract states, six views · a view is a filter, not a tab</div>
      <h1 class="board-title" style="margin-top:8px">Every request binds an object at a revision, and every outcome is a sentence.</h1>
      <div class="board-grid" style="grid-template-columns:1fr 1fr 1fr">
        ${cell('Active vs selected', '<span class="tag live">live</span>', list(regRow({ title: 'Approve the redlined termination clause', label: 'Needs you', time: '2h ago', review: true }) + regRow({ title: 'Review Project Cedar source change', label: 'Investigating', time: '19m ago', selected: true }) + regRow({ title: 'Northside ledger: confirm opening balance', label: 'Waiting', time: '3d ago', focus: true })), 'Row 1: state word only (Needs you, 600 weight, review colour). Row 2: selected = L2 float. Row 3: keyboard cursor = 2px focus ring. Three facts, three channels; none is colour alone.')}
        ${cell('Empty view', '<span class="tag live">live</span>', `${views('needs_you')}<p class="attention-count">0 items · Needs you</p><div style="padding:8px 0"><h3 style="font-size:15px;font-weight:600">Nothing in this view</h3><p class="form-help">Recorded attention items matching this project and state will appear here.</p></div>`, 'Per-view empty state; the count line stays. No illustration, no call to action — an empty Needs you is a good state.')}
        ${cell('Loading / error / no project', '<span class="tag live">live</span>', `<p class="form-help" role="status">Loading items…</p><p class="form-help" role="status" style="margin-top:10px">Attention items could not be read. <button type="button" class="text-button">Retry</button></p><p class="form-help" style="margin-top:10px">Create a project to begin.</p>`, 'Three sentences in the registry column; the detail column keeps its own status. The project selector is never disabled by a list error.')}
        ${cell('Permission · not granted', '<span class="tag live">live</span>', `<div class="inline-notice"><b>Disclosure requested</b> · fields <span class="k">reason, source_refs</span> · scope: this conversation<div style="display:flex;gap:8px;margin-top:8px"><button type="button" class="primary-button">Allow this disclosure</button><button type="button" class="secondary-button">Deny</button></div></div>`, 'Scope, fields and duration are visible at the decision point, never in a tooltip (IC-3). Allow = one exact grant, not "always allow".')}
        ${cell('Permission · granted (revision 2)', '<span class="tag live">live</span>', `<div style="font-size:12px;line-height:1.7;color:var(--muted-strong)">Runtime disclosure until 2026-09-11 06:00 · recorded fields: reason, source_refs<br>Recorded basis: revision 2 · Event ev-41aa</div><p class="form-help" style="margin-top:8px">Readable here, editable nowhere (WK-158 §25). No Revoke, no Active badge, no countdown.</p>`, 'The grant is a recorded fact on the item. Its expiry is a time, shown as a time.')}
        ${cell('Permission · revoked / expired', '<span class="tag live">live</span>', `<div style="font-size:12px;line-height:1.7;color:var(--muted-strong)">Runtime disclosure: None<br>Previous grant expired 2026-09-11 06:00 · revision 2</div><p class="inline-error" style="margin-top:8px" role="alert">You do not have access to this field.</p>`, 'DISCLOSURE_DENIED is a sentence on the field it refuses; the rest of the item still renders.')}
        ${cell('Request in flight', '<span class="tag live">live</span>', waitingEditor({ sending: true }), 'Only the submit says Sending… (M-9 width lock: no neighbour moves). Row and detail keep the last confirmed status — nothing is optimistic.')}
        ${cell('Receipt → re-inspect', '<span class="tag live">live</span>', `<div style="font-size:12px;line-height:1.7"><span class="home-attention-state">Waiting</span> · Revision 3 · Updated just now<br><span class="form-help">Receipt read for request 3c9e… · re-inspected · editor closed</span></div>`, 'A receipt describes what committed, not the newest state; the object is read again before anything is rendered from it.')}
        ${cell('Old revision conflict', '<span class="tag live">live</span>', `${waitingEditor({})}<p class="inline-notice" style="margin-top:10px;color:var(--danger)" role="alert">This item changed while you were deciding. Reload it and try again.</p>`, 'VERSION_CONFLICT keeps the draft words; the next submit is a new decision with a new identity and expected revision. Never a silent replay.')}
        ${cell('Uncertain transport', '<span class="tag live">live</span>', `<div class="inline-notice" role="alert"><p>The result of your request is not known. It was not marked failed.</p><button type="button" class="text-button" style="margin-top:8px">Retry sending</button></div>`, 'Same stored request, same identity: a retry can never become a second recorded action.')}
        ${cell('Field validation', '<span class="tag live">live</span>', waitingEditor({ error: 'reason' }), 'Inline error under the field, danger text + border; focus moves to the field. The server may still refuse.')}
        ${cell('Question (assistant)', '<span class="tag live">live</span>', `<div class="question-card"><b style="font-size:15px">Question</b><span style="font-size:15px">Proceed with the disclosed Project Cedar review item?</span><div style="display:flex;gap:8px"><input type="text" placeholder="Your answer" style="flex:1"><button type="button" class="primary-button">Answer</button></div></div>`, 'Answer is a natural-language reply, not authorization (composition standard). Resolved questions keep the card and lose the form.')}
      </div>
      <div class="board-grid" style="grid-template-columns:1fr 1fr">
        <div class="cell"><h3>Keyboard · J/K · Escape · return</h3><p class="why">J/K and ↑/↓ move the cursor and clamp at both ends (no wrap). Enter opens. Escape closes the editor first, then the detail. Returning from a detail lands on the row it opened from; if a status change moved the row out of the view, on the nearest surviving row; only then on the view control — never on the project selector (WK-158 §11).</p></div>
        <div class="cell"><h3>What Attention is not</h3><p class="why">Not an inbox, not a second registry, not a scheduler: a recorded due time is a time, not a timer. Spark never creates an Attention item (SP-11). The global assistant is a conversation with its own identity (scope global); items are the queue. Entry points: sidebar row → workspace; Home card row → workspace with that item selected; assistant toolbar → workspace; workspace → assistant (Open Attention).</p></div>
      </div>
    </div>`,
  });

  // ── AttentionNarrow 390 ──────────────────────────────────────────────────────
  page({
    file: `${out}/AttentionNarrow.dc.html`, title: 'Attention · 390 narrow · detail', width: 390, height: 844,
    body: `<div style="height:844px;background:var(--frame);overflow:hidden">
      <div class="chat-header" style="padding:0 12px"><div class="chat-header-inner"><div class="chat-title-wrap">${iconBtn('panel-left','Open navigation')}<h1 style="display:flex;align-items:center;gap:6px">${icon('attn-a',16)}Attention items</h1></div></div></div>
      <div style="padding:12px 16px 16px"><div class="attention-views" style="overflow:hidden">${[['All',false],['Investigating',true],['Needs you',false],['Waiting',false]].map(([l,c])=>`<button type="button" class="attention-view-choice${c?' is-current':''}" style="min-height:44px">${l}</button>`).join('')}</div>
        <section class="attention-reading" style="border:0;padding:0;background:transparent;min-height:0"><button type="button" class="text-button" style="min-height:44px;padding-left:0">‹ Back to items</button>
          <div class="attention-detail-head"><span class="attention-detail-state">Investigating</span><h2 style="font-size:22px">Review Project Cedar source change</h2><p>A human should inspect the refreshed source before deciding.</p></div>
          <div class="attention-decision" style="padding:12px 0"><h3>Why this needs attention</h3><p>The source-backed review needs human inspection after a source refresh.</p><h3>Next step</h3><p>Inspect refreshed sources</p></div>
          <details class="attention-basis"><summary><span class="disc" style="min-height:44px">Recorded context</span></summary></details>
          <section class="attention-actions" style="margin-top:16px"><h3>Actions</h3><div class="attention-action-choices">${['Mark as seen','Resume','Set waiting','Snooze','Resolve'].map(a=>`<button type="button" class="text-button attention-action-choice" style="min-height:44px">${a}</button>`).join('')}</div></section>
        </section></div>
      <p class="form-help" style="padding:0 16px">Below 1024 the two columns become one; the list and the detail are two screens with Back. Every control is ≥ 44px. Long titles wrap (overflow-wrap: anywhere), never ellipsize.</p>
    </div>`,
  });
}
