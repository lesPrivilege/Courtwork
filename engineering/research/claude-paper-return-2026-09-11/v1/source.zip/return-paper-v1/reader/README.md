# reader · 可运行出版阅读面候选（阶段 3）

候选在固定 SE 源 `2817b8240c34d0754caf623e2a867cc168a260ab` 的隔离副本上制作（本地 clone，分支 `claude/paper-v1-candidate`，不触共享 checkout）。论文正文与译文只读，不编辑。

## 构建输入（可应用补丁）

`patch/0001-*.patch` 由 `git format-patch 2817b824..HEAD` 导出，只改 reader 层：

| 文件 | 变化 |
|---|---|
| `papers/reader/reader.css` | 重写：Dystopia 角色映射、出版层级、rail/breakout、封面角色、打印/无脚本/窄屏 |
| `papers/reader/reader.js` | 新增：≥1100px 展开目录 rail，窄屏折叠；其余行为不变 |
| `papers/reader/signature.svg` | 新增：les Privilege 标记（几何来自 brand `mark.svg`，填色改 class 钩子） |
| `papers/reader/cover.svg` `cover-compact.svg` | 新增：推荐插画 E1 宽/紧凑版（角色类名，颜色由 reader.css 定义） |
| `papers/build.py` | 新增 `READER_CANDIDATE`/`SIGNATURE_FAMILY`；masthead 署名、元数据 eyebrow、封面挂载（Canonical 卷标题/副题之后）、`paper-body` 包裹、页脚；输出文件名加 `-paper-v1`；`reader-candidate` meta；中英 label 与 alt |
| `papers/validate.py` | 调色板检查改为新 canvas/ink 值；新增 reader-candidate 元数据与署名检查 |

应用方式（在 SE 仓 2817b824 的隔离工作区）：

```bash
git am reader/patch/0001-*.patch
python3 -m pip install -r papers/requirements.txt
python3 papers/build_en.py && python3 papers/build.py && python3 papers/validate.py
```

`src/` 是同一组文件的直接副本，供不走 git 的核对。

## 生成输出

`dist/` 为隔离副本中实际构建产物：`schema-engineering-2026-09-07-reader-2026-09-11-paper-v1.html`（中文）与 `-en.html`（英文）；`index.html`/`index-en.html` 与之字节相同。它们是候选生成物，不是发布；SE 仓已跟踪的 2026-09-11 与历史文件未被改写（validate 已核历史 9.6 字节不变）。

预览：直接打开 `dist/index.html`（无外部依赖），或

```bash
python3 -m http.server 8977 --directory reader/dist
```

## 阅读功能变化清单

| 功能 | 状态 |
|---|---|
| Canonical / Practice / Index 三卷、`?mode=`、`#paper-*` 与旧别名 hash | 保留（reader.js 未改此段） |
| 中文 / English 切换保留卷与最近章节 | 保留；QA `*-language-anchor` 通过 |
| 主题按钮、系统偏好、localStorage、`aria-pressed` | 保留 |
| back/forward、刷新、可分享链接 | 保留 |
| 键盘：skip link、tab 顺序、焦点环 | 保留；控件改为文字 tab 仍有 44px 高度与 `--focus` 环 |
| 无脚本 | 三卷顺序全显，目录为折叠 details，封面仍显示 |
| 打印 | 隐藏控件与目录，masthead 保留作品与署名，封面转灰阶，表格/代码展开 |
| 目录 | 标记不变；宽屏 sticky rail，窄屏折叠 |
| 翻译缺失章节 | 按现合同：英文由 reviewed manifest 门控，无对应译文时不出现 English 入口；本轮译文完整，未伪造 |
| 新增 motion | 无；目录折叠箭头 120ms 旋转，`prefers-reduced-motion` 下取消 |

## 不在范围

未复制可编辑正文到 CourtWork；未接入 CourtWork Pages；未推送 SE main；候选 Pages 入口仍需 SE release/workflow 回执。
