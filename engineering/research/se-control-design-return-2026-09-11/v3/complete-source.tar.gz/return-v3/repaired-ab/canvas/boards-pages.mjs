import { page, icon } from './shared.mjs';

const campaign = `
.pg{--campaign-paper:#f4f5f6;--campaign-raised:#ffffff;--campaign-ink:#282b2d;--campaign-soft:#e1e5e8;--campaign-rule:#a7aeb2;--campaign-serif:Georgia,'Times New Roman',serif;background:var(--campaign-paper);color:var(--campaign-ink);padding:64px 80px;font-size:15px;line-height:1.75}
.pg .index{font-family:var(--font-mono);font-size:12px;letter-spacing:.12em;margin:0 0 22px;color:#54616a}
.pg h2{font:400 clamp(38px,4.8vw,66px)/1.03 var(--campaign-serif);letter-spacing:-.055em;margin:0 0 20px}
.pg .thesis{font-size:18px;line-height:1.75;margin:0}
.product-atoms{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:64px;margin:0}
.product-atom{border-top:1px solid var(--campaign-rule);padding-top:24px}
.atom-diagram{margin:26px 0 0}.atom-diagram svg{display:block;width:100%;height:auto;overflow:visible;color:var(--campaign-ink)}
.atom-wire,.attention-boundary{fill:none;stroke:var(--campaign-rule);stroke-width:1}
.source-base,.derived-view rect{fill:var(--campaign-raised);stroke:var(--campaign-rule);stroke-width:1}
.source-mark,.derived-view path{fill:none;stroke:currentColor;stroke-width:2}.source-mark{stroke-width:3}
.source-change{fill:var(--campaign-ink)}
.atom-axis{display:flex;justify-content:space-between;margin:0 0 18px;padding:0 7%;font:12px/1.5 var(--font-mono);color:#54616a}
.signal-stream{fill:var(--campaign-rule);stroke:var(--campaign-rule);stroke-width:1}
.attention-boundary{stroke-dasharray:3 6}
.attention-path{fill:none;stroke:var(--campaign-ink);stroke-width:2}
.attention-target{fill:var(--campaign-paper);stroke:var(--campaign-rule);stroke-width:1}
.attention-target-mark{fill:none;stroke:var(--campaign-ink);stroke-width:2;stroke-linecap:round}
.atom-bottom{display:flex;align-items:center;justify-content:space-between;gap:16px;min-height:64px;border-top:1px solid #d9d9e0}
.atom-state{margin:0;font-size:14px}
.atom-control{font:500 14px/1.5 system-ui,sans-serif;color:var(--campaign-ink);background:none;border:0;padding:10px 0}
.story{margin-top:88px;border-top:1px solid var(--campaign-rule);padding-top:24px}
.story h2{font-size:clamp(32px,4vw,56px);letter-spacing:-.035em;line-height:1.2}
.beats{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:20px;margin-top:36px}
.beat{border-top:1px solid var(--campaign-rule);padding-top:14px}
.beat .n{font-family:var(--font-mono);font-size:12px;letter-spacing:.1em;color:#54616a}
.beat h3{font:400 22px/1.2 var(--campaign-serif);letter-spacing:-.02em;margin:8px 0 8px}
.beat p{font-size:14px;line-height:1.7;margin:0}
.beat .fig{margin-top:14px;background:var(--campaign-soft);border:1px solid var(--campaign-rule);padding:14px;min-height:150px;display:flex;align-items:center;justify-content:center}
.beat .fig svg{width:100%;height:auto;color:var(--campaign-ink)}
`;

const sparkDiagram = (changed) => `<svg viewBox="0 0 520 190" focusable="false">
  <path class="atom-wire" d="M88 94H185M185 94V42H286M185 94H286M185 94V146H286"/>
  <rect class="source-base" x="46" y="55" width="78" height="78" rx="4"/>
  <path class="source-mark" d="M67 78H103M67 94H97M67 110H87"/>
  <g class="derived-view" transform="translate(${changed?10:0},0)"><rect x="286" y="22" width="182" height="40" rx="4"/><path d="M308 42H409"/></g>
  <g class="derived-view" transform="translate(${changed?-8:0},0)"><rect x="286" y="74" width="152" height="40" rx="4"/><path d="M308 94H386"/></g>
  <g class="derived-view" transform="translate(${changed?6:0},0)"><rect x="286" y="126" width="170" height="40" rx="4"/><path d="M308 146H404"/></g>
  <circle class="source-change" cx="124" cy="55" r="7" style="opacity:${changed?1:0}"/>
  ${changed ? '<text x="300" y="52" font-family="ui-monospace,Menlo,monospace" font-size="11" fill="#54616a">rev 2 · behind</text><text x="300" y="104" font-family="ui-monospace,Menlo,monospace" font-size="11" fill="#54616a">rev 1 · behind</text><text x="300" y="156" font-family="ui-monospace,Menlo,monospace" font-size="11" fill="#54616a">rev 3 · current</text>' : ''}
</svg>`;
const attnDiagram = (changed) => `<svg viewBox="0 0 520 190" focusable="false">
  <g class="signal-stream" style="opacity:${changed?.5:1}"><path d="M44 35H204M74 65H228M30 94H264M92 123H204M55 153H230"/><circle cx="84" cy="35" r="3"/><circle cx="125" cy="65" r="3"/><circle cx="67" cy="94" r="3"/><circle cx="157" cy="123" r="3"/><circle cx="101" cy="153" r="3"/></g>
  <path class="attention-boundary" d="M292 22V168"/>
  <path class="attention-path" d="M102 94H442" style="opacity:${changed?1:0}"/>
  <circle class="attention-target" cx="414" cy="94" r="23" style="${changed?'stroke:#282b2d':''}"/>
  <path class="attention-target-mark" d="M414 83V96M414 104V105" style="opacity:${changed?1:0}"/>
</svg>`;

export function buildPages(out) {
  const beat = (n, h, p, fig) => `<div class="beat"><div class="n">${n}</div><h3>${h}</h3><p>${p}</p><div class="fig">${fig}</div></div>`;
  const miniSpark = `<svg viewBox="0 0 220 90"><rect x="10" y="25" width="40" height="40" rx="3" fill="#fff" stroke="#a7aeb2"/><path d="M20 38h20M20 46h16M20 54h10" stroke="currentColor" stroke-width="2.5" fill="none"/><path d="M50 45h30M80 45V22h50M80 45h50M80 45v23h50" stroke="#a7aeb2" fill="none"/><rect x="130" y="12" width="70" height="20" rx="3" fill="#fff" stroke="#a7aeb2"/><rect x="130" y="35" width="60" height="20" rx="3" fill="#fff" stroke="#a7aeb2"/><rect x="130" y="58" width="66" height="20" rx="3" fill="#fff" stroke="#a7aeb2"/><circle cx="50" cy="25" r="5" fill="#282b2d"/></svg>`;
  const miniStale = `<svg viewBox="0 0 220 90"><rect x="130" y="12" width="70" height="20" rx="3" fill="#fff" stroke="#282b2d" stroke-dasharray="3 3"/><rect x="130" y="35" width="60" height="20" rx="3" fill="#fff" stroke="#282b2d" stroke-dasharray="3 3"/><rect x="130" y="58" width="66" height="20" rx="3" fill="#fff" stroke="#a7aeb2"/><text x="24" y="30" font-family="ui-monospace,Menlo,monospace" font-size="10" fill="#54616a">2 stale of 3</text><text x="24" y="48" font-family="ui-monospace,Menlo,monospace" font-size="10" fill="#54616a">rev 2 → 3</text><path d="M96 45h30" stroke="#a7aeb2"/></svg>`;
  const miniLocate = `<svg viewBox="0 0 220 90"><path d="M20 20h60M20 45h60M20 70h60" stroke="#a7aeb2"/><rect x="100" y="34" width="100" height="22" rx="3" fill="#fff" stroke="#282b2d"/><text x="110" y="49" font-family="ui-monospace,Menlo,monospace" font-size="10" fill="#282b2d">Acme inbound NDA</text><path d="M80 45h20" stroke="#282b2d" stroke-width="2"/></svg>`;
  const miniHuman = `<svg viewBox="0 0 220 90"><path d="M20 30h90M20 45h110M20 60h90" stroke="#a7aeb2" opacity=".5"/><path d="M130 45h50" stroke="#282b2d" stroke-width="2"/><circle cx="192" cy="45" r="16" fill="#f4f5f6" stroke="#282b2d"/><path d="M192 37v9M192 51v1" stroke="#282b2d" stroke-width="2" stroke-linecap="round"/><text x="20" y="80" font-family="ui-monospace,Menlo,monospace" font-size="10" fill="#54616a">reason · revision · receipt</text></svg>`;
  const miniContinue = `<svg viewBox="0 0 220 90"><rect x="10" y="25" width="40" height="40" rx="3" fill="#fff" stroke="#a7aeb2"/><path d="M50 45h30M80 45V22h50M80 45h50M80 45v23h50" stroke="#a7aeb2" fill="none"/><circle cx="50" cy="25" r="5" fill="#282b2d"/><rect x="130" y="12" width="70" height="20" rx="3" fill="#fff" stroke="#a7aeb2" stroke-dasharray="3 3"/><rect x="130" y="35" width="60" height="20" rx="3" fill="#fff" stroke="#a7aeb2" stroke-dasharray="3 3"/><rect x="130" y="58" width="66" height="20" rx="3" fill="#fff" stroke="#282b2d"/><text x="10" y="89" font-family="ui-monospace,Menlo,monospace" font-size="9" fill="#54616a">c-11 → v8 · c-9, c-10 kept</text></svg>`;

  page({
    file: `${out}/PagesStory.dc.html`, title: 'Pages · Spark & Attention story', width: 1440, height: 1900, extraCss: campaign,
    body: `<div class="pg">
      <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:40px"><span class="index" style="margin:0">DG-08 · HOME · AFTER THE HERO · MEDIA STAYS f137 · READING PATH HERO → SPARK/ATTENTION → PAPER/TOUR UNCHANGED</span><span class="index" style="margin:0">DRAWN SPECIMEN · NOT A CAPTURE</span></div>
      <section class="product-atoms" aria-label="Spark and Attention">
        <article class="product-atom"><p class="index">SPARK</p><h2>Knowledge,<br><em>rebuilt.</em></h2><p class="thesis">来源更新，发现随之重建。<br>知识保持新鲜，决定保留来路。</p>
          <div class="atom-diagram">${sparkDiagram(true)}<div class="atom-axis"><span>Sources</span><span>Derived knowledge</span></div></div>
          <div class="atom-bottom"><p class="atom-state">来源 s-1 更新到修订 2；两项派生落后。</p><button type="button" class="atom-control" aria-pressed="true">更新来源 <span>↗</span></button></div></article>
        <article class="product-atom"><p class="index">ATTENTION</p><h2>Attention,<br><em>well spent.</em></h2><p class="thesis">让工作持续推进。<br>把你的注意力留给重要变化。</p>
          <div class="atom-diagram">${attnDiagram(true)}<div class="atom-axis"><span>Work in motion</span><span>Human judgment</span></div></div>
          <div class="atom-bottom"><p class="atom-state">一项需要你：检查刷新后的来源。</p><a class="atom-control" href="#">Explore the ideas <span>↗</span></a></div></article>
      </section>
      <section class="story"><p class="index">HOW SE GOVERNS CONTINUING WORK</p><h2>One change of source, five things you can check.</h2>
        <p class="thesis" style="max-width:68ch">来源变了，工作不必从头开始。CourtWork 记录变化、识别过期、定位相关工作，把判断留给人，再让工作继续。</p>
        <div class="beats">
          ${beat('01 · SOURCE CHANGES', 'A source moves.', '一份来源更新了版本。变化被记录下来，不是一条警报。', miniSpark)}
          ${beat('02 · SPARK SEES WHAT IS BEHIND', 'Derivations fall behind.', 'Spark 读出哪些派生来自旧版本，用文字和数字说明，不催促。', miniStale)}
          ${beat('03 · FIND THE WORK', 'The Matter is where it was.', '从 Spark 回到同一件工作：它的来源版本、成果与待审候选都还在原处。', miniLocate)}
          ${beat('04 · A PERSON DECIDES', 'With a reason, at a version.', 'Attention 把这次判断留在视野里。决定带着理由与版本被记录，并留下回执。', miniHuman)}
          ${beat('05 · WORK CONTINUES', 'A new version, on the record.', '判断之后，针对当前来源重新形成的派生成为新的版本；旧候选与它的失效记录一并保留。下一次运行从当前有效的材料出发。', miniContinue)}
        </div>
      </section>
    </div><div class="annot" style="padding:16px 80px"><b>Specimen notes — not page copy.</b> Placement ruled: five beats after the two atoms, before the research figures; hero, object figure, Tour/Paper/Release nav, default-open Ideas and media (f137) unchanged. Capability account, kept apart from the story: beat 3's "find the work" is the live Matter → Work path for live rows only (sample rows are inert); beat 5 shows the causal chain the contract allows — a new candidate derived from the current source (revise_candidate, or a new Run with supersedes) is accepted and advances the Matter version, while c-9 / c-10 and their stale basis stay recorded; no automatic rebuild ships on this baseline; beats 1, 2, 4 map to the live Spark read and the live Attention typed-action receipt. Assets: five static SVGs on the campaign palette, currentColor, existing forced-colors rules apply; the atoms' own 420 / 240ms transitions are the only motion, none added. Copy above is bilingual product copy for Astra to rewrite as DR-06 sees fit.</div>`,
  });
}
