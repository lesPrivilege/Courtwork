import { page, icon, iconBtn, sidebar } from './shared.mjs';

const actionBar = (role, { state = {} } = {}) => {
  const btn = (name, label, st) => `<button type="button" class="quiet-button icon-only${st==='hover'?' is-hover':''}${st==='focus'?' is-focus':''}${st==='pressed'?' is-pressed':''}" aria-label="${label}" ${st==='unavailable'?'aria-disabled="true" data-tooltip="'+label+' — unavailable"':''} ${st==='selected'?'aria-pressed="true"':''} ${st==='busy'?'aria-busy="true" style="opacity:.6"':''}>${icon(name,18)}</button>`;
  const items = role === 'user' ? [['copy','Copy message'],['square-pen','Edit message']] : [['copy','Copy response'],['volume-2','Read aloud'],['thumbs-up','Good response'],['thumbs-down','Bad response'],['rotate-ccw','Regenerate'],['ellipsis','More response actions']];
  return `<div class="chat-action-row" role="group">${items.map(([n,l]) => btn(n,l,state[n])).join('')}</div>`;
};

export function buildChat(out) {
  // ── ChatSpace scene (light 1440) ─────────────────────────────────────────────
  page({
    file: `${out}/ChatSpace.dc.html`, title: 'Chat space · waiting · light 1440', width: 1440, height: 964,
    body: `<div class="app-shell" style="height:900px">${sidebar({ current: null, sparkGlyph: 'spark-a', attnGlyph: 'attn-a', chatCurrent: 'refresh' })}
      <div class="main">
        <div class="chat-header"><div class="chat-header-inner"><div class="chat-title-wrap"><h1>Source refresh — Spark derivation</h1><span class="run-badge running"><span class="dot"></span>Running</span></div><div class="chat-header-actions">${iconBtn('text','Chat overview')}${iconBtn('panel-right','Open work surface','quiet-button icon-only',18,'aria-pressed="false"')}</div></div></div>
        <div class="message-stream"><div class="message-list">
          <div class="message user"><div class="user-message-content">Refresh the Project Cedar sources and tell me which derivations are behind.<span class="src">▸ Source</span></div></div>
          <div class="flow-row flow-sep">${icon('activity',16)}<span class="flow-title">1 tool action</span><span class="flow-meta">Completed ${icon('chevron-right',14)}</span></div>
          <div class="flow-row flow-sep">${icon('file-text',16)}<span class="flow-title">out/spark-derivations-cedar.md</span><span class="flow-meta">Recorded version ${icon('chevron-right',14)}${iconBtn('ellipsis','More file actions','quiet-button icon-only',18)}</span></div>
          <p class="message-role">Assistant</p>
          <p class="message-body">Source s-1 moved from revision 1 to 2 and s-2 was added, so the Matter's source set is now revision 3. Two pending candidates (c-9, c-10) derive from earlier revisions; the accepted ones are current.</p>
          <div style="display:flex;flex-direction:column;gap:6px;color:var(--muted-strong)">${actionBar('assistant')}<p class="chat-action-status">Copied.</p></div>
          <div class="flow-row" style="margin-top:4px">${icon('activity',16)}<span class="flow-title">Reading the refreshed source</span><span class="flow-meta"><span class="dot" style="animation:se-pulse 1.6s cubic-bezier(.2,0,0,1) infinite"></span>Working</span></div>
          <div class="question-card" style="margin-top:8px"><b style="font-size:15px">Question</b><span style="font-size:15px">Which stale candidate should I inspect first, c-9 or c-10?</span><div style="display:flex;gap:8px"><input type="text" placeholder="Your answer" style="flex:1"><button type="button" class="primary-button">Answer</button></div></div>
        </div>
        <div style="position:absolute;left:50%;bottom:196px;transform:translateX(-50%);background:var(--glass);backdrop-filter:blur(12px);border:1px solid var(--line);border-radius:999px;padding:5px 12px;font-size:11.5px;box-shadow:var(--rim)">Back to latest</div></div>
        <div class="composer-area"><div class="composer-form"><div class="composer-input">What would you like to work on?</div>
          <div class="composer-run-hint is-waiting"><span class="dot"></span>Waiting for you · answer the question above, or keep typing. Your input will not be sent automatically.</div>
          <div class="composer-controls"><div class="composer-context">${iconBtn('paperclip','Attach','quiet-button icon-only',18)}<span class="composer-model">running-correction-model</span></div><div class="composer-buttons">${iconBtn('square','Stop working','primary-button icon-only pill',18)}</div></div></div>
          <div class="composer-below"><span>Project Cedar review</span><span>Allow edits ${icon('chevron-down',12)}</span></div></div>
      </div></div><div class="annot"><b>Specimen notes (not product copy).</b> Question card and Answer are the live ask-user path (canAnswer); the question is a read-only inspection choice — no rebuild path exists on this baseline. Assistant action bar: hover-revealed as currently shipped (opacity 0 → 1, always visible on touch); only Copy / Edit / Copy path / Copy hash have handlers. Header: three-line overview donor + panel-right with aria-expanded=false. Tokens: effective default-slate cascade.</div>`,
  });

  // ── ChatActions: anatomy + states matrix (DG-06) ─────────────────────────────
  const stateRow = (label, html, note) => `<tr><td>${label}</td><td style="background:var(--panel)">${html}</td><td class="form-help">${note}</td></tr>`;
  page({
    file: `${out}/ChatActions.dc.html`, title: 'Chat space · actions and rows', width: 1440, height: 1380,
    body: `<div class="board">
      <div class="eyebrow">DG-06 · P1 · chat-actions.mjs (15 intents, 4 production: copy, edit, copy-path, copy-hash) · semantic registry 47 keys / 36 glyphs · Chat ≠ Run ≠ Thread</div>
      <h1 class="board-title" style="margin-top:8px">One row anatomy, one action anatomy, every state a word.</h1>
      <div class="board-grid" style="grid-template-columns:1.1fr 1fr">
        <div class="cell"><h3>Row anatomy (WK-57) — glyph 16 · object name · one meta · one action</h3>
          <div style="background:var(--panel);padding:4px 0;margin-top:8px">
            <div class="flow-row flow-sep">${icon('activity',16)}<span class="flow-title">2 tool actions</span><span class="flow-meta">Completed ${icon('chevron-right',14)}</span></div>
            <div class="flow-row flow-sep">${icon('file-text',16)}<span class="flow-title">out/project-cedar-review.md</span><span class="flow-meta">Recorded version ${icon('chevron-right',14)}${iconBtn('ellipsis','More file actions','quiet-button icon-only',18)}</span></div>
            <div class="flow-row flow-sep">${icon('file-text',16)}<span class="flow-title">source-0d8258ae…:1 · 64076b0b8183</span><span class="flow-meta">Read the recorded source ${icon('external-link',14)}</span></div>
            <div class="flow-row flow-sep is-failed">${icon('activity',16)}<span class="flow-title">ws_write · notice.md</span><span class="flow-meta">Failed <button type="button" class="text-button">Retry loading</button></span></div>
            <div class="flow-row">${icon('message-square',16)}<span class="flow-title">Question · answered</span><span class="flow-meta">Resolved</span></div>
          </div>
          <p class="why"><b>File version vs read source</b> share the file-text glyph but never the same meta: "Recorded version" opens the recorded bytes; "Read the recorded source" is a link out (external-link, link semantics). The distinction is carried by the words + trailing glyph, not by inventing a second document icon (IC-1 P1). <b>Retry loading</b> and <b>Continue</b> keep visible text — they are different consequences.</p></div>
        <div class="cell"><h3>Action anatomy — 32×32 hit, 18 glyph, name = tooltip = aria-label <span class="tag spec">presentation specimen · 4 live handlers</span></h3>
          <table class="spec" style="margin-top:8px">
            ${stateRow('idle (assistant)', actionBar('assistant'), 'opacity 0 → 1 on hover/focus-within, 120ms; always visible on touch (hover:none)')}
            ${stateRow('hover / focus / pressed', actionBar('assistant', { state: { copy: 'hover', 'volume-2': 'focus', 'thumbs-up': 'pressed' } }), 'hover gray-3 · focus 2px ring offset 2 · pressed gray-5 (120ms)')}
            ${stateRow('unavailable', actionBar('assistant', { state: { 'volume-2': 'unavailable', 'thumbs-up': 'unavailable', 'thumbs-down': 'unavailable', 'rotate-ccw': 'unavailable' } }), 'aria-disabled, .55 opacity, tooltip "Read aloud — unavailable"; click yields the reason sentence, never a fake result')}
            ${stateRow('inflight / busy', actionBar('assistant', { state: { copy: 'busy' } }) + '<p class="chat-action-status">Copy response…</p>', 'aria-busy, .6 opacity, status line polite. No spinner glyph.')}
            ${stateRow('selected', actionBar('assistant', { state: { 'thumbs-up': 'selected' } }), 'aria-pressed → --selected background; drawn only; like/dislike/pin have no backend')}
            ${stateRow('resolved / error', '<p class="chat-action-status">Copied.</p><p class="chat-action-status" data-state="error">The action failed. Try again.</p>', 'one status line per row, replaces itself; error is danger text and a separate element — it must stay readable even when the hover-revealed bar fades')}
            ${stateRow('pending response', actionBar('assistant', { state: { 'volume-2': 'unavailable', 'thumbs-up': 'unavailable', 'thumbs-down': 'unavailable', 'rotate-ccw': 'unavailable' } }), 'while streaming only Copy current text is available ("Available after this response finishes.")')}
            ${stateRow('user message', actionBar('user'), 'Copy message · Edit message (edit disabled while busy)')}
          </table></div>
      </div>
      <div class="board-grid" style="grid-template-columns:1fr 1fr 1fr">
        <div class="cell"><h3>More menu · file</h3><div class="menu" style="margin-top:8px">${[['copy','Copy path'],['copy','Copy hash'],['download','Download'],['external-link','Open with…'],['folder','Reveal in folder']].map(([n,l],i)=>`<button type="button" class="quiet-button" ${i>1?'aria-disabled="true"':''} role="menuitem">${icon(n,18)}<span>${l}</span>${i>1?'<span class="form-help" style="margin-left:auto">not available here</span>':''}</button>`).join('')}</div><p class="why">Menu items keep visible words (IC-1). Unavailable items stay in the menu with the reason inline, so the capability gap is legible, not hidden.</p></div>
        <div class="cell"><h3>Capability ledger (unchanged by design)</h3><table class="spec"><tr><th>Intent</th><th>Status</th></tr><tr><td>copy · edit · copy-path · copy-hash</td><td><span class="tag live">live</span> production handlers</td></tr><tr><td>read-aloud · stop-reading</td><td>gap · no speech service admitted</td></tr><tr><td>like · dislike</td><td>gap · no feedback store</td></tr><tr><td>regenerate · fork</td><td>gap · no run/thread endpoint</td></tr><tr><td>share · pin</td><td>gap · no publish / pin owner</td></tr><tr><td>download · open-with · reveal</td><td>gap · host bridge missing</td></tr></table><p class="why">Drawing a control confers no authority (SE-02). The rows above keep their reason strings; no PR in this return wires them.</p></div>
        <div class="cell"><h3>Touch · keyboard · zoom</h3><p class="why">Touch: bar always visible, 44 hit on &lt;1024 via min-height. Keyboard: Tab into the bar, ←/→ not required (buttons are ordinary); More opens a role=menu with ↑/↓/Home/End/Escape; a stream repaint restores focus to the same message's More (restoreChatActionFocus). 200%: status line wraps, bar wraps (flex-wrap) — <i>unverified on device</i>.</p></div>
      </div>
    </div>`,
  });

  // ── ComposerMotion timeline (DG-04) ──────────────────────────────────────────
  const comp = ({ text = null, hint = null, hintClass = '', btn = 'send', focus = false, notice = null, disabled = false }) => `
    <div class="composer-form${focus ? ' is-focus-within' : ''}" style="box-shadow:none;margin:0">
      <div class="composer-input${text ? ' has-text' : ''}" style="min-height:44px">${text ?? 'What would you like to work on?'}</div>
      ${notice ? `<p class="composer-notice">${notice}</p>` : ''}
      ${hint ? `<div class="composer-run-hint ${hintClass}"><span class="dot"></span>${hint}</div>` : ''}
      <div class="composer-controls"><div class="composer-context">${iconBtn('paperclip','Attach','quiet-button icon-only',18)}<span class="composer-model">running-correction-model</span></div><div class="composer-buttons">${btn === 'send' ? iconBtn('arrow-up','Send','primary-button icon-only pill',18, disabled ? 'aria-disabled="true"' : '') : btn === 'stop' ? iconBtn('square','Stop working','primary-button icon-only pill',18, disabled ? 'aria-disabled="true"' : '') : iconBtn('square','Stop working','primary-button icon-only pill',18,'aria-disabled="true"')}</div></div>
    </div>`;
  const step = (n, title, when, motion, reduced, body) => `
    <div class="cell" style="padding:0;overflow:hidden;display:grid;grid-template-rows:auto 1fr auto">
      <div style="padding:10px 14px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:baseline"><h3 style="margin:0"><span class="k" style="color:var(--muted-strong);margin-right:8px">${n}</span>${title}</h3><span class="k" style="color:var(--muted-strong)">${when}</span></div>
      <div style="padding:14px;background:var(--panel)">${body}</div>
      <div style="padding:10px 14px;border-top:1px solid var(--line);display:grid;grid-template-columns:1fr 1fr;gap:12px"><div><div class="eyebrow">motion</div><div class="form-help">${motion}</div></div><div><div class="eyebrow">reduced motion</div><div class="form-help">${reduced}</div></div></div>
    </div>`;
  page({
    file: `${out}/ComposerMotion.dc.html`, title: 'Composer · thinking · streaming timeline', width: 1440, height: 1860,
    body: `<div class="board">
      <div class="eyebrow">DG-04 · P0 · <span class="tag spec">source-inferred state / timing specimen · static boards, not wired</span> · registered tokens 120 / 180ms, curve (.2,0,0,1) · loops in code today: run pulse 1.6s, activity shimmer 1.8s (styles.css ~3433) · status words from thread-projection.mjs / app.mjs: Working / Waiting for you / Stopping / Completed / Interrupted / Failed</div>
      <h1 class="board-title" style="margin-top:8px">The word changes first; motion only confirms it.</h1>
      <p class="board-lede">Nine states, drawn with the composer as it ships. These frames show intended appearance and timing; they do not execute a transition, and every claim here is to be verified against the real projection in DR-04. Nothing here fakes thinking content, progress, token rate or time remaining. The draft, the selection, the focus and the reading position are never touched by a transition: every animated property is opacity, transform or colour on chrome, never on text the user is reading or editing. Enter/exit resumes from the current state; a reopened chat renders the final text at once, it never replays the stream.</p>
      <div class="board-grid" style="grid-template-columns:1fr 1fr 1fr">
        ${step('1','Idle → typing','0 ms','focus-within: border --line-strong → --ink, 120ms colour','same, instant', comp({ text: 'Refresh the Project Cedar sources and tell me which derivations are behind.', focus: true }))}
        ${step('2','Send pressed → in flight','0–120 ms','Send bg → --accent-strong 120ms; message appears in the list without animation; field clears; Send slot swaps to Stop (same pill, same 28×28) — no width change (M-9)','same', comp({ btn: 'stop' }))}
        ${step('3','Before first output','≈ 180 ms after receipt','run hint enters: opacity 0→1, translateY 4→0, 180ms (@starting-style); dot pulses 1.6s; title badge gets the word Running','hint appears instantly; dot static at full opacity', comp({ hint: 'Working · your input will not be sent automatically.', btn: 'stop' }))}
        ${step('4','Text streaming','continuous','append-only: no per-token fade, no caret animation; scroll stays pinned to bottom only if the reader was at the bottom; otherwise the Back to latest chip enters 180ms and the reading position holds','chip appears instantly', `<div style="font-size:15px;line-height:1.7">Source s-1 moved from revision 1 to 2 and s-2 was added, so the Matter's source set is now revision 3. Two pending candidates derive from earlier rev</div><div style="margin-top:8px;display:inline-block;background:var(--glass);border:1px solid var(--line);border-radius:999px;padding:4px 12px;font-size:11.5px">Back to latest</div>`)}
        ${step('5','Tool call','per event','a flow row enters 180ms opacity; meta word Working + dot; the assistant actions bar stays hidden (opacity 0) until the response finishes','row appears instantly', `<div class="flow-row">${icon('activity',16)}<span class="flow-title">Reading the refreshed source</span><span class="flow-meta"><span class="dot" style="animation:se-pulse 1.6s cubic-bezier(.2,0,0,1) infinite"></span>Working</span></div>` + comp({ hint: 'Working for 1m 47s · your input will not be sent automatically.', btn: 'stop' }))}
        ${step('6','Waiting for you','on waiting_user','no transition: pulse stops in the same frame (animation:none), hint colour → --accent-ink 120ms; Question card enters 180ms; Stop remains','same', comp({ hint: 'Waiting for you · answer the question above, or keep typing.', hintClass: 'is-waiting', btn: 'stop' }))}
        ${step('7','Stop requested','on click','the 28×28 Stop control stays 28×28 and becomes aria-disabled; the word Stopping appears in the hint and title badge only after the host reports stopping (cancel requested ≠ stopped); no width change anywhere','same', comp({ hint: 'Stopping', hintClass: 'is-static', btn: 'stopping' }))}
        ${step('8','Stopped / completed','on terminal status','hint exits 180ms opacity; pill swaps back to Send; badge word Interrupted / Completed; actions bar becomes hoverable','hint disappears instantly', comp({}) + `<p class="form-help" style="margin-top:8px"><span class="run-badge">Interrupted</span> · partial text stays as recorded</p>`)}
        ${step('9','Failed → retry','on failed','no motion: error block (2px danger rule) renders statically; two distinct text actions — Retry loading (re-read) vs Continue (new Run)','same', `<div class="message error">Work failed. The runtime closed the connection before the response completed.</div><div style="display:flex;gap:8px;margin-top:8px"><button type="button" class="secondary-button">Retry loading</button><button type="button" class="primary-button">Continue</button></div>` + comp({}))}
      </div>
      <div class="board-grid" style="grid-template-columns:1fr 1fr 1fr">
        <div class="cell"><h3>Timeline (reproducible)</h3><table class="spec"><tr><th>t</th><th>property</th><th>value</th></tr><tr><td>0</td><td>button bg</td><td>120ms colour</td></tr><tr><td>0</td><td>message list</td><td>append, no anim</td></tr><tr><td>+180</td><td>run hint</td><td>opacity/translateY 180ms</td></tr><tr><td>loop</td><td>dot</td><td>1.6s opacity 1 → .25 → 1</td></tr><tr><td>event</td><td>flow row</td><td>opacity 180ms</td></tr><tr><td>waiting</td><td>dot</td><td>animation none (0ms)</td></tr><tr><td>terminal</td><td>hint</td><td>opacity 180ms out</td></tr></table></div>
        <div class="cell"><h3>Interruptions</h3><p class="why">IME composition: Enter during composition never sends (isComposing guard exists). Rapid open/close of the work surface while streaming: the stream keeps its scroll offset; the surface transition (180ms translateX 12) is independent. Switching project or chat mid-stream: the old run's late events go to the old chat; the composer draft belongs to the chat it was typed in. Old request arriving late: ignored by generation counter (already the Spark/Attention rule).</p></div>
        <div class="cell"><h3>What exists today vs what is recommended</h3><p class="why">In code: run-hint pulse 1.6s, a separate activity shimmer 1.8s (~3433) and a raw 140ms chevron transition (~5471). Recommended for DR-04: one long-lived loop at most, the shimmer adjudicated (keep, merge or drop) rather than assumed absent, raw values normalised to tokens. Not drawn: typing dots, skeletons, "thinking…" text, progress, tokens/s, ETA. Reduced motion = static (existing rule; the external "fade must remain" claim is rejected). Forced-colors: dot becomes a CanvasText circle; words carry the state anyway.</p></div>
      </div>
    </div>`,
  });
}
