# Independent Design return · Courtwork SE control surfaces · 2026-09-11 · v2

v2 follows Astra's ruling (return-intake.md, main 3f5daf4). The v1 packet stays archived; differences are listed under "v2 · changes".

Text twin of the design canvas. Astra fills adopt / adapt / reject / defer; nothing here claims acceptance, merge or a closed gate.

## 1 · Input baseline

| Input | Fixed value |
|---|---|
| Packet | `dbd1efe52d7a078cfdb8af03a82470135f31a9dd` |
| Product source read | `a01dee89e752111e63012b705ef81350ce518446` main + `5e3a504` dark authored fix |
| Captures | `f1373cde341b5a17299fad6ba5921ba3fcc43824` · 13 slots × light/dark · evidence only, not relabelled |
| Paper | SE 9.6 `d78fd312955c1f594e59cbdcbb0d3074ac355940` untouched |
| Icon family | Lucide 1.41.0 `bca7e75a816dcf1e75e8feb5a3198a68cbb8a052` static subset (35) |
| Not applicable | EX-IC2 WIP (recall only); historical be41-dto "unimplemented" notes; Scout v1 roles; taste-input accuracy figures; f137 dark bubble as current design |

## 2 · Recommended system

One reading direction for the two reopened glyphs (work on the left → object of judgment on the right); a legal-combination table over existing tokens; state as a word before motion; 120/180 ms and one curve; solid content planes with two registered blurs; sample and live on the same anatomy, labelled. Oppositions drawn as pairs: Spark A/B, Attention A/B, header pair A/B/C, active vs selected, light vs dark depth.

## 3 · Consumption ledger

| Input | Disposition | Reason | Fixed input | Effect |
|---|---|---|---|---|
| Scout L0-1 (WK-134) S-layer above A–D | adopt | External items were used as data only; no asset copied, no instruction executed. | scout-digest.md @dbd1efe | Every external row below is reference or donor, never authority. |
| Scout L0-2 (WK-134/137) consumption chain | adopt | Each candidate cites precedent → grammar rule → primitive → real-content specimen. | scout-digest.md | Glyphs and states are specimens with real Cedar/Acme content, not moodboards. |
| Scout L0-3 (WK-137) problem-addressed research | adopt | Rows were consumed by problem key (icons, composer, approval, motion, material). | scout/README.md @0c60f4f | No favourite-site transfer; Navbar Gallery not used for app shell. |
| Scout L0-4/5 (WK-134/135) capture schema, four dispositions | adopt | Rejected glyphs carry a disposition and reason (ignore with anti-example). | intake-round-3 §4am/§4an | Icons board keeps sparkle / bell / eye / strike as recorded anti-examples. |
| Scout L0-6 (WK-135) EX-SC1 8/8 ignore | adopt | Iridescent status = anti-example; material never carries state. | ex-sc1-scout-pilot.md @318b137 | Material row in DG-09 table; no status tint anywhere. |
| Scout L0-7 (WK-137) section sweep method | defer | No sweep run this round; no open row needed one for the deliverable. | scout-digest.md | Inspector/contextual toolbar stays deferred (SE-05). |
| Scout L0-8 (WK-135/137) pull cadence | adopt | No standing subscription proposed. | scout-digest.md | — |
| Scout L0-9 research workflow as method | adapt | Constraint-first, isolated states and removal pass used; no new tokens authorised by it. | design-research-index @85dc363 | State matrices (Spark/Attention/Chat) are the isolated-state review. |
| SE-01 domain distinctions | adopt | Project ≠ Matter, Session ≠ Run ≠ Thread; unknown stays unknown. | frontend-contract.md @b2f6b3c | Spark rows never show 0 for unavailable; Explore rows are Thread-scoped. |
| SE-02 projection ≠ control | adopt | Every drawn control names its owner or is marked sample. | atlas/README.md @0c60f4f | Rebuild, Explore ladder, chat gaps are sample; nothing new is wired by drawing. |
| SE-03 PropertyRow / model picker reuse | adopt | Settings board redraws the shipped anatomy; numeric control shown only with unit/bounds/commit. | settings-view.mjs @a01dee8 | No new row type. |
| SE-04 Home/Work/Dashboard composition | adopt | Header pair fix keeps the shell; alternative B (fold overview) listed but not recommended. | home-composition README @f666c09 | HeaderPair board. |
| SE-05 disclosure/overlay classification | adopt | Tooltip / popover / menu / dialog drawn as four surfaces with their focus rules. | disclosure-overlay.md @aa9f04f | Settings board; contextual toolbar remains deferred. |
| SE-06 material tiers | adopt | Two blur consumers only; solid content planes. | material-grammar.md @42f2ae9 | DG-09 material row; Pages atmosphere separate. |
| SE-07 Visual Grammar = Shape+Material+Identity+Motion | adopt | DG-09 table resolves roles → existing tokens; no parallel token system. | shape-grammar input @3299730 | Main board. |
| SE-08 skin ≠ review meaning | adopt | Needs you word/weight is the review channel; no colour-only state. | skin-constitution.md @b2f6b3c | Attention boards. |
| SE-09 shape roles | adopt | No new radii; pill only for composer Send/Stop; glyph slots stay square. | ui-composition-standard.md | DG-09 shape row. |
| SE-10 Lucide 1.41.0 subset, no migration (WK-163 D) | adopt + local reopen | Two Courtwork-drawn glyphs on the same grid; one same-family donor (text) for the header pair. | icon-controls.md IC-5…IC-8 @32b0c37 | Icons + HeaderPair boards; manifest rows required. |
| SE-11 composer grammar; dark bubble correction | adopt | CW-PREF-20260911-01 taken as given; light bubble unchanged. | evidence/dark-authored-20260911 @5e3a504 | Depth maps on Main; dark scenes use float bubble. |
| SE-12 BE41 live | adopt | Spark read states drawn from the projection; Refresh ≠ rebuild. | be41-b README @589102c | SparkStates / SparkRebuild. |
| SE-13 Scout protocol | adopt | See L0 rows. | scout/README.md | — |
| SE-14/15/16 Pages copy, capture batch, capture review | adopt | Media stays f137; Pages board is a drawn specimen citing captures as evidence. | site/media/main/manifest.json | PagesStory board. |
| SE-17 EX-IC2 WIP not ancestor; WO-VS-01 shared actions | adopt | Chat actions drawn from chat-actions.mjs as shipped; EX-IC2 used only as recall. | convergence README @035134b | ChatActions board; capability ledger unchanged. |
| SE-18 PR chronology | adopt | No claim about PR #2 state beyond the convergence record. | convergence README | — |
| IC-1 priority & placement | adopt | Navigation = glyph + text; Answer/Allow/Deny keep words; Retry vs Continue distinct. | icon-controls.md | All scenes. |
| IC-3 hover/focus secondary text | adopt | Tooltip never hides scope/error; disclosure request shows fields at the decision point. | icon-controls.md | Attention assistant scene. |
| IC-6 canonical geometry + optical acceptance | adapt | bbox computed, blur test not run (unverified). | icon-controls.md | Verification account on Icons board. |
| WK-57 flow-row anatomy | adopt | Explore ladder reuses it instead of a new row type. | ui-controls.mjs | Explore board. |
| WK-102 material closed set | adopt | No new blur consumer. | styles.css | — |
| WK-120 maturity = size+weight hierarchy | adopt | Boards use no colour or rule to make hierarchy. | intake | — |
| WK-123 auto principle | adopt | Disclosure grant is one exact grant; no always-allow. | intake | Attention states. |
| WK-156…158 Attention views/actions/receipts | adopt | All drawn states exist in attention-view.mjs. | attention-view.mjs @a01dee8 | AttentionStates marks them live. |
| WO-SD-01 / SD-14, SD-17, SD-19 sample rules | adopt | Sample entry lives in the unimplemented sentence; grey label; inert rows. | spark-view.mjs | SparkStates + Explore sample ladder follow the same rule. |
| UE-VG01 Carbon layering | adapt | Layer → role → state order adopted with existing tokens; no Carbon values. | source-review.md | Depth maps. |
| UE-VG02 Atlassian elevation | adapt | Sunken/default/raised/overlay mapped to frame/panel/float/scrim; no new raised. | source-review.md | DG-09 surface row. |
| UE-VG03 Material 3 roles | adapt | on-role relation restated as ink/on-accent; naming not imported. | source-review.md | — |
| UE-VG04 Radix scale | reject as token source / adopt as method | Slots for state exist already; numbers 1–12 do not become Courtwork tokens. | source-review.md | — |
| UE-VG05 Apple materials | adopt | Glass only in registered chrome/transient; content solid. | source-review.md | — |
| UE-VG06 Fluent lifetimes | adopt | Persistent / transient / blocking drawn as three surfaces. | source-review.md | Settings board. |
| UE-VG07 Carbon type strategies | adapt | Expressive serif confined to Pages editorial moments. | source-review.md | DG-09 type row. |
| UE-S03 beUI, UE-S04 assistant-ui, UE-S13 Motiq | reference | Behaviour vocabulary only (action swap, reasoning/tool anatomy); no dependency, no default blur. | source-review.md | Composer timeline. |
| External claim: reduced-motion must keep fades | reject | Accepted rule "reduced motion = static" stands; no counter-evidence with an owner. | HANDOFF §3 | Every timeline step has a static column. |
| External claim: iridescent/shimmer for agent state | reject | EX-SC1 anti-example. | WK-135 | — |
| Taste input multiplication formula / 78–82% accuracy | reject as measurement | Conceptual only; no Courtwork data. | taste-memory.md | Not cited anywhere in the boards. |
| Astra ruling 2026-09-11 · return-intake.md @16e9d37 / 3f5daf4 | adopt (v2) | Four errors admitted and corrected: top palette ≠ effective cascade; Request timeout row not shipped; ChatSpace rebuild question had no handler; DG-04 was not CSS-only live. Header aria, Attention selection semantics, five-beat placement and glyph maturity follow the ruling. | return-intake.md; capability-review.md; visual-review.md; consumption-review.json | All boards re-resolved on the effective cascade; sample / specimen tags added; copy and notes separated. |
| CR-01…04 chat reading (DR-04 supplement) | adopt as scope | Text emergence, syntax colour, Markdown readability and tonal scale are DR-04 requirements; not drawn in this return (out of the visualization grant). | engineering/design/chat-reading-2026-09-11.md @241dd26 | ComposerMotion notes reference them; no board claims them. |
| CW-PREF-20260911-01 dark authored plane lighter | adopt | User direction; scope light unchanged, cards/overlays untouched. | taste-memory.md | Preference Log row; dark scenes. |

## 4 · DG-01–09 coverage matrix

| Gap | Asset | Capability | States | Owner | Entry & return | A11y / static | Deps | Licence | Missing backend |
|---|---|---|---|---|---|---|---|---|---|
| DG-01 | Spark/Attention glyphs (2 source SVG + manifest) | asset · not wired | light / dark / mono · 16-18-20-24 | engineering/design (asset owner), semantic registry nav.spark / nav.attention | nav rows, dialog titles, Home card titles | aria-hidden glyph, text unchanged, currentColor | none | Courtwork-owned; Lucide ISC for donor rows | none |
| DG-02 | Spark overview/activity/states/narrow/rebuild | live (read) · sample (rebuild) | loading, no source, sample, empty, quiet, partial, truncated, error, 409 | BE-41 projection; spark-view.mjs | nav → dialog → Work (Matter) → back to opener | role=status/alert words; focus keys; Escape | none | — | candidate rebuild action + receipt |
| DG-03 | Attention queue/detail/assistant/states/narrow | live | empty, loading, error, not granted / granted / revoked, sending, receipt, conflict, uncertain, validation, question | attention.md contract; attention-view.mjs; attention-agent-view.mjs | nav / Home card / assistant toolbar ↔ workspace | J/K, Escape, return-to-row; 44 targets narrow | none | — | none |
| DG-04 | Composer/thinking/streaming timeline | specimen · source-inferred, not wired | idle, typing, sending, before-output, streaming, tool, waiting, stopping, stopped, failed | thread-projection.mjs status words; styles.css tokens + existing pulse 1.6s / shimmer 1.8s / raw 140ms | in place | reduced-motion static column; forced-colors dot | none | — | none (DR-04 adjudicates shimmer and raw values) |
| DG-05 | Explore coordination + task ladder | live (threads/messages) · sample (ladder) | queued, delivered, stale_target, target_unavailable; sample: queued/working/waiting/completed | coordination-projection.mjs; no task owner | chat disclosure "Threads & messages" | same row anatomy; words not colour | none | — | task object, result binding, per-task stop |
| DG-06 | Chat rows + action anatomy + menu | presentation specimen · live (4 intents) · gap (11) | idle, hover, focus, pressed, unavailable, busy, selected, resolved, error, pending | chat-actions.mjs; semantic registry | message → bar → menu → status | touch-visible bar, restoreChatActionFocus, menu keys | none | — | speech, feedback, regenerate, fork, share, pin, download, open-with, reveal |
| DG-07 | PropertyRow, segmented, tabs, view-switch, filter, tooltip, popover, menu, tap | live (shipped rows only; numeric row is a gate example, not shipped) | rest, hover, pressed, focus, disabled, error, reset | settings-view.mjs, ui-controls.mjs, Floating UI 1.8.0 | settings nav → group → row | focus-visible ring; Escape; 44 touch | Floating UI (already vendored) | MIT (vendored) | Home/End on settings nav (test, not restyle) |
| DG-08 | Pages Home story section + 5 static SVGs | specimen · product copy separate from the capability account | static; motion = existing atom transitions | site/src/page.mjs; media f137 | Home → features.html | forced-colors rules exist; reduced-motion none | none | — | none |
| DG-09 | Grammar legal-combination table + depth maps over the effective cascade | docs | — | atlas/README.md, styles.css :root | — | — | none | — | none |

## 5 · Deliverables

- Native SVG: spark-a, spark-b, attn-a, attn-b (+ rejected spark-c, attn-c) in `glyphs/`.
- Component anatomies and legal combinations: Main, ChatActions, Settings boards.
- Motion timeline with interruptions and static fallback: ComposerMotion board.
- Before/after: light/dark, wide/narrow, long text, failure states.

## 6 · Verification

| Class | What |
|---|---|
| executed (this canvas) | All 19 artboards rendered at their frames: 1440×900 scenes light+dark, 390×844 narrow, matrices; glyphs at 16/18/20/24 in light, dark and mono. |
| source-inferred | Token values, radii, durations, focus/return paths, keyboard handling, state words — read from styles.css, ui-controls.mjs, spark-*.mjs, attention-*.mjs, chat-actions.mjs at dbd1efe. |
| computed | Glyph bbox extents from path data (spark-a 18×10, attn-a 18×10, Lucide neighbours 18×18 / 20×20 on the 24 grid). |
| unverified | VoiceOver names on device; IME composition in the real composer; forced-colors emulation in a browser; true 200% zoom reflow; 1280 viewport; the IC-6 circle/square blur test; the Lucide `text` sha (not fetched). |

## 7 · Suggested PR order

1. DG-09 grammar table → atlas (docs)
2. DG-01 asset PR: spark.svg, attention.svg, manifest courtwork block, sprite regen; then semantic slots nav.spark / nav.attention glyph+text
3. DG-06/07 header pair: vendor the three-line donor by its real Lucide filename + sha, chat.overview → that glyph, surface control keeps aria-expanded / aria-controls + Open / Hide / Collapse names
4. DG-02 Spark read-only parity (state copy audit, narrow padding, 409 copy) — rebuild stays out
5. DG-03 Attention visual parity (no behaviour change)
6. DG-04 composer CSS timeline (no new state)
7. DG-05 Explore sample adapter behind sample entry; backend gap registered
8. DG-08 Pages story section with before/after capture and the five SVGs

### Awaiting Astra

- Spark glyph A (fan-out) vs B (revision ladder). Design recommends A; B is a valid alternate.
- Header pair: donor glyph (recommended) vs folding overview into the surface tabs (alt B) vs visible label (alt C).
- Attention selected-row surface: keep L2 float (recommended) vs gray-4 selected.
- Whether the Pages story section goes above or below the research figures (drawn: above).
- Whether DG-01 glyphs enter canonical on merge or stay "adopted specimen" until a real-device a11y pass.

## v2 · changes against the v1 packet

- all boards: effective default-slate cascade (styles.css ~5500–5570; authored plane ~5906; dark authored = float); "pixel-perfect" withdrawn.
- Main: depth maps sunken / frame / paper / raised + authored with resolved values; dark chips paint their own ink; state ⟂ selection; sunken legal; motion row lists pulse 1.6s, shimmer 1.8s, raw 140ms as facts to adjudicate.
- Icons: Spark A2 optical candidate (18×14) for DR-02; ring = attention object / judgment convergence; counts abstract; single-colour column relabelled.
- HeaderPair: aria-expanded / aria-controls + Open / Hide / Collapse; donor vendored by real Lucide filename + sha.
- SparkRebuild: all controls inert, row-level sample tags, invented route removed.
- SparkActivityDark · SparkNarrow · AttentionNarrow: implementation notes moved to an annotation strip outside the product frame.
- AttentionStates: selection / state / focus coexist; live = list/detail/query, actions live only when advertised.
- ChatSpace: read-only inspection question; four live handlers and hover-revealed bar stated.
- ChatActions: presentation specimen; error status independent of hover.
- ComposerMotion: source-inferred specimen; 28×28 Stop stays 28×28; shimmer and raw values acknowledged; "CSS-only" withdrawn.
- Settings: Request timeout removed from as-shipped; numeric gate example in its own not-shipped cell.
- PagesStory: bilingual product copy without asides; capability account in the annotation strip.
- Frames: heights raised; Return widened to 1200.

## Taste Memory entries proposed

- **Grammar** — DG-09 table; scope App; exceptions Pages campaign palette/serif; review gate Astra + non-author.
- **Exemplars** — Spark A/B, Attention A/B (candidates); spark-c, attn-c, bell, sparkles (rejected, reasons kept); header pair current vs recommended.
- **Preference Log** — CW-PREF-20260911-01 consumed as given; no new user preference recorded (no comparison run with the user).
- **Open Taste** — the disagreements above; Explore ladder shape; whether the Pages story needs a motion variant.
