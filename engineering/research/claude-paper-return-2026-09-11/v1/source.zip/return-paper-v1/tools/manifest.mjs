// Writes source-manifest.json for the return package: consumed sources (repo/SHA/path/hash),
// every output file's sha256, build/render commands and dependencies. No credentials, no personal paths.
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import { join, relative } from 'node:path';
const ROOT = process.argv[2];
const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex');
const walk = (d, out = []) => { for (const n of readdirSync(d).sort()) { const p = join(d, n); const s = statSync(p); if (s.isDirectory()) walk(p, out); else if (n !== 'source-manifest.json' && n !== '.DS_Store') out.push(p); } return out; };
const consumed = JSON.parse(readFileSync(join(ROOT, 'tools', 'consumed.json'), 'utf8'));
const outputs = walk(ROOT).map((p) => ({ path: relative(ROOT, p), bytes: statSync(p).size, sha256: sha(p) }));
const manifest = {
  package: 'return-paper-v1',
  author: 'Claude (Fable 5.1)',
  date: '2026-09-11',
  baseline: {
    courtwork_content_input: '02276730db8a32c24dddd8d514fb4f3b29bf5a5c',
    courtwork_dispatch: 'bb1cba2946157bf8eec0a7d95577a4118f078050',
    courtwork_actual_head_at_work: '2337ada33f1d59543c33ac9e98fcacc5a9e34d21',
    se_reader_source: '2817b8240c34d0754caf623e2a867cc168a260ab',
    paper_adopted: '9.6 / 2026-09-07 / d78fd312955c1f594e59cbdcbb0d3074ac355940',
    candidate_commit_in_isolated_clone: '77b7728 (branch claude/paper-v1-candidate, scratchpad only)',
  },
  consumed,
  commands: {
    build: ['python3 papers/build_en.py', 'python3 papers/build.py', 'python3 papers/validate.py'],
    apply_patch: ['git am reader/patch/0001-*.patch'],
    qa: ['python3 papers/check_translation_alignment.py --self-test', 'python3 papers/qa/test_translation_gate.py', 'python3 -m http.server 8977 --directory papers/dist', 'node papers/qa/verify_reader.mjs --origin http://127.0.0.1:8977/ --out <dir> --cdp-port 19972'],
    editorial: ['node tools/gen-editorial.mjs editorial', 'node tools/shot.mjs <list.json> <receipt.json>'],
    measure: ['node tools/measure.mjs <list.json> <receipt.json>', 'node tools/probe.mjs <url> <width> <expression>'],
    manifest: ['node tools/manifest.mjs .'],
  },
  dependencies: {
    python: '3.10+ with markdown2==2.5.5 (papers/requirements.txt)',
    node: '22+ (global WebSocket, fetch); used 25.9.0',
    browser: 'Google Chrome headless via CDP (path is a CLI/arg default in the tools; any Chrome binary works)',
    fonts: 'system fonts only (ui-serif/ui-sans-serif/ui-monospace stacks); screenshots taken on macOS',
    network: 'none for build, render or reader runtime; refs/external captures fetched public anthropic.com pages once as comparison input',
  },
  notes: [
    'Receipts under verification/ and refs/ record scratchpad file:// paths of the capture session; they are evidence, not runtime dependencies.',
    'reader/dist files are generated outputs of reader/patch applied to the fixed SE source; reader/src mirrors the patched files.',
  ],
  outputs,
};
writeFileSync(join(ROOT, 'source-manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
console.log('files', outputs.length);
