# Canvas v3 · repairs against the v2 receipt

| Receipt item | Change | Evidence |
|---|---|---|
| dark authored values overstated | `shared.mjs`: dark overrides only `--authored-surface` (= float #2e3335); raised / ink / muted / line keep root values #303638 / #f5f7f8 / #c8cdd0 / #596267; header comment states this is a candidate difference, not cascade parity | shared.mjs |
| Spark "extension not loaded" reason | replaced by DTO / fixture values: unavailable row reason `contract_unsupported`; partial coverage reason `contract_unsupported_excluded` (partial.json); the invented scenario text removed | boards-spark.mjs; SparkOverview, SparkNarrow, SparkStates |
| clipped boards | Main split into Main (system + grammar) and MainPlan (ruled mapping); every frame set from a measured content height and re-measured: measure-final.json records document scrollHeight ≤ frame and no clipped container for all boards except the AttentionAssistant stream, which is a scrolling region in the product itself (noted, not a clip of board content) | measure-final.json, renders/ |
| five-beat causality | beat 5 copy and mini figure: a new derivation from the current source (c-11, rev 3) becomes version 8; c-9 / c-10 stay recorded as stale; annotation names the contract path (revise_candidate / new Run with supersedes) | boards-pages.mjs |
| RETURN old ledger | "Awaiting Astra" and "Suggested PR order" kept verbatim as history with the ruled mapping to DG / DR; ledger rows corrected per consumption-review C04 / C05 / C15 / C16 / C18 / C30 / C32 (authority vs evidence, corrected SE-07 pin 5a6d8ac5…, review = label + structure with bounded colour, donor admission deferred pending real filename + sha, WK-120 wording, Attention actions live only when advertised, SE-17 anchors) | boards-return.mjs, work/RETURN-design.md |

Not republished to the artifact URL in this round (offline HTML in work/ + renders/ are the deliverable; Astra archives). A2 glyph stays a DR-02 optical candidate only.
