// Content-completeness check: opens each HTML in headless Chrome over CDP and
// reports document scrollHeight/scrollWidth vs the intended frame, plus any
// element whose text overflows its own box. Node 22+ global WebSocket, no deps.
import { spawn } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const [,, listFile, outFile] = process.argv;
const items = JSON.parse(readFileSync(listFile, 'utf8')); // [{file, w, h, label}]
const port = 9333 + Math.floor(Math.random() * 500);
const chrome = spawn(CHROME, ['--headless=new', '--disable-gpu', '--hide-scrollbars', `--remote-debugging-port=${port}`, '--user-data-dir=/tmp/cw-measure-' + port, 'about:blank'], { stdio: 'ignore' });
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
async function waitPort() { for (let i = 0; i < 50; i++) { try { const r = await fetch(`http://127.0.0.1:${port}/json/version`); if (r.ok) return; } catch {} await sleep(200); } throw new Error('chrome did not start'); }
await waitPort();
const results = [];
for (const it of items) {
  const t = await (await fetch(`http://127.0.0.1:${port}/json/new?about:blank`, { method: 'PUT' })).json();
  const ws = new WebSocket(t.webSocketDebuggerUrl);
  await new Promise(r => ws.onopen = r);
  let id = 0; const pending = new Map();
  ws.onmessage = (m) => { const d = JSON.parse(m.data); if (d.id && pending.has(d.id)) { pending.get(d.id)(d); pending.delete(d.id); } };
  const send = (method, params = {}) => new Promise(res => { const i = ++id; pending.set(i, res); ws.send(JSON.stringify({ id: i, method, params })); });
  await send('Emulation.setDeviceMetricsOverride', { width: it.w, height: it.h, deviceScaleFactor: 1, mobile: false });
  await send('Page.enable');
  await send('Page.navigate', { url: `file://${it.file}` });
  await sleep(700);
  const expr = `(()=>{const d=document.documentElement;const over=[];for(const el of document.querySelectorAll('body *')){if(el.children.length)continue;const cs=getComputedStyle(el);if(cs.overflow!=='visible'&&cs.overflow!=='')continue;if(el.scrollWidth>el.clientWidth+1&&el.clientWidth>0&&cs.whiteSpace!=='nowrap'){over.push({tag:el.tagName,text:(el.textContent||'').trim().slice(0,60),sw:el.scrollWidth,cw:el.clientWidth});}}
    const clipped=[];for(const el of document.querySelectorAll('body *')){const cs=getComputedStyle(el);if(!/hidden|clip/.test(cs.overflowY)&&!/hidden|clip/.test(cs.overflow))continue;if(el.scrollHeight>el.clientHeight+2&&el.clientHeight>0){clipped.push({cls:(el.className||'').toString().slice(0,40),sh:el.scrollHeight,ch:el.clientHeight});}}
    const svgOver=[];for(const t of document.querySelectorAll('svg text')){const b=t.getBBox();const svg=t.ownerSVGElement;const vb=svg.viewBox.baseVal;if(b.x+b.width>vb.x+vb.width+0.5||b.x<vb.x-0.5){svgOver.push({text:t.textContent.slice(0,50),right:Math.round(b.x+b.width),vbw:vb.width});}}
    return {scrollHeight:d.scrollHeight,scrollWidth:d.scrollWidth,clientWidth:d.clientWidth,overflow:over.slice(0,12),svgOver:svgOver.slice(0,12),clipped:clipped.slice(0,12)};})()`;
  const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true });
  const v = r.result.result.value;
  results.push({ label: it.label, file: it.file, frame: [it.w, it.h], measured: [v.scrollWidth, v.scrollHeight], fitsHeight: v.scrollHeight <= it.h, fitsWidth: v.scrollWidth <= it.w, textOverflow: v.overflow, svgTextOutsideViewBox: v.svgOver, clippedContainers: v.clipped });
  ws.close();
  await fetch(`http://127.0.0.1:${port}/json/close/${t.id}`);
}
chrome.kill();
writeFileSync(outFile, JSON.stringify({ at: new Date().toISOString(), results }, null, 2));
for (const r of results) console.log(`${r.fitsHeight && r.fitsWidth ? 'OK  ' : 'FAIL'} ${r.label} frame ${r.frame.join('x')} measured ${r.measured.join('x')} textOverflow ${r.textOverflow.length} svgOut ${r.svgTextOutsideViewBox.length} clipped ${r.clippedContainers.length}${r.clippedContainers.length?' '+JSON.stringify(r.clippedContainers.slice(0,3)):''}`);
