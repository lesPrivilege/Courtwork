// Renders the current reader signature at 16/20/24/32 px, mono and colour, light and dark grounds,
// using the reader's own CSS variables so the sheet reflects the actual page mapping.
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
const [, , readerDir, outDir, label] = process.argv;
mkdirSync(outDir, { recursive: true });
const css = readFileSync(`${readerDir}/reader.css`, "utf8");
const sig = readFileSync(`${readerDir}/signature.svg`, "utf8").trim();
const sizes = [16, 20, 24, 32];
const cell = (fam, size, i) => `<div class="cell"><span class="maker" data-size="${size}">${sig.replace('id="lp-mast-title"', `id="lp-${fam}-${size}-${i}"`).replace('aria-labelledby="lp-mast-title"', `aria-labelledby="lp-${fam}-${size}-${i}"`)}<b>${size}</b></span></div>`;
const block = (fam, theme, i) => `<section data-theme="${theme}"><body-like data-signature="${fam}" class="ground"><h2>${label} · ${fam} · ${theme}</h2><div class="row">${sizes.map((s) => cell(fam, s, i + s)).join("")}</div></body-like></section>`;
const html = `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>signature specimen</title>
<style>${css}
html,body{background:#888;margin:0}
section{padding:0}
.ground{display:block;padding:20px 28px;background:var(--canvas);color:var(--ink);font-family:var(--sans)}
h2{margin:0 0 12px;font:600 12px/1.4 var(--mono);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}
.row{display:flex;gap:36px;align-items:center}
.cell .maker{display:inline-flex;align-items:center;gap:.4em}
.cell .maker .lp-mark{width:auto;height:auto}
.cell .maker[data-size="16"] .lp-mark{width:16px;height:16px}.cell .maker[data-size="20"] .lp-mark{width:20px;height:20px}.cell .maker[data-size="24"] .lp-mark{width:24px;height:24px}.cell .maker[data-size="32"] .lp-mark{width:32px;height:32px}
.cell b{font:500 11px var(--mono);color:var(--muted)}
/* colour family hooks apply on any ancestor carrying data-signature */
[data-signature="color"] .lp-mark .lp-l{fill:var(--lp-l)}[data-signature="color"] .lp-mark .lp-bar-top{fill:var(--lp-red)}[data-signature="color"] .lp-mark .lp-bar-mid{fill:var(--lp-secondary)}
</style>
${block("black", "light", 100)}${block("color", "light", 200)}${block("black", "dark", 300)}${block("color", "dark", 400)}`;
writeFileSync(`${outDir}/signature-specimen.html`, html);
console.log("specimen written");
