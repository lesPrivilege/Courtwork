# F4 · caption and footnote candidates (copy only; Astra integrates)

- `site/src/copy.mjs` ARCHITECTURE.caption: `当前状态 → 运行上下文 → 候选 → 审阅 → 正式变化。` → **`当前状态 → 上下文投影 → 候选 → 审阅 → 正式变化。`** ("运行上下文" reads as runtime state; the canon's word is the compiled context projection.)
- pipeline figure (registry `pipeline`) note for `figures.json.audit.reason` or the page caption: **"Compile is context compilation (M09) — one responsibility inside the target Work Compiler, not the whole compiler."**
- No SVG edit to diagram.svg / pipeline.svg / anatomy-instrument; edge-by-edge verdicts (all keep) are in the archived v2 `F4-continuity-review.md`.
